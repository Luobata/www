/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true*/
/*global console: true*/

(function () {

    //加载css文件
    var loadCss = function (url) {
        var container = document.getElementsByTagName("head")[0];
        var addStyle = document.createElement("link");
        addStyle.rel = "stylesheet";
        addStyle.type = "text/css";
        addStyle.charset = "utf-8";
        addStyle.media = "screen";
        addStyle.href = url;
        container.appendChild(addStyle);
    };

    // 加载js文件
    var loadJs = function (src, fun) {
        var head = document.getElementsByTagName('head')[0] || document.head || document.documentElement;

        var script = document.createElement('script');
        script.setAttribute('type', 'text/javascript');
        script.setAttribute('charset', 'UTF-8');
        script.setAttribute('src', src);

        if (typeof fun === 'function') {
            if (window.attachEvent) {
                script.onreadystatechange = function () {
                    var r = script.readyState;
                    if (r === 'loaded' || r === 'complete') {
                        script.onreadystatechange = null;
                        fun();
                    }
                };
            } else {
                script.onload = fun;
            }
        }

        head.appendChild(script);
    };

    var init = function () {

        // resourceRoot，version
        var version = 'v##CY_JS_VERSION##';
        var resourceRoot = 'http://changyan.itc.cn/changquan/' + version + '/';
        (function () {
            var scripts = document.getElementsByTagName('script'),
                i,
                currentScript;

            for (i = 0; i < scripts.length; i++) {
                if (/changquan\.js/gi.test(scripts[i].src)) {
                    currentScript = scripts[i];
                    break;
                }
            }

            var uri = '';
            try {
                uri = currentScript.src.split('changquan.js')[0];
                if (uri.indexOf('changyan.itc.cn') < 0) {
                    resourceRoot = uri;
                    version = +new Date();
                }
            } catch (e) {}
        }());


        window.changquan._tmp.params.resourceRoot = resourceRoot;
        window.changquan._tmp.params.version = version;


        // load
        var css = [
            'src/css/main/changquan_global.css',
            'src/css/main/changquan_page.css',
            'src/css/main/skin/default.css',
            'src/css/main/changquan_moderator.css'
        ];
        var i;
        for (i = 0; i < css.length; i++) {
            loadCss(resourceRoot + css[i] + '?' + version);
        }

        loadJs(resourceRoot + 'app.js?' + version);
    };

    init();
}());
