/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true, white:true*/
/*global console: true, changquan: true*/
changquan.define(function (require, exports, module) {

	var $ = require('src/lib/zepto.cyan.js');
	var $$template = require('src/lib/template.cyan.js');
	var $$config = require('src/widget/global/changquan_config.js');

	var comment_audit_tmpl = {};
	comment_audit_tmpl.comment_audit_tab = [
	'		<ul id="comment_audit_tab" class="nav nav-pills" role="tablist" data-comment-type="{{comment_status}}">',
  	'			<li data-comment-type="AUDITED" {{if comment_status == "AUDITED"}}class="active"{{/if}}><a href="javascript:void(0)">已审核</a></li>',
  	'			<li data-comment-type="UNAUDIT" {{if comment_status == "UNAUDIT"}}class="active"{{/if}}><a href="javascript:void(0)">未审核</a></li>',
  	'			<li data-comment-type="DELETED" {{if comment_status == "DELETED"}}class="active"{{/if}}><a href="javascript:void(0)">已删除</a></li>',
	'		</ul>',
	];
	comment_audit_tmpl.comment_list = [
	'		{{each comments as comment index}}',
	'			<div class="media normal comment" data-comment-id="{{comment.comment_id}}" data-topic-id="{{comment.topic_id}}">',
    '				{{if comment.attachment}}',
    '				<a class="pull-left" href="#">',
    '					<img src="{{comment.attachment.replace(base_url, base_url + \'/c_fill,w_64,h_64\')}}" style="width: 4em; height: 4em;">',
    '				</a>',
    '				{{/if}}',
    '				<div class="media-body">',
    '					{{if show_topic}}',
    '					<h4 class="media-heading">帖子：{{comment.topic_title}}</h4>',
    '					评论内容：',
    '					{{/if}}',
    '					{{comment.content.substring(0,50)}}',
    '				</div>',
    '				<div class="action-menu">',
    '					{{if comment_status == "UNAUDIT"}}',
    '						<!--{{col = 2}}-->',
    '					{{else}}',
    '						<!--{{col = 1}}-->',
    '					{{/if}}',
    '					{{if comment_status != "AUDITED"}}',
    '					<span class="label label-success comment-pass" style="width:{{90/col}}%;display:inline-block">通过</span>',
    '					{{/if}}',
    '					{{if comment_status != "DELETED"}}',
    '					<span class="label label-danger comment-del" style="width:{{90/col}}%;display:inline-block">删除</span>',
    '					{{/if}}',
    '				</div>',
    '			</div>',
    '		{{/each}}',
    '		{{if comments.length > 0}}',
    '		<div class="text-center margin-top1">',
    '			<button id="comment_audit_btn" class="btn btn-primary" style="width:100%">确&nbsp;&nbsp;&nbsp;&nbsp;定</button>',
    '		</div>',
    '		<div class="text-center">',
    '			<ul id="comment-pager" class="pagination">',
    '				<li {{if page_no <= 1}}class="disabled"{{/if}}><a class="pre" href="javascript:void(0)">上一页</a></li>',
    '				<li class="disabled"><a href="javascript:void(0)">{{page_no}}</a></li>',
    '				<li {{if page_no >= board.total_page}}class="disabled"{{/if}}><a class="next" href="javascript:void(0)">下一页</a></li>',
    '			</ul>',
    '		</div>',
    '		{{/if}}',
	];
	comment_audit_tmpl.board_comment = [
    //畅圈 - 板块帖子审核  Begin
    '   <div id="sohu_CQ_moderator">',
    '		<nav class="navbar-fixed-top" role="navigation">',
    '			<a id="back_to_index" data-hash="" data-tile="{{config.bbs_name}}"',
    '				class="navbar-left">',
    '				返回',
    '			</a>',
    '			<a id="thread_audit" data-hash="boardtaudit_{{board.board_id}}" data-title="{{board.name}}"',
    '				class="navbar-right" href="javascript:void(0)">',
    '				帖子列表',
    '			</a>',
    '      		<p class="navbar-text" data-board-id="{{board.board_id}}">{{board.name}}</p>',
	'		</nav>',
		comment_audit_tmpl.comment_audit_tab.join('\r\n'),
		comment_audit_tmpl.comment_list.join('\r\n'),
    '   </div>'
    //畅圈 - 板块帖子审核  End
	];
	comment_audit_tmpl.thread_comment = [
    //畅圈 - 板块帖子审核  Begin
    '   <div id="sohu_CQ_moderator">',
    '		<nav class="navbar-fixed-top" role="navigation">',
    '			<a id="back_to_boardtaudit" data-hash="boardtaudit_{{board_id}}" class="navbar-left"',
    '				data-board-id="{{board_id}}">',
    '				返回',
    '			</a>',
    '      		<p class="navbar-text" data-topic-id="{{thread.thread_id}}">{{thread.title}}</p>',
	'		</nav>',
		comment_audit_tmpl.comment_audit_tab.join('\r\n'),
		comment_audit_tmpl.comment_list.join('\r\n'),
    '   </div>'
    //畅圈 - 板块帖子审核  End
	];
	var initBoardManageEvent = function(){
		//评论类型类型选择
	    $('#comment_audit_tab li').live('tap', function() {
	    	//重置当前页数
	    	page_no = 1;
	        var category = $(this).data('comment-type');
	        var board_id = $('.navbar-text').data('board-id');
	        var topic_id = $('.navbar-text').data('topic-id');
	        if(board_id){
	        	boardCommentsManage(board_id, category);
	        }
	        if(topic_id){
	        	threadCommentsManage(cur_board_id,topic_id, category);
	        }
	        return false;
	    });
	    //删除通过标记
	    $('.comment-pass').live('tap', function(){
	    	$(this).parents('.media').removeClass('del');
	    	$(this).parents('.media').toggleClass('pass');
	    });
	    $('.comment-del').live('tap', function(){
	    	$(this).parents('.media').removeClass('pass');
	    	$(this).parents('.media').toggleClass('del');
	    });
	    //审核
	    $('#comment_audit_btn').live('tap', function () {
	    	commentAudit();
	    });
	    //翻页
	    $('#comment-pager .pre').live('tap', function(){
	    	if(page_no <=1){
	    		return;
	    	}
	    	var category = $('#comment_audit_tab li.active').data('comment-type');
	        var board_id = $('.navbar-text').data('board-id');
	        var topic_id = $('.navbar-text').data('topic-id');
	    	page_no--;
	        if(board_id){
	        	boardCommentsManage(board_id, category);
	        }
	        if(topic_id){
	        	threadCommentsManage(cur_board_id, topic_id, category);
	        }
	        return false;
	    });
	    $('#comment-pager .next').live('tap', function(){
	    	if(page_no >= total_page){
	    		return;
	    	}
			var category = $('#comment_audit_tab li.active').data('comment-type');
	        var board_id = $('.navbar-text').data('board-id');
	        var topic_id = $('.navbar-text').data('topic-id');
	    	page_no++;
	    	if(board_id){
	        	boardCommentsManage(board_id, category);
	        }
	        if(topic_id){
	        	threadCommentsManage(cur_board_id, topic_id, category);
	        }
	    	return false;
	    });
	};
	var page_no = 1;
	var total_page;
	var boardCommentsManage = function(board_id,category){
	    var params =  {
            bid: board_id,
            page_no: page_no,
            page_size: 10
	    };
	    $.ajax({
	        dataType: 'jsonp',
	        jsonp: 'callback',
	        jsonpCallback: 'loadBoardManagementCallBack',
	        url: 'http://changyan.sohu.com/api/bbs/admin/board/comments/' + category,
	        scriptCharset: 'utf-8',
	        cache: false,
	        data: params,
	        success: function(data) {
	        	data.config = $$config.backend_config;
	        	data.base_url = 'http://comment.bjcnc.img.sohucs.com';
	        	data.page_no = page_no;
	        	data.show_topic = true;
	        	total_page = data.board.total_page;
	            var board_comments_render = $$template.compile(comment_audit_tmpl.board_comment.join('\r\n'));
	            var load_html = board_comments_render(data);
	            $('#sohu-changquan').html(load_html);  
	        }
	    });
	};
	var cur_board_id;
	var threadCommentsManage = function(board_id, topic_id, category){
		cur_board_id = board_id;
	    var params =  {
            bid: board_id,
            tid: topic_id,
            page_no: page_no,
            page_size: 10
	    };
	    $.ajax({
	        dataType: 'jsonp',
	        jsonp: 'callback',
	        jsonpCallback: 'loadBoardManagementCallBack',
	        url: 'http://changyan.sohu.com/api/bbs/admin/topic/' + category,
	        scriptCharset: 'utf-8',
	        cache: false,
	        data: params,
	        success: function(data) {
	        	data.board_id = board_id;
	        	data.base_url = 'http://comment.bjcnc.img.sohucs.com';
	        	data.page_no = page_no;
	        	total_page = data.board.total_page;
	            var thread_comments_render = $$template.compile(comment_audit_tmpl.thread_comment.join('\r\n'));
	            var load_html = thread_comments_render(data);
	            $('#sohu-changquan').html(load_html);  
	        }
	    });
	};
	var commentAudit = function(){
		var comments = [];
		var board_id = $('.navbar-text').data('board-id');
		$('.media').each(function(){
			if($(this).hasClass('del')){
				var comment = {};
				comment.cid = $(this).data('comment-id');
				comment.tid = $(this).data('topic-id');
				comment.status = 2;
				comments.push(comment);
			}
			if($(this).hasClass('pass')){
				var comment = {};
				comment.cid = $(this).data('comment-id');
				comment.tid = $(this).data('topic-id');
				comment.status = 3;
				comments.push(comment);
			}
		});
	    $.ajax({
	    	type: 'POST',
	    	url: 'http://changyan.sohu.com/api/bbs/admin/comment/audit?bid=' + board_id,
	        cache: false,
	        crossDomain: true,
	        xhrFields: {
	        	withCredentials: true
	        },
	        contentType: 'application/json',
	        data: JSON.stringify(comments),
	        success: function(data) {
	        	var category = $('#comment_audit_tab').data('comment-type');
	            if(!data.error_code){
	                boardCommentsManage(board_id, category);
	            }else{
	                alert('帖子审核失败');
	            }
	        }
	    });
	};
	initBoardManageEvent();

	var boardThreadAudit = {
		boardCommentsManage: boardCommentsManage,
		threadCommentsManage: threadCommentsManage
	};
	module.exports = boardThreadAudit;
});