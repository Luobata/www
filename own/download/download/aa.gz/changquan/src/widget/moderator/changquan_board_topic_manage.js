/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true, white:true*/
/*global console: true, changquan: true*/
changquan.define(function (require, exports, module) {

	var $ = require('src/lib/zepto.cyan.js');
	var $$template = require('src/lib/template.cyan.js');
	var $$config = require('src/widget/global/changquan_config.js');
	var $$board_comment_manage = require('src/widget/moderator/changquan_comment_manage.js');

	var board_thread_audit_tmpl = [
    //畅圈 - 板块帖子审核  Begin
    '   <div id="sohu_CQ_moderator">',
    '		<nav class="navbar-fixed-top" role="navigation">',
    '			<a id="back_to_index" data-hash="" data-tile="{{config.bbs_name}}" class="navbar-left" data-hash="">',
    '				返回',
    '			</a>',
    '			<a id="comment_audit" data-hash="boardcaudit_{{board.board_id}}" data-title="{{board.name}}"',
    '				class="navbar-right" href="javascript:void(0)">',
    '				评论列表',
    '			</a>',
    '      		<p class="navbar-text" data-board-id="{{board.board_id}}">{{board.name}}</p>',
	'		</nav>',
	'		<ul id="thread_audit_tab" class="nav nav-pills" role="tablist" data-thread-type="{{topic_status}}">',
  	'			<li data-thread-type="NORMAL" {{if topic_status == "NORMAL"}}class="active"{{/if}}><a href="javascript:void(0)">已审核</a></li>',
  	'			<li data-thread-type="UNAUDIT" {{if topic_status == "UNAUDIT"}}class="active"{{/if}}><a href="javascript:void(0)">未审核</a></li>',
  	'			<li data-thread-type="DELETED" {{if topic_status == "DELETED"}}class="active"{{/if}}><a href="javascript:void(0)">已删除</a></li>',
	'		</ul>',
    '		{{each threads as thread index}}',
	'			<div class="media normal" data-hash="threadcaudit_{{board.board_id}}_{{thread.thread_id}}" ',
	'				data-topic-id="{{thread.thread_id}}">',
	'				<div class="media-main">',
    '					{{if thread.attachment}}',
    '					<a class="pull-left" href="#">',
    '						<img src="{{thread.attachment.replace(base_url, base_url + \'/c_fill,w_64,h_64\')}}" style="width: 4em; height: 4em;">',
    '					</a>',
    '					{{/if}}',
    '					<div class="media-body">',
    '						<h4 class="media-heading">{{thread.title}}</h4>',
    '						{{#thread.content.substring(0,50)}}',
    '					</div>',
    '				</div>',
    '				<div class="action-menu">',
    '					{{if topic_status == "UNAUDIT" || topic_status == "NORMAL"}}',
    '						<!--{{col = 2}}-->',
    '					{{else}}',
    '						<!--{{col = 1}}-->',
    '					{{/if}}',
    '					{{if topic_status != "NORMAL"}}',
    '					<span class="label label-success thread-pass" style="width:{{90/col}}%;display:inline-block">通过</span>',
    '					{{/if}}',
    '					{{if topic_status != "DELETED"}}',
    '					<span class="label label-danger thread-del" style="width:{{90/col}}%;display:inline-block">删除</span>',
    '					{{/if}}',
    '					{{if topic_status == "NORMAL"}}',
    '						{{if !thread.is_top}}',
    '						<span class="label label-warning thread-top" style="width:{{90/col}}%;display:inline-block">置顶</span>',
    '						{{else}}',
    '						<span class="label label-warning thread-untop" style="width:{{90/col}}%;display:inline-block">取消置顶</span>',
    '						{{/if}}',
    '					{{/if}}',
    '				</div>',
    '			</div>',
    '		{{/each}}',
    '		{{if threads.length > 0}}',
    '		<div class="text-center margin-top1">',
    '			<button id="thread_audit_btn" class="btn btn-primary" style="width:100%">确&nbsp;&nbsp;&nbsp;&nbsp;定</button>',
    '		</div>',
    '		<div class="text-center">',
    '			<ul id="thread-pager" class="pagination">',
    '				<li {{if page_no <= 1}}class="disabled"{{/if}}><a class="pre" href="javascript:void(0)">上一页</a></li>',
    '				<li class="disabled"><a href="javascript:void(0)">{{page_no}}</a></li>',
    '				<li {{if page_no >= board.total_page}}class="disabled"{{/if}}><a class="next" href="javascript:void(0)">下一页</a></li>',
    '			</ul>',
    '		</div>',
    '		{{/if}}',
    '   </div>'
    //畅圈 - 板块帖子审核  End
	];
	var initBoardManageEvent = function(){
		//切换到评论，列表
		$('#comment_audit').live('tap', function(){
			var board_id = $('.navbar-text').data('board-id');
			$$board_comment_manage.boardCommentsManage(board_id, 'UNAUDIT');
		})
		$('#thread_audit').live('tap', function(){
			var board_id = $('.navbar-text').data('board-id');
			boardTopicsManage(board_id, 'UNAUDIT');
		})
		//帖子类型选择
	    $('#thread_audit_tab li').live('tap', function() {
	    	//重置当前页数
	    	page_no = 1;
	        var category = $(this).data('thread-type');
	        var board_id = $('.navbar-text').data('board-id');
	        boardTopicsManage(board_id, category);
	        return false;
	    });
	    //删除通过标记
	    $('.thread-pass').live('tap', function(){
	    	$(this).parents('.media').removeClass('del');
			$(this).parents('.media').toggleClass('pass');
	    });
	    $('.thread-del').live('tap', function(){
	    	$(this).parents('.media').removeClass('pass');
			$(this).parents('.media').toggleClass('del');
	    });
	    //审核
	    $('#thread_audit_btn').live('tap', function () {
	    	topicAudit();
	    });
	    //翻页
	    $('#thread-pager .pre').live('tap', function(){
	    	if(page_no <=1){
	    		return;
	    	}
	    	var category = $('#thread_audit_tab li.active').data('thread-type');
	        var board_id = $('.navbar-text').data('board-id');
	    	page_no--;
	    	boardTopicsManage(board_id, category);
	        return false;
	    });
	    $('#thread-pager .next').live('tap', function(){
	    	if(page_no >= total_page){
	    		return;
	    	}
			var category = $('#thread_audit_tab li.active').data('thread-type');
	        var board_id = $('.navbar-text').data('board-id');
	    	page_no++;
	    	boardTopicsManage(board_id, category);
	    	return false;
	    });
	    //帖子评论审核
	    $('.media').live('tap', function (e) {
	    	if($(e.target).hasClass('label')){
	    		return;
	    	}
	    	var board_id = $('.navbar-text').data('board-id');
	    	var topic_id = $(this).data('topic-id');
	    	$$board_comment_manage.threadCommentsManage(board_id, topic_id, 'UNAUDIT');
	    });
	    //帖子置顶
	    $('.thread-top').live('tap', function(){
	    	var tid = $(this).parents('.media').data('topic-id');
	    	changeThreadTop(tid, 'ADD', this);
	    });
	    $('.thread-untop').live('tap', function(){
	    	var tid = $(this).parents('.media').data('topic-id');
	    	changeThreadTop(tid, 'CANCEL', this);
	    })
	};

	var changeThreadTop = function(tid, op, obj){
		var board_id = $('.navbar-text').data('board-id');
		$.ajax({
			url: 'http://changyan.sohu.com/api/bbs/admin/thread/top/' + op,
			dataType: 'jsonp',
			jsonp: 'callback',
			jsonpCallback: 'threadTopCallBack',
	        scriptCharset: 'utf-8',
	        cache: false,
			data: {
				bid: board_id,
				tid: tid
			},
			success: function(data){
				if(!data.error_code){
					if(op == 'ADD'){
						$(obj).removeClass('thread-top');
						$(obj).addClass('thread-untop');
						$(obj).text('取消置顶');
					}
					else{
						$(obj).removeClass('thread-untop');
						$(obj).addClass('thread-top');
						$(obj).text('置顶');
					}
				}else{
					alert('操作失败');
				}
			},
			error: function(){
				alert('操作失败');
			}
		});
	};

	var page_no = 1;
	var total_page;
	var boardTopicsManage = function(board_id,category){
	    var params =  {
            bid: board_id,
            page_no: page_no,
            page_size: 10
	    };
	    $.ajax({
	        dataType: 'jsonp',
	        jsonp: 'callback',
	        jsonpCallback: 'loadBoardManagementCallBack',
	        url: 'http://changyan.sohu.com/api/bbs/admin/board/topics/'+category,
	        scriptCharset: 'utf-8',
	        cache: false,
	        data: params,
	        success: function(data) {
	        	data.config = $$config.backend_config;
	        	data.base_url = 'http://comment.bjcnc.img.sohucs.com';
	        	data.page_no = page_no;
	        	total_page = data.board.total_page;
	            var topic_load_render = $$template.compile(board_thread_audit_tmpl.join('\r\n'));
	            var load_html = topic_load_render(data);
	            $('#sohu-changquan').html(load_html);  
	        }
	    });
	};
	var topicAudit = function(){
		var topics = [];
		var board_id = $('.navbar-text').data('board-id');
		$('.media').each(function(){
			if($(this).hasClass('del')){
				var topic = {};
				topic.id = $(this).data('topic-id');
				topic.status = 2;
				topics.push(topic);
			}
			if($(this).hasClass('pass')){
				var topic = {};
				topic.id = $(this).data('topic-id');
				topic.status = 3;
				topics.push(topic);
			}
		});
	    $.ajax({
	    	type: 'POST',
	    	url: 'http://changyan.sohu.com/api/bbs/admin/topic/audit?bid=' + board_id,
	        cache: false,
	        crossDomain: true,
	        xhrFields: {
	        	withCredentials: true
	        },
	        contentType: 'application/json',
	        data: JSON.stringify(topics),
	        success: function(data) {
	        	var category = $('#thread_audit_tab').data('thread-type');
	            if(!data.error_code){
	                boardTopicsManage(board_id, category);
	            }else{
	                alert('帖子审核失败');
	            }
	        }
	    });
	};
	initBoardManageEvent();

	var boardThreadAudit = {
		boardTopicsManage: boardTopicsManage
	};
	module.exports = boardThreadAudit;
});