changquan.define(function (require, exports, module){
    var $ = require('src/lib/zepto.cyan.js');
    var $$template = require('src/lib/template.cyan.js');
    var $$config = require('src/widget/global/changquan_config.js');
    var $$user = require('src/widget/global/changquan_user.js')

    var sso_isv_login;
    var sso_isv_logout;
    var sso_isv_userinfo;
    var mobile_isv_login_url;
    var client_id;
    //用户登出
    function logout() {
        var sohuplus_logout = 'http://plus.sohu.com/a/spassport/logoutservice';
        var passport_logout = 'http://passport.sohu.com/sso/logout.jsp';
        //先调用畅言的登出接口，成功后回调网站登出接口
        var cyan_logout_api = 'http://changyan.sohu.com/api/2/logout';
        $.ajax({
            url: cyan_logout_api,
            dataType: 'jsonp',
            jsonp: 'callback',
            data: {
                client_id: client_id
            },
            success: function(data) {
                if (!data.error_code) {
                    $$user.cyan_user = undefined;
                    var sso = sso_isv_login && sso_isv_logout && sso_isv_userinfo && mobile_isv_login_url;
                    var isv_user = $$user.isv_user;
                    //如果网站开启单点登录，并且网站用户已登录，则回调网站登出接口
                    if(sso && isv_user && isv_user.is_login){
                        logoutIsv();
                    }
                }
            }
        });
        //登出sohu+
        $.ajax({
            url: sohuplus_logout,
            dataType: 'jsonp',
            jsonp: 'cb',
            jsonpCallback: 'quit',
            cache: false,
            success: function(data) {
                if (data.code == 0) {
                    $$user.cyan_user = undefined;
                } else {
                    console.log('登出失败');
                }
            }
        });
        //登出passport
        $.ajax({
            url: passport_logout,
            dataType: 'jsonp',
            cache: false,
            success: function(data) {
                console.log(data.logout_status);
            }
        });
    }

    // 调用网站单点登出接口
    function logoutIsv(){
        var isv_logout_api = decodeURIComponent(sso_isv_logout);
        $.ajax({
            url: isv_logout_api,
            dataType: 'jsonp',
            jsonp: 'callback',
            jsonpCallback: 'isv_logout_cb',
            success: function(data) {
                if (data.code == 1){
                    if(data.js_src){
                        var js_src = data.js_src;
                        // 声明一个数组标志位，标示是否所有的异步请求都完成
                        var ready = [];
                        for(var i = 0; i < js_src.length; i++){
                            ready[i] = false;
                        }
                        // 所有的异步请求都完成，才表明ucenter登出成功
                        var is_ready = function(){
                            for(var i = 0; i < js_src.length; i++){
                                if(!ready[i])
                                    return false;
                            }
                            return true;
                        }
                        for(var i = 0; i < js_src.length; i++){
                            $.ajax({
                                url: js_src[i],
                                type: 'get',
                                dataType: 'jsonp',
                                success: function(){
                                    ready[i] = true;
                                    if(is_ready() && data.reload_page){
                                        window.location.reload();
                                    }
                                }
                            });
                        }
                        // 防止有接口请求失败，两秒后强制刷新页面
                        if(data.reload_page){
                            setTimeout(function(){
                                window.location.reload();
                            }, 2000);
                        }
                    }else{
                        window.location.reload();
                    }
                }
            }
        });
    }

    var initLogout = function(){
        client_id = $$config.client_id;
        var bbs_global_conf = $$config.backend_config['0'];
        sso_isv_login = bbs_global_conf.sso_isv_login;
        sso_isv_logout = bbs_global_conf.sso_isv_logout;
        sso_isv_userinfo = bbs_global_conf.sso_isv_userInfo;
        mobile_isv_login_url = bbs_global_conf.mobile_isv_login_url;
    }

    var logout_module = {
        initLogout: initLogout,
        logout: logout
    }

    module.exports = logout_module;
});