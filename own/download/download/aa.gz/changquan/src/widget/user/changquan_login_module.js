/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true, white:true*/
/*global console: true, changquan: true*/

changquan.define(function (require, exports, module){
	var $ = require('src/lib/zepto.cyan.js');
	var $$template = require('src/lib/template.cyan.js');
	var $$config = require('src/widget/global/changquan_config.js');
    var $$user = require('src/widget/global/changquan_user.js');
    var $$logout_module = require('src/widget/user/changquan_logout_module.js');
	var login_tmpl = [
        //登录窗口  Begin
        //交互：灰色半透明遮罩层
        '<div id="sohu_CQ_mark" class="reset_public" style="display:none;"></div>',
        //快速发表、其他登录
        '<section id="login_layer" class="reset_public wrapper_CQ_public home_login" style="display:none;">',
            '<section class="home_login_wrap">',
                '<h3 class="login_name"><span>登&nbsp;&nbsp;录</span></h3>',
                '<div class="login_select">',
                    '<ul class="clear_public">',
                        '{{if sso}}',
                            '<li><span id="sso_login" class="select_single" style="background-image:url(\'{{mobile_isv_login_icon}}\')">单点</span></li>',
                        '{{/if}}',
                        '<li><span class="select_sina platform-login" data-platform-id="2">新浪</span></li>',
                        '<li><span class="select_qq platform-login" data-platform-id="3">腾讯</span></li>',
                        '<li><span class="select_renren platform-login" data-platform-id="6">人人</span></li>',
                    '</ul>',
                '</div>',
            '</section>',
        '</section>',
        //登录窗口  End
	];

	var sso_isv_login;
	var sso_isv_logout;
	var sso_isv_userinfo;
	var mobile_isv_login_url;
    var mobile_isv_login_icon;
    var sso_type;
    var client_id;

	var addLoginLayer = function(){
        var data = {};
        data.sso = sso_isv_login && sso_isv_logout && sso_isv_userinfo && mobile_isv_login_url;
        data.mobile_isv_login_icon = mobile_isv_login_icon;
		var login_layer_render = $$template.compile(login_tmpl.join('\r\n'));
        var login_layer = login_layer_render(data);

		$('body').append(login_layer);

        $('#sso_login').live('tap',function(){
            var login_url = decodeURIComponent(mobile_isv_login_url);
            var param_from = encodeURIComponent(window.location.href);
            login_url = login_url.indexOf('?') >=0 ? login_url + '&from=' + param_from : login_url + '?from=' + param_from;
            window.location.href = login_url;
        });
        $('.platform-login').live('tap',function(){
            var client_id = $$config.client_id;
            var platform_id = $(this).data('platform-id');
            var url = encodeURIComponent(encodeURIComponent(window.location.href));
            var login_url = 'http://changyan.sohu.com/api/2/login/passport?client_id=' + client_id + '&platform_id=' + platform_id + '&url=' + url + '&connName=changquan_wap&isMobile=true';
            window.location.href = login_url;
        });
        $('#sohu_CQ_mark').live('tap', function(){
        	$(this).hide();
        	$('#login_layer').hide();
        });
	}

    /**
     * @params login_sso 是否需要调用站点登录接口
     */
    function getUserInfo(login_sso) {
        var param = {
                client_id: client_id
        };

        $.ajax({
            url: 'http://changyan.sohu.com/api/2/user/info',
            dataType: 'jsonp',
            jsonp: 'callback',
            jsonpCallback: 'user_info_cb',
            cache: false,
            data: param,
            success: function(data) {
                $$user.cyan_user = data;
                $$user.ready_trigger.resolve();
                if (!data.error_code) {
                    if (login_sso)
                        loginIsv($$user.cyan_user);
                }
            }
        });
    }

	//获取用户在网站的登录状态和用户信息
    function getIsvUserInfo() {
        var user_info_api = decodeURIComponent(sso_isv_userinfo);
        $.ajax({
            url: user_info_api,
            cache: false,
            dataType: 'jsonp',
            jsonp: 'callback',
            success: function(data) {
                $$user.isv_user = data;
                //用户已经在网站登录
                if (data.is_login) {
                    //调用畅言单点登录接口
                    loginCyan(data.user, data.sign);
                } else if(sso_type == 1){ 
                    //站点配置的完全单点登录，用户未在网站登录,
                    //调用畅言用户信息接口，获取畅言用户信息后，回调网站的单点登录接口
                    getUserInfo(true);
                } else {
                    $$logout_module.logout();
                    getUserInfo();
                }
            },
            error:function(){
                getUserInfo(true);
            }
        });
    }

    //调用网站的单点登录接口
    function loginIsv(user) {
        //用户在畅言已登录，调用网站的单点登录接口
        if (user && !user.error_code) {
            var isv_sso_login_api = decodeURIComponent(sso_isv_login);
            $.ajax({
                url: isv_sso_login_api,
                dataType: 'jsonp',
                data: {
                    cy_user_id: user.user_id,
                    user_id: user.isv_refer_id,
                    nickname: encodeURIComponent(user.nickname),
                    img_url: encodeURIComponent(user.img_url),
                    profile_url: encodeURIComponent(user.profile_url),
                    sign: encodeURIComponent(user.sign)
                },
                jsonp: 'callback',
                jsonpCallback: 'isv_login_cb',
                success: function(data) {
                    if (data.user_id){
                        // 登录ucenter体系的其它应用
                        if(data.js_src){
                            var js_src = data.js_src;
                            // 声明一个数组标志位，标示是否所有的异步请求都完成
                            var ready = [];
                            for(var i = 0; i < js_src.length; i++){
                                ready[i] = false;
                            }
                            // 所有的异步请求都完成，才表明ucenter登录成功
                            var is_ready = function(){
                                for(var i = 0; i < js_src.length; i++){
                                    if(!ready[i])
                                        return false;
                                }
                                return true;
                            }
                            for(var i = 0; i < js_src.length; i++){
                                $.ajax({
                                    url: js_src[i],
                                    type: 'get',
                                    dataType: 'jsonp',
                                    success: function(data){
                                        ready[i] = true;
                                        if(is_ready()){
                                            window.location.reload();
                                        }
                                    }
                                });
                            }
                            // 防止有接口请求失败，两秒后强制刷新页面
                            setTimeout(function(){
                                window.location.reload();
                            }, 2000);
                        }else{
                            window.location.reload();
                        }
                    }
                }
            });
        }
    }

    //畅言单点登录
    function loginCyan(isv_user, sign) {
        var login_isv_api = 'http://changyan.sohu.com/api/2/login/isv';
        $.ajax({
            url: login_isv_api,
            cache: false,
            dataType: 'jsonp',
            jsonp: 'callback',
            data: {
                client_id: client_id,
                nickname: isv_user.nickname,
                img_url: isv_user.img_url,
                profile_url: isv_user.profile_url,
                isv_user_id: isv_user.user_id,
                sign: sign
            },
            success: function(data) {
                if (data.error_code) {
                    $.ajax({
                        url: data.error_msg,
                        cache: false,
                        dataType: 'jsonp',
                        jsonp: 'cb',
                        jsonpCallback: 'cb',
                        success: function(){
                            loginCyan(isv_user, sign);
                        }
                    });
                } else {
                    $$user.cyan_user = data;
                    $$user.ready_trigger.resolve();
                }
            }
        });
    }

    var initLogin = function(){
        client_id = $$config.client_id;
        var bbs_global_conf = $$config.backend_config['0'];
        sso_isv_login = bbs_global_conf.sso_isv_login;
        sso_isv_logout = bbs_global_conf.sso_isv_logout;
        sso_isv_userinfo = bbs_global_conf.sso_isv_userInfo;
        mobile_isv_login_url = bbs_global_conf.mobile_isv_login_url;
        mobile_isv_login_icon = bbs_global_conf.mobile_isv_login_icon;
        sso_type = bbs_global_conf.sso_type;

        addLoginLayer();
    	var sso = sso_isv_login && sso_isv_logout && sso_isv_userinfo && mobile_isv_login_url;
	    if (sso)
        	getIsvUserInfo();
	    else
	        getUserInfo();
    }

	var login_module = {
        initLogin: initLogin,
        showLoginLayer: function(){
            $('#sohu_CQ_mark').show();
            $('#login_layer').show();
        },
        hideLoginLayer: function(){
            $('#sohu_CQ_mark').hide();
            $('#login_layer').hide();
        }
	}

    module.exports = login_module;
});