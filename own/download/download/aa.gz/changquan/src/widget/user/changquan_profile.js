/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true, white:true*/
/*global console: true, changquan: true*/
changquan.define(function (require, exports, module){

	var $ = require('src/lib/zepto.cyan.js');
	var $$template = require('src/lib/template.cyan.js');
	var $$config = require('src/widget/global/changquan_config.js');
	var $$user = require('src/widget/global/changquan_user.js');
	var $$thread_module = require('src/widget/bbs/changquan_thread_module.js');
	var $page = require('src/widget/utils/changquan_page.js');

	var profile_tmpl = {};
	profile_tmpl.user_info = [
				// topBar  Begin 
		'		<section class="top_bar_site">',
		'			<div class="top_bar_bg"></div>',
		'			<div class="top_bar_wrap">',
		'				<div class="bar_left">',
		'					<div class="bar_left_prev">',
		'						<span id="back_to_index" data-hash="">上一页</span>',
		'					</div>',
		'				</div>',
		'				<div class="bar_center">',
		'					<h2 class="bar_center_name">个人中心</h2>',
		'				</div>',
		'			</div>',
		'		</section>',
				// 用户个人信息  Begin 
		'		<section class="user_msg">',
		'			<div class="clear_public msg_wrap">',
		'				<div class="wrap_left"><img src="{{user.img_url || default_img}}" alt=""/></div>',
		'				<div class="wrap_right">',
		'					<div class="clear_public right_name_level">',
		'						<span class="right_name"><em>{{user.nickname}}</em>',
		'						</span><span class="right_level level_{{user.userScore.level}}"></span>',
		'					</div>',
		'					<div class="right_num right_card_num"><em>帖子：{{user.bbs_thread_count}}</em></div>',
		'					<div class="right_num right_comment_num"><em>评论：{{user.bbs_post_reply_count}}</em></div>',
		'				</div>',
		'			</div>',
		'		</section>'
		// 用户个人信息  End   
	];
	profile_tmpl.home_page_tabs = [
		'			<div class="msg_head" id="user_page_head">',
		'				<ul>',
		'					<li id="user-reply-list" {{if data_type == "replies"}}class="now"{{/if}}><span>最新回复</span></li>',
		'					<li id="user-topic-list" {{if data_type == "topics"}}class="now"{{/if}}><span>我的帖子</span></li>',
		'					<li id="user-comment-list" {{if data_type == "comments"}}class="now"{{/if}}><span>我的评论</span></li>',
		'				</ul>',
		'			</div>'
	];
	profile_tmpl.reply_list_tmpl = [
		'	{{each replies as reply index}}',
		'	<div class="clear_public reply_lump" data-hash="thread_{{reply.thread_id}}" data-title="{{reply.thread_title}}"',
		'			data-topic-id="{{reply.thread_id}}">',
		'		<div class="lump_left"><img src="{{reply.user_img || default_img}}" alt=""/></div>',
		'		<div class="lump_right">',
		'			<div class="clear_public lump_head"><span class="head_name"><em>{{reply.user_nick}}</em></span><span class="head_level level_1"></span></div>',
		'			<p class="lump_text"><span>{{#reply.comment_content | $escape | decodeFaceContent}}</span></p>',
		'			<p class="reply_my_comment"><span>',
		'			{{if reply.reply_id}}',
		'				回复我的评论：{{reply.reply_content}}',
		'			{{else}}',
		'				回复我的帖子：{{reply.thread_title}}',
		'			{{/if}}',
		'			</span></p>',
		'			<div class="clear_public lump_from_date">',
		'				<div class="lump_from"><span>来自{{reply.board_name}}圈</span></div>',
		'				<div class="lump_date"><span>{{reply.time | getFormatDate}}</span></div>',
		'			</div>',
		'		</div>',
		'	</div>',
		'	{{/each}}',
	];
	profile_tmpl.user_replies_tmpl = [
			// 畅圈首页  Begin 
		'	<div id="sohu_CQ_page5" class="reset_public wrapper_CQ_public">',
				profile_tmpl.user_info.join('\r\n'),
		'		<section class="msg_cont">',
					profile_tmpl.home_page_tabs.join('\r\n'),
		'			<div class="msg_body" id="user_page_body">',
						// 最新回复 
		'				<div class="body_block now">',
		'					<div class="block_reply">',
		'					{{if replies.length > 0}}',
								profile_tmpl.reply_list_tmpl.join('\r\n'),
		'					{{/if}}',
		'					</div>',
							// 正在加载  Begin 
		'					<section class="lump_loading" style="display:none">',
		'						<div class="loading_wrap"><span class="loading_icon"></span><em>正在加载</em></div>',
		'					</section>',
							// 正在加载  End   
		'				</div>',
		'			</div>',
		'		</section>',
				// 用户信息内容  End   
		'	</div>'
			// 畅圈首页  End 
	];
	profile_tmpl.topic_list_tmpl = [
		'	{{each threads as thread index}}',
		'	<div class="card_lump" id="my_thread_{{thread.thread_id}}" data-hash="thread_{{thread.thread_id}}" ',
		'			data-title="{{thread.title}}" data-topic-id="{{thread.thread_id}}">',
		'		<p class="lump_text"><span>{{thread.title}}</span></p>',
		'		{{if thread.attachment}}',
		'		<div class="cont_pic"><img src="{{thread.attachment}}" alt=""/></div>',
		'		{{/if}}',
		'		<div class="clear_public lump_date_action">',
		'			<div class="lump_date"><span>{{thread.create_time | getFormatDate}}</span></div>',
		'			<div class="lump_action">',
		'				<span class="action_ding">',
		'					<i class="ding_icon"></i><em>{{thread.support_count}}</em>',
		'				</span>',
		'				<span class="action_comment">',
		'					<i class="comment_icon"></i><em>{{thread.cmt_sum}}</em>',
		'				</span>',
		'				<span class="wrap_del" data-topic-id="{{thread.thread_id}}"><em>删除</em></span>',
		'			</div>',
		'		</div>',
		'	</div>',
		'	{{/each}}',
	];
	profile_tmpl.user_topics_tmpl = [
			// 畅圈首页  Begin 
		'	<div id="sohu_CQ_page5" class="reset_public wrapper_CQ_public">',
				profile_tmpl.user_info.join('\r\n'),
		'		<section class="msg_cont">',
					profile_tmpl.home_page_tabs.join('\r\n'),
		'			<div class="msg_body" id="user_page_body">',
						// 我的帖子 
		'				<div class="body_block now">',
		'					<div class="block_card">',
		'					{{if threads.length > 0}}',
								profile_tmpl.topic_list_tmpl.join('\r\n'),
		'					{{/if}}',
		'					</div>',
							// 正在加载  Begin 
		'					<section class="lump_loading" style="display:none">',
		'						<div class="loading_wrap"><span class="loading_icon"></span><em>正在加载</em></div>',
		'					</section>',
							// 正在加载  End   
		'				</div>',
		'			</div>',
		'		</section>',
				// 用户信息内容  End   
		'	</div>'
			// 畅圈首页  End 
	];
	profile_tmpl.comment_list_tmpl = [
		'	{{each comments as comment index}}',
		'	<div class="comment_lump" id="my_comment_{{comment.comment_id}}" data-hash="thread_{{comment.thread_id}}" ',
		'			data-title="{{comment.thread_title}}}" data-topic-id="{{comment.thread_id}}">',
		'		<p class="lump_text"><span>{{#comment.content | $escape | decodeFaceContent}}</span></p>',
		'		{{if comment.attachment}}',
		'		<div class="cont_pic"><img src="{{comment.attachment}}" alt=""/></div>',
		'		{{/if}}',
		'		<div class="clear_public lump_msg">',
		'			<div class="msg_from"><span><em>{{comment.thread_title}}}</em></span></div>',
		'			<div class="msg_date_del">',
		'				<span class="date"><em>{{comment.create_time | getFormatDate}}</em></span>',
		'				<span class="del" data-comment-id="{{comment.comment_id}}"><em>删除</em></span>',
		'			</div>',
		'		</div>',
		'	</div>',
		'	{{/each}}',
	];
	profile_tmpl.user_comments_tmpl = [
			// 畅圈首页  Begin 
		'	<div id="sohu_CQ_page5" class="reset_public wrapper_CQ_public">',
				profile_tmpl.user_info.join('\r\n'),
		'		<section class="msg_cont">',
					profile_tmpl.home_page_tabs.join('\r\n'),
		'			<div class="msg_body" id="user_page_body">',
					// 我的评论 
		'				<div class="body_block now">',
		'					<div class="block_comment">',
		'					{{if comments.length > 0}}',
								profile_tmpl.comment_list_tmpl.join('\r\n'),
		'					{{/if}}',
		'					</div>',
							// 正在加载  Begin 
		'					<section class="lump_loading" style="display:none">',
		'						<div class="loading_wrap"><span class="loading_icon"></span><em>正在加载</em></div>',
		'					</section>',
							// 正在加载  End   
		'				</div>',
		'			</div>',
		'		</section>',
				// 用户信息内容  End   
		'	</div>'
			// 畅圈首页  End 
	];

	var initProfileEvent = function(){
		$('#user-topic-list').live('tap',function(){
			initUserTopics();
			return false;
		});
		$('#user-comment-list').live('tap',function(){
			initUserComments();
			return false;
		});
		$('#user-reply-list').live('tap',function(){
			initUserReplies();
			return false;
		});
		//跳转到帖子详情页
		$('.reply_lump,.card_lump,.comment_lump').live('tap',function(e){
			var target = $(e.target);
			if(target.hasClass('wrap_del') || target.hasClass('del') || 
					target.parents('.wrap_del').length > 0 || target.parents('.del').length > 0){
				return;
			}
	        $$thread_module.showTopic($(this).data('topic-id'));
	        return false;
		});
        //帖子删除
        $('.block_card .wrap_del').live('tap', function(){
            var topic_id = $(this).data('topic-id');
            delTopic(topic_id);
        });
        //评论删除
        $('.block_comment .del').live('tap', function(){
        	var comment_id = $(this).data('comment-id');
        	delComment(comment_id);
        });
	};
	//分页计数
	var page_size = 10;
	var next_page;
	var total_page;
	var initUserTopics = function(){
		next_page = 1;
		getUserTopics(next_page, page_size,function(data){
			var topics_render = $$template.compile(profile_tmpl.user_topics_tmpl.join('\r\n'));
            var topics_html = topics_render(data);
            $('#sohu-changquan').html(topics_html); 
            //滚动分页效果
            $.when($page.getPageEvent('profile_topic')).progress(function(a){
            	if(next_page <= total_page && a.type == 'profile_topic')
            		nextPageUserTopics();
            });
		});
	};
	var nextPageUserTopics = function(){
		getUserTopics(next_page, page_size, function(data){
			var topics_render = $$template.compile(profile_tmpl.topic_list_tmpl.join('\r\n'));
            var topics_html = topics_render(data);
            $('.block_card').append(topics_html);
		});
	};
	var getUserTopics = function(page_no,page_size,render_fn){
		var params = {
			client_id: $$config.client_id,
			page_no: page_no,
			page_size: page_size
		};
		$.ajax({
			url: 'http://changyan.sohu.com/api/bbs/user/topics',
			dataType: 'jsonp',
			jsonp: 'callback',
			jsonpCallback: 'loadUserTopics',
			scriptCharset: 'utf-8',
			cache: false,
			data:params,
			beforeSend: function(){
				$('.lump_loading').show();
			},
			success: function(data) {
				$('.lump_loading').hide();
				data.default_img = 'http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png';
				data.data_type = 'topics';
				total_page = data.total_page;
				next_page++;
				$.when($$user.ready_trigger).done(function(){
					data.user = $$user.cyan_user;
					if (render_fn && typeof render_fn == 'function') {
                        render_fn(data);
                    }
				});
			}
		});
	};
	var initUserReplies = function(){
		next_page = 1;
		getUserReplies(next_page, page_size, function(data){
			var replies_render = $$template.compile(profile_tmpl.user_replies_tmpl.join('\r\n'));
	        var replies_html = replies_render(data);
	        $('#sohu-changquan').html(replies_html);
            //滚动分页效果
            $.when($page.getPageEvent('profile_reply')).progress(function(a){
            	if(next_page <= total_page && a.type == 'profile_reply')	
            		nextPageUserReplies();
            })
	    });
	};
	var nextPageUserReplies = function(){
		getUserReplies(next_page, page_size, function(data){
			var replies_render = $$template.compile(profile_tmpl.reply_list_tmpl.join('\r\n'));
	        var replies_html = replies_render(data);
	        $('.block_reply').append(replies_html);
		});
	};
	var getUserReplies = function(page_no, page_size, render_fn){
		var params = {
			page_no:page_no,
			page_size:page_size,
			client_id: $$config.client_id
		}
		$.ajax({
		    url: 'http://changyan.sohu.com/api/bbs/user/replies',
		    dataType: 'jsonp',
		    jsonp: 'callback',
		    jsonpCallback: 'loadUserReplies',
		    scriptCharset: 'utf-8',
		    cache: false,
		    data: params,			
		    beforeSend: function(){
				$('.lump_loading').show();
			},
			success: function(data) {
				$('.lump_loading').hide();
		    	next_page++
		    	total_page = data.total_page;
		    	data.data_type = 'replies';
		    	data.default_img = 'http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png';
	    		$.when($$user.ready_trigger).done(function(){
			    	data.user = $$user.cyan_user;
			    	if(render_fn && typeof render_fn == 'function'){
			    		render_fn(data);
			    	}
		        });
		    }
	  	});
	};
	var initUserComments = function(){
		next_page = 1;
		getUserComments(next_page, page_size, function(data){
			var comments_render = $$template.compile(profile_tmpl.user_comments_tmpl.join('\r\n'));
            var comments_html = comments_render(data);
            $('#sohu-changquan').html(comments_html); 
            //滚动分页效果
            $.when($page.getPageEvent('profile_comment')).progress(function(a){
            	if(next_page <= total_page && a.type == 'profile_comment')
            		nextPageUserComments();
            });
		})
	};
	var nextPageUserComments = function(){
		getUserComments(next_page, page_size, function(data){
			var comments_render = $$template.compile(profile_tmpl.comment_list_tmpl.join('\r\n'));
	        var comments_html = comments_render(data);
	        $('.block_comment').append(comments_html); 
		});
	};
	var getUserComments = function(page_no, page_size, render_fn){
		var params = {
			page_no: page_no,
			page_size: page_size,
			client_id: $$config.client_id
		};
		$.ajax({
			url: 'http://changyan.sohu.com/api/bbs/user/comments',
			dataType: 'jsonp',
			jsonp: 'callback',
			jsonpCallback: 'loadUserComments',
			scriptCharset: 'utf-8',
			cache: false,
			data:params,
			beforeSend: function(){
				$('.lump_loading').show();
			},
			success: function(data) {
				$('.lump_loading').hide();
				data.data_type = 'comments';
				data.default_img = 'http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png';
				total_page = data.total_page;
				next_page++;
				$.when($$user.ready_trigger).done(function(){
					data.user = $$user.cyan_user;
					if(render_fn && typeof render_fn == 'function'){
						render_fn(data);
					}					
		        });
			}
		});
	};
    //作者删帖
    var delTopic = function(topic_id){
        $.ajax({
            url: 'http://changyan.sohu.com/api/bbs/user/del/topic',
            type: 'get',
            dataType: 'jsonp',
            jsonp: 'callback',
            data: {
                client_id: $$config.client_id,
                thread_id: topic_id
            },
            success: function(data){
                $('#my_thread_' + topic_id).remove();
            }
        });
    };
    //作者删除评论
    var delComment = function(comment_id){
        $.ajax({
            url: 'http://changyan.sohu.com/api/bbs/user/del/comment',
            type: 'get',
            dataType: 'jsonp',
            jsonp: 'callback',
            data: {
                client_id: $$config.client_id,
                comment_id: comment_id
            },
            success: function(data){
                $('#my_comment_' + comment_id).remove();
            }
        });
    };
	var profile = {
		initProfile: initProfileEvent,
		getUserReplies: initUserReplies,
		getUserComments: initUserComments,
		getUserTopics: initUserTopics
	};

	module.exports = profile;
});