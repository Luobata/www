/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true, white:true*/
/*global console: true, changquan: true*/

changquan.define(function (require, exports, module){
    var $ = require('src/lib/zepto.cyan.js');
    var $$template = require('src/lib/template.cyan.js');
    var $$config = require('src/widget/global/changquan_config.js');
    var $$thread_module = require('src/widget/bbs/changquan_thread_module.js');
    var $$login_module = require('src/widget/user/changquan_login_module.js');
    var $$user = require('src/widget/global/changquan_user.js');
    var $$edit_thread_module = require('src/widget/bbs/changquan_edit_thread_module.js');
    var $page = require('src/widget/utils/changquan_page.js');

    var board_template = {};
    board_template.top_threads_tmpl = [
        // 板块置顶贴列表
        '{{each top_threads as thread index}}',
        '    <div class="clear_public activity_lump" data-topic-id="{{thread.thread_id}}"',
        '           data-hash="topic_{{thread.thread_id}}" data-title="{{thread.title}}">',
        '        <div class="lump_ding"><span>顶</span></div>',
        '        <p class="lump_text"><span>',
        '            <a href="javascript:void(0)">{{thread.title}}</a>',
        '        </span></p>',
        '    </div>',
        '{{/each}}'
    ];
    board_template.topic_list_piece = [
        // 论坛帖子列表
        '{{each threads as thread index}}',
        //渐变间隔效果  Begin
        '   <section class="group_gap"></section>',
        //渐变间隔效果  End
        //详情  Begin
        '    <section id="thread_{{thread.thread_id}}" class="group_details" >',
        '        <div class="details_lump">',
        '            <div class="lump_title" data-topic-id="{{thread.thread_id}}"',
        '                   data-hash="topic_{{thread.thread_id}}" data-title="{{thread.title}}">',
        '               <a href="javascript:void(0)">{{thread.title}}</a>',
        '            </div>',
        '            <div class="clear_public lump_pic_text {{if !thread.attachment || !thread.attachment.length}}lump_pic_not{{/if}}" data-topic-id="{{thread.thread_id}}"',
        '                   data-hash="topic_{{thread.thread_id}}" data-title="{{thread.title}}">',
        '                {{if thread.attachment}}',
        '                    <div class="lump_pic">',
        '                       <img src="{{thread.attachment.replace(base_url, base_url + \'/c_fill,w_160,h_110/\')}}" alt=""/>',
        '                    </div>',
        '                {{/if}}',
        '                <div class="lump_text">',
        '                    <p class="text "><span>{{#thread.content.substring(0,50)}}</span></p>',
        '                </div>',
        '            </div>',
        '            <div class="clear_public lump_msg">',
        '                <div class="msg_name_level_date">',
        '                    <span class="msg_name"><i>{{thread.user_name}}</i></span>',
        '                    <span class="msg_level level_{{thread.user_score.level}}"></span>',
        '                    <span class="msg_date"><i>{{thread.create_time | getFormatDate}}</i></span>',
        '                </div>',
        '                <div class="msg_ding_comment">',
        '                    <span class="msg_ding" data-topic-id="{{thread.thread_id}}">',
        '                       <i class="ding_icon"></i><em>{{thread.support_count}}</em>',
        '                    </span>',
        '                    <span class="msg_comment" data-topic-id="{{thread.thread_id}}"',
        '                           data-hash="topic_{{thread.thread_id}}" data-title="{{thread.title}}">',
        '                       <i class="comment_icon"></i><em>{{thread.cmt_sum}}</em>',
        '                    </span>',
        '                </div>',
        '            </div>',
        '        </div>',
        '    </section>',
        //详情  End
        '{{/each}}'
    ];
    board_template.topic_list_tmpl = [
        //畅圈 - 圈子页  Begin
        '<div id="sohu_CQ_page2" class="reset_public wrapper_CQ_public">',
        //topBar  Begin
        '    <section class="top_bar_site">',
        '        <div class="top_bar_bg"></div>',
        '        <div class="top_bar_wrap">',
        '            <div class="bar_left">',
        '                <div class="bar_left_prev">',
        '                   <span id="back_to_index" data-hash="" data-title="{{config[0].bbs_name}}">上一页</span>',
        '               </div>',
        '            </div>',
        '            <div class="bar_center">',
        '                <h2 class="bar_center_name">{{board.name}}</h2>',
        '            </div>',
        '            <div class="bar_right">',
        '                {{if !user || user.error_code}}',
        //登录前
        '                    <div class="bar_right_user"><a href="javascript:void(0)"></a></div>',
        '                {{else}}',
        //登录后 显示头像图片 增加class='bar_right_logined' -->
        '                    <div class="bar_right_user bar_right_logined" data-hash="home" data-title="用户中心">',
        '                        <span href="javascript:void(0)">',
        '                            <img src="{{user.img_url||default_img}}" alt=""/>',
        '                        </span>',
        '                        {{if user.bbs_new_reply_count}}',
        '                            <div class="bar_right_logined_msg"></div>',
        '                        {{/if}}',
        '                    </div>',
        '                {{/if}}',
        '            </div>',
        '        </div>',
        '    </section>',
        //topBar  End
        //简介  Begin
        '   <section class="group_intro">',
        '       <div class="clear_public intro_wrap">',
        '           <div class="intro_left">',
        '               <div class="intro_head">',
        '                   {{if board.icon}}',
        '                   <img src="{{board.icon.replace(base_url,base_url + \'/c_fill,w_128,h_128/\')}}" alt=""/>',
        '                   {{else}}',
        '                   <img src="http://changyan.sohu.com/changquan/css/main/images/pic/pic03.png" alt=""/>',
        '                   {{/if}}',
        '               </div>',
        '           </div>',
        '           <div class="intro_right">',
        '               <div class="clear_public intro_right_msg">',
        '                   <h3 class="msg_title">{{board.name}}</h3>',
        '                   <div class="msg_gross">帖子<span>{{board.thread_num}}</span></div>',
        '               </div>',
        '               <p class="intro_right_cont"><span>{{board.description}}</span></p>',
        '           </div>',
        '       </div>',
        '   </section>',
        //简介  End
        //活动  Begin
        '    {{if top_threads.length > 0}}',
        '        <section class="group_activity">',
                    board_template.top_threads_tmpl.join('\r\n'),
        '        </section>',
        '    {{/if}}',
        //活动  End   -->
        '    {{if threads.length > 0}}',
                board_template.topic_list_piece.join('\r\n'),
        '    {{else}}',// end of if
        '       <section class="group_details">',
        '           <div class="details_lump">',
        '               <div class="lump_title"><a href="#">该圈子还没有帖子，快来抢沙发吧</a></div>',
        '           </div>',
        '       </section>',
        '    {{/if}}',

        //正在加载  Begin
        '    <section class="group_loading" style="display:none;">',
        '        <div class="loading_wrap"><span class="loading_icon"></span><em>正在加载</em></div>',
        '    </section>',
        //正在加载  End

        //发帖按钮  Begin
        '    <section class="group_issue">',
        '       <div class="issue_btn">',
        '           <a id="edit_thread" data-board-id="{{board.board_id}}" data-board-name="{{board.board_name}}"',
        '               data-hash="editthread" data-title="发表话题" href="javascript:void(0)"><em>发帖</em></a>',
        '       </div>',
        '    </section>',
        //发帖按钮  End
        '</div>'
        //畅圈 - 圈子页  End
    ];

    var initBoardEvent = function(){
        $('.lump_title,.lump_pic_text,.msg_comment,.activity_lump').live('tap',function(e){
            $$thread_module.showTopic($(this).data('topic-id'));
            return false;
        });
        $('#edit_thread').live('tap',function(){
            //用户未登录
            var user_info = $$user.cyan_user;
            if(!user_info || user_info.error_code == 10207){
                return;
            }

            $$edit_thread_module.editThread($(this).data('board-id'), $(this).data('board-name'));
        });
        $('.msg_ding').live('tap', function(){
            if($(this).hasClass('msg_ding_e')){
                return;
            }
            $(this).addClass('msg_ding_e');
            $$thread_module.favourTopic($(this).data('topic-id'));
            return false;
        });
    };
    //当前页数
    var next_page = 2;
    var total_page;
    //初始化页面
    var loadTopics = function(board_id) {
        getThreads(board_id, 1, 10, function(data){
            var topic_load_render = $$template.compile(board_template.topic_list_tmpl.join('\r\n'));
            var load_html = topic_load_render(data);
            $('#sohu-changquan').html(load_html);
            next_page = 2; 
            total_page = data.board.total_page;
            // 滚动加载  
            $.when($page.getPageEvent('board')).progress(function(a){
                if(next_page <= total_page && a.type == 'board')
                    nextPage(board_id);
            });
        });
    };
    //分页加载帖子
    var nextPage = function(board_id){
        getThreads(board_id, next_page, 10, function(data){
            var page_comment_render = $$template.compile(board_template.topic_list_piece.join('\r\n'));
            var page_html = page_comment_render(data);
            $('.group_details').last().after(page_html);
            next_page++;
        });
    };
    //请求帖子数据
    var getThreads = function(board_id, page_no, page_size, render_fn){
        var params =  {
            board_id: board_id,
            page_no: page_no,
            page_size: page_size
        };
        $.ajax({
            url: 'http://changyan.sohu.com/api/bbs/board/threads',
            dataType: 'jsonp',
            jsonp: 'callback',
            jsonpCallback: 'loadTopicsCallBack',
            scriptCharset: 'utf-8',
            cache: false,
            data: params,
            beforeSend: function(){
                $('.group_loading').show();
            },
            success: function(data){
                //用户信息获取完成后，再渲染页面
                $.when($$user.ready_trigger).done(function(){
                    data.config = $$config.backend_config;
                    data.base_url = 'http://comment.bjcnc.img.sohucs.com';
                    data.default_img = 'http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png';
                    data.user = $$user.cyan_user;
                    if(render_fn && typeof render_fn == 'function'){
                        render_fn(data);
                    }
                    $('.group_loading').hide();
                });
            }
        });
    };

    initBoardEvent();

    var board_module = {
        loadTopics: loadTopics
    };
    module.exports = board_module;
});