/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true, white:true*/
/*global console: true, changquan: true*/

changquan.define(function (require, exports, module) {
	var $ = require('src/lib/zepto.cyan.js');
	var $$template = require('src/lib/template.cyan.js');
	var $$config = require('src/widget/global/changquan_config.js');
	var $$user = require('src/widget/global/changquan_user.js');
	var $$login_module = require('src/widget/user/changquan_login_module.js');
	var $$board_module = require('src/widget/bbs/changquan_board_module.js');
	var $$thread_module = require('src/widget/bbs/changquan_thread_module.js');
	var $$profile_module = require('src/widget/user/changquan_profile.js');
	var $$board_topic_manage = require('src/widget/moderator/changquan_board_topic_manage.js');

	var index_tmpl = {};
	index_tmpl.board_list_tmpl = [
		'<div id="sohu_CQ_page1" class="reset_public wrapper_CQ_public">',
		//topBar  Begin
		'	<section class="top_bar_site">',
		'		<div class="top_bar_bg"></div>',
		'		<div class="top_bar_wrap">',
		'			<div class="bar_left">',
		'				<div class="bar_left_prev">',
		'					<span {{if config[0].home_page}}onclick="window.location.href=\'{{config[0].home_page}}\'"{{/if}}',
		'						style="background-image:url({{config[0].home_logo}})">上一页</span>',
		'				</div>',
		'			</div>',
		'			<div class="bar_center">',
		'				<h2 class="bar_center_name">{{config[0].bbs_name}}</h2>',
		'			</div>',
		'			<div class="bar_right">',
		'				{{if !user || user.error_code}}',
		//登录前
		'					<div class="bar_right_user"><span data-hash="home" data-title="用户中心"></span></div>',
		'				{{else}}',
		//登录后 显示头像图片 增加class='bar_right_logined' -->
		'					<div class="bar_right_user bar_right_logined" data-hash="home" data-title="用户中心">',
		'						<span href="javascript:void(0);"><img src="{{user.img_url||default_img}}" alt=""/></span>',
		'						{{if user.bbs_new_reply_count}}',
		'							<div class="bar_right_logined_msg"></div>',
		'						{{/if}}',
		'					</div>',
		'				{{/if}}',
		'			</div>',
		'		</div>',
		'	</section>',
		//topBar  End
		//焦点图   Begin
		'	<section class="turn_pic">',
		'		<div class="turn_wrap">',
		'			<ul class="trun_box clear_pbulic" style="width:{{topics.length*100}}%;margin-left:-100%">',
		// 最后一张轮播图放在第一个，向前滑动时显示
		'				<!-- {{length = topics.length}} -->',
		'				<!-- {{last = topics[length - 1]}} -->',
		'				<li data-pic-num="{{length - 1}}" style="width:{{100/length}}%">',
		'					<a href="javascript:void(0)" data-hash="thread_{{last.thread_id}}" ',
		'							data-title="{{last.title}}" data-thread-id="{{last.thread_id}}">',
		'						<img src="{{last.attachment}}" style="width:100%;height:12.5em" alt=""/>',
		'					</a>',
		'				</li>',
		'				{{each topics as thread index}}',
		'					{{if index < length - 1}}',
		'					<li {{if index == 0}}class="now"{{/if}} data-pic-num="{{index}}" style="width:{{100/length}}%">',
		'						<a href="javascript:void(0)" data-hash="thread_{{thread.thread_id}}" ',
		'								data-title="{{thread.title}}" data-thread-id="{{thread.thread_id}}">',
		'							<img src="{{thread.attachment}}" style="width:100%;height:12.5em" alt=""/>',
		'						</a>',
		'					</li>',
		'					{{/if}}',
		'				{{/each}}',
		'			</ul>',
		'			<div class="trun_pic_title">',
		'				<ul class="clear_public">',
		'					{{each topics as thread index}}',
		'						<li {{if index == 0}}class="now" {{/if}}>{{thread.title}}</li>',
		'					{{/each}}',
		'				</ul>',
		'			</div>',
		'			<div class="trun_pic_num">',
		'				<ul class="clear_public">',
		'					{{each topics as thread index}}',
		'						<li {{if index == 0}}class="now" {{/if}}>{{index}}</li>',
		'					{{/each}}',
		'				</ul>',
		'			</div>',
		'		</div>',
		'	</section>',
		//焦点图   End
		//列表  Begin
		'	<section class="article_list">',
		//注：块点击后添加背景色　class='article_lump_click' -->
		'		{{each boards as board index}}',
		'		<div class="clear_public article_lump" data-hash="board_{{board.board_id}}" data-title="{{board.name}}"',
		'				data-board-id="{{board.board_id}}" data-board-name="{{board.name}}">',
		'			<div class="lump_left">',
		'				<div class="lump_head">',
		'					{{if board.icon}}',
		'					<img src="{{board.icon.replace(base_url, base_url + \'/c_fill,w_128,h_128/\')}}" alt=""/>',
		'					{{else}}',
		'					<img src="http://changyan.sohu.com/changquan/css/main/images/pic/pic03.png" alt=""/>',
		'					{{/if}}',
		'				</div>',
		'			</div>',
		'			<div class="lump_right">',
		'				<div class="clear_public lump_right_msg">',
		'					<h3 class="msg_title">{{board.name}}</h3>',
		'					<div class="msg_num"><span>{{board.thread_num}}</span></div>',
		'				</div>',
		'			    <p class="lump_right_cont"><span>{{board.description}}</span></p>',
		'				{{if board.moderators && arrayContains(board.moderators.split(","), user.user_id)}}',
		'					<a class="board_manage" data-hash="boardtaudit_{{board.board_id}}" ',
		'						style="font-size:0.75em;margin-top:0.5em;">板块管理</a>',
		'				{{/if}}',
		'			</div>',
		'		</div>',
		'		{{/each}}',
		'	</section>',
		//列表  End
		//首页foot  Begin -->
		'	<section class="article_foot">',
		'		<div class="foot_wrap"></div>',
		'	</section>',
		//首页foot  End -->
		'</div>'
	];

	var nextDiagram = function(){
		var width = $('.turn_wrap').width();
		var cur_diagram = $('.trun_box li.now');
		var next_idx = parseInt(cur_diagram.data('pic-num')) + 1;
		//已播放到最后一个
		if(next_idx == $('.trun_box li').length){
			next_idx = 0;
		}
		var next_diagram = $('.trun_box li[data-pic-num="'+ next_idx +'"]');
		$('.trun_box li').eq(0).animate({'margin-left':-width}, 500, 'ease',function(){
			cur_diagram.removeClass('now');
			next_diagram.addClass('now');
			// 第一张轮播图放到最后一张
			var first = $('.trun_box li').eq(0);
			first.css('margin-left', 0);
			first.remove();
			$('.trun_box').append(first);
			//图片说明切换
			$('.trun_pic_title ul li').removeClass('now');
			$('.trun_pic_title ul li').eq(next_idx).addClass('now');
			//图片下标切换
			$('.trun_pic_num ul li').removeClass('now');
			$('.trun_pic_num ul li').eq(next_idx).addClass('now');
		});
	};

	var preDiagram = function(){
		var width = $('.turn_wrap').width();
		var cur_diagram = $('.trun_box li.now');
		var pre_idx = parseInt(cur_diagram.data('pic-num')) - 1;
		//已播放到第一个
		if(pre_idx == -1){
			pre_idx = $('.trun_box li').length - 1;
		}
		var next_diagram = $('.trun_box li[data-pic-num="'+ pre_idx +'"]');
		$('.trun_box li').eq(0).animate({'margin-left':width}, 500, 'ease',function(){
			cur_diagram.removeClass('now');
			next_diagram.addClass('now');
			// 最后一张轮播图放到最后一张
			var last = $('.trun_box li').eq($('.trun_box li').length - 1);
			last.css('margin-left', 0);
			last.remove();
			$('.trun_box').prepend(last);
			$(this).css('margin-left', 0);
			//图片说明切换
			$('.trun_pic_title ul li').removeClass('now');
			$('.trun_pic_title ul li').eq(pre_idx).addClass('now');
			//图片下标切换
			$('.trun_pic_num ul li').removeClass('now');
			$('.trun_pic_num ul li').eq(pre_idx).addClass('now');
		});
	};

	var initIndexEvent = function() {
		//板块列表点击，进入板块页
		$('.article_lump').live('tap', function(e) {
			//点击板块管理，不触发该方法
			if($(e.target).hasClass('board_manage')){
				return false;
			}

			$$board_module.loadTopics($(this).data('board-id'));
			return false;
		});
		//用户中心点击，未登返回，登录跳转用户中心页
		$('.bar_right_user').live('tap', function() {
			//用户未登录
            var user_info = $$user.cyan_user;
            if(!user_info || user_info.error_code === 10207){
                return;
            }

			$$profile_module.getUserReplies();
			return false;
		});
		//轮播图点击进入帖子详情页
		$('.trun_box li a').live('tap',function() {
	        $$thread_module.showTopic($(this).data('thread-id'));
		});
		// 轮播图自动播放
		// setInterval(function(){
		// 	nextDiagram();
		// },5000);
		//轮播图手动切换事件
		var start = [];
		var end = [];
		$('.turn_wrap').live('touchstart',function(e){
			start[0] = e.touches[0].clientX;
			start[1] = e.touches[0].clientY;
		}).live('touchend',function(e){
			end[0] = e.changedTouches[0].clientX;
			end[1] = e.changedTouches[0].clientY;
			if(Math.abs(end[0] - start[0]) > 100 && Math.abs((end[0] - start[0])/(end[1] - start[1])) > 2){
				if(end[0] - start[0] < 0){
					nextDiagram();
				}
				else{
					preDiagram();
				}
			}
		});
		//板块管理
		$('.board_manage').live('tap', function(){
			var board_id = $(this).parents('.article_lump').data('board-id');

			$$board_topic_manage.boardTopicsManage(board_id, 'UNAUDIT');
			return false;
		});
	};

	var loadBoard = function() {
		var params = {
			client_id: $$config.client_id
		};
		$.ajax({
			url: 'http://changyan.sohu.com/api/bbs/index',
			dataType: 'jsonp',
			jsonp: 'callback',
			jsonpCallback: 'loadBoardCallBack',
			scriptCharset: 'utf-8',
			cache: false,
			data: params,
			success: function(data) {
				data.config = $$config.backend_config;
				data.base_url = 'http://comment.bjcnc.img.sohucs.com';
				data.default_img = 'http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png';
				//用户信息获取完成后，再加载首页
				$.when($$user.ready_trigger).done(function(){
					data.user = $$user.cyan_user;
					var topic_load_render = $$template.compile(index_tmpl.board_list_tmpl.join('\r\n'));
					var load_html = topic_load_render(data);
					$('#sohu-changquan').html(load_html);
				});
			}
		});
	};
	initIndexEvent();
	var index_module = {
		loadBoard: loadBoard
	};
	module.exports = index_module;
});