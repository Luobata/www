/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true, white:true*/
/*global console: true, changquan: true, exports: true*/
changquan.define(function (require, exports, module) {
    var $ = require('src/lib/zepto.cyan.js');
    var $$template = require('src/lib/template.cyan.js');
    var $$config = require('src/widget/global/changquan_config.js');
    var $$face_utils = require('src/widget/utils/changquan_face.js');
    var $$uploader = require('src/widget/utils/changquan_upload.js');

    var edit_thread_tmpl = [
    // 畅圈发帖页  Begin 
    '   <div id="sohu_CQ_page3" class="reset_public wrapper_CQ_public">',

    // topBar  Begin 
    '       <section class="top_bar_site">',
    '           <div class="top_bar_bg"></div>',
    '           <div class="top_bar_wrap">',
    '               <div class="bar_left">',
    '                   <div class="bar_left_prev">',
    '                       <span id="back_to_board" data-board-id="{{board_id}}" data-hash="board_{{board_id}}">上一页</span>',
    '                   </div>',
    '               </div>',
    '               <div class="bar_center">',
    '                   <h2 class="bar_center_name">{{board_name}}</h2>',
    '               </div>',
    '               <div class="bar_right">',
    '                   <div class="bar_right_issue"><span></span></div>',
    '               </div>',
    '           </div>',
    '       </section>',
    // topBar  End   

    // 发帖  Begin 
    '       <section class="issue_card">',
    '           <div class="card_title_text">',
    '               <div class="clear_public card_title">',
    '                   <div class="title_left"><span>标题：</span></div>',
    '                   <div class="title_right">',
    '                       <input id="title_input" type="text" value="" />',
    '                       <input id="attach_url" type="hidden">',
    '                       <input id="board_id" type="hidden" value="{{board_id}}">',
    '                   </div>',
    '               </div>',
    // 注：textarea需要JS实现自适应高度，样式无法实现高度100%，默认状态只有两行的高度 
    '               <div class="card_text"><span><em>内容：</em></span>',
    '               <textarea id="thread_input" name="" style="height:100%"></textarea></div>',
    '           </div>',

    // 浮条 Begin 
    '           <div id="thread_bar" class="issue_action face_hidden">',
    '               <div class="clear_public action_bar">',
    '                   <div class="bar_kinds">',
    '                       <ul class="clear_public">',
    // 注：表情按钮点击后添加“kinds_face_e”，表情ICON改变且表情栏显示，再次点击删除“kinds_face_e”，表情ICON恢复到默认状态且表情栏隐藏 
    '                           <li id="thread_face_btn" class="kinds_face"><a href="javascript:;"></a></li>',
    // 上传图片后此按钮隐藏 
    '                           <li class="kinds_upload"><a href="javascript:void(0);">',
    '                               <input id="upload_input" style="font-size:1.5em;opacity: 0.01;" type="file">',
    '                           </a></li>',
    '                       </ul>',
    '                   </div>',
    // 上传图片后，删除图片样式显示 
    '                   <div class="clear_public bar_del_pic" style="display:none;">',
    '                       <div class="bar_pic"><img id="" src="" alt=""/></div>',
    '                       <div class="bar_del"><span>删除</span></div>',
    '                   </div>',
    // 表情 Begin 
    '                   <div id="thread_face_box" class="bar_face_lump" style="display:none">',
    '                        <div class="face_box">',
    '                               {{each faces as face index}}',
    '                                   {{if face.turn % 6 == 1}}',
    '                                       <ul class="clear_public">',
    '                                   {{/if}}',
    '                                   <li data-code="{{index}}"><img src="{{face_base_url + face.img}}"/></li>',
    '                                   {{if face.turn % 6 == 0}}',
    '                                       </ul>',
    '                                   {{/if}}',
    '                               {{/each}}',
    '                               <div class="box_arrow"><span></span></div>',
    '                        </div>',
    '                   </div>',
    // 表情 End   
    '               </div>',
    '           </div>',
    // 浮条 End   

    '       </section>',
    // 发帖  End   
    '   </div>'
    // 畅圈发帖页  End 
    ];
    var initThreadEditEvent = function() {
        //发表帖子
        $('.bar_right_issue span').live('tap', function() {
            var content = $('#thread_input').val();
            var title = $('#title_input').val();
            var img_url = $('#attach_url').val();
            var board_id = $('#board_id').val();
            addTopic(title, content, img_url, board_id);
        });
        //上传图片
        $('#upload_input').live('change', function(e){
            var file = e.target.files[0];
            $.when($$uploader.upload(file))
            .done(function(data){
                $('.kinds_upload').hide();
                $('.bar_del_pic img').attr('src', data.url);
                $('.bar_del_pic').show();
                $('#attach_url').val(data.url);
            })
            .fail(function(data){
                console.log(data.error_msg);
            });
        });
        //删除图片
        $('.bar_del span').live('tap', function(){
            $('.kinds_upload').show();
            $('.bar_del_pic').hide();
            $('.bar_del_pic img').attr('src', '');
            $('#attach_url').val('');
        });
        //表情框
        $('#thread_face_btn').live('tap',function(){
            $(this).toggleClass('kinds_face_e');
            $('#thread_face_box').toggle();
            $('#thread_bar').toggleClass('face_hidden');
            changeTextSize(); 
        });
        //表情点击
        $('#thread_face_box .face_box ul li').live('tap', function(){
            var code = $(this).data('code');
            var old_val = $('#thread_input').val();
            $('#thread_input').val(old_val + '[' + code + ']');
        });
        $(window).resize(function(){
            changeTextSize();
        });
    };
    var changeTextSize = function(){
        var height = $(window).height() - $('.top_bar_wrap').height() 
            - $('.card_title').height() - $('.issue_action').height() - $('.bar_face_lump').height();
        $('.card_text').height(height);
    };
    var editThread = function(board_id, board_name) {
        var data = {};
        data.board_id = board_id;
        data.board_name = board_name;
        data.face_base_url = $$face_utils.face_base_url;
        data.faces = $$face_utils.faces;
        var edit_thread_render = $$template.compile(edit_thread_tmpl.join('\r\n'));
        var edit_html = edit_thread_render(data);
        $('#sohu-changquan').html(edit_html);
        //初始化输入框高度
        changeTextSize();
    };
    var addTopic = function(title, content, img_url, board_id) {
        if(!title){
            alertMsg('请填写帖子标题');
        }
        if(!content){
            alertMsg('请填写帖子内容');
        }
        var params = {
            content: content,
            title: title,
            attachment: img_url
        };
        $.ajax({
            type: 'POST',
            url: 'http://changyan.sohu.com/api/bbs/postthread/' + board_id,
            cache: false,
            crossDomain: true,
            xhrFields:{
                withCredentials: true
            },
            data: params,
            success: function(result) {
                if (!result.error_code) {
                    if (result.topic_status == 'NORMAL') {
                        alertMsg('发表成功', function(){
                            $('#back_to_board').tap();
                        });
                    } else {
                        alertMsg('帖子已发出，请等待管理员审核', function(){
                            $('#back_to_board').tap();
                        });
                    }
                }else{
                    alertMsg('发表失败');
                }
            }
        });
    };
    var alertMsg = function(msg, post_fn){
        $('.issue_succeed span').text(msg);
        $('.issue_succeed').show();
        setTimeout(function(){
            $('.issue_succeed').hide();
            if(typeof post_fn == 'function'){
                post_fn();
            }
        }, 2000);
    };

    initThreadEditEvent();
    var edit_thread_module = {
        editThread: editThread
    };
    module.exports = edit_thread_module;
});