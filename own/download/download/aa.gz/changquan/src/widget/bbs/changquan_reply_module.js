/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true, white:true*/
/*global console: true, changquan: true, exports: true*/
changquan.define(function (require, exports, module) {

    var $ = require('src/lib/zepto.cyan.js'),
        $$template = require('src/lib/template.cyan.js'),
        $$config = require('src/widget/global/changquan_config.js'),
        $$uploader = require('src/widget/utils/changquan_upload.js'),
        $$face_utils = require('src/widget/utils/changquan_face.js');

    var reply_tmpl = {};
    reply_tmpl.reply_layer = [
            // 发表成功提示  Begin  
        '   <div class="reset_public issue_succeed" style="display:none">',
        '       <div class="succeed_wrap"><span>发表成功！</span></div>',
        '   </div>',
            // 发表成功提示  End 
            // 回复窗口 
        '   <div id="comment_reply_container" class="reset_public reply_content face_hidden" style="display:none;">',
        '       <div class="content_wrap">',
        '           <div class="wrap_box">',
        '               <div class="box_action">',
        '                   <div class="action_cancel"><span>取消</span></div>',
        '                   <div class="action_title"><span>回复</span></div>',
                            // 注：发表成功后，按钮显示为灰色，即添加className "action_issue_e" 
        '                   <div class="action_issue"><span>发表</span></div>',
        '               </div>',
                        // 注：默认文字浅灰“回复无敌兔：”，当输入文字时textarea添加“entry_text_e”,文字变为深灰色，且删除默认文字 
        '               <div class="box_reply">',
        '                   <input type="hidden" id="param_topic_id">',
        '                   <input type="hidden" id="param_reply_id">',
        '                   <input type="hidden" id="attach_url">',
        '                   <textarea class="entry_text_e" id="comment_input" name="comment_input"></textarea>',
        '               </div>',
        '               <div class="clear_public action_bar">',
        '                   <div class="bar_kinds">',
        '                       <ul class="clear_public">',
                                    // 注：表情按钮点击后添加“kinds_face_e”，表情栏显示，再次点击删除“kinds_face_e”，表情栏隐藏 
        '                           <li id="comment_face_btn" class="kinds_face"><a href="javascript:void(0);"></a></li>',
        '                           <li class="kinds_upload"><a href="javascript:void(0);">',
        '                               <input id="upload_input" style="font-size:1.5em;opacity: 0.01;" type="file">',
        '                           </a></li>',
        '                       </ul>',
        '                   </div>',
        '                   <div class="clear_public bar_del_pic" style="display:none">',
        '                       <div class="bar_pic"><img src="" alt=""/></div>',
        '                       <div class="bar_del"><span>删除</span></div>',
        '                   </div>',
                            // 表情 Begin 
        '                   <div id="comment_face_box" class="bar_face_lump" style="display:none;">',
        '                       <div class="face_box">',
        '                           <div class="clear_public face_page">',
        '                               {{each faces as face index}}',
        '                                   {{if face.turn % 12 == 1}}',
        '                                       <div class="page_wrap">',
        '                                   {{/if}}',
        '                                   {{if face.turn % 6 == 1}}',
        '                                       <ul class="clear_public">',
        '                                   {{/if}}',
        '                                   <li data-code="{{index}}"><img src="{{face_base_url + face.img}}"/></li>',
        '                                   {{if face.turn % 6 == 0}}',
        '                                       </ul>',
        '                                   {{/if}}',
        '                                   {{if face.turn % 12 == 0}}',
        '                                       </div>',
        '                                   {{/if}}',
        '                               {{/each}}',
        '                           </div>',
        '                           <div class="box_page"><span class="page_now"></span><span></span></div>',
        '                           <div class="box_arrow"><span></span></div>',
        '                       </div>',
        '                   </div>',
                            // 表情 End   
        '               </div>',
        '           </div>',
        '       </div>',
        '   </div>'
            // 窗口  End   
    ];

    var bindReplyEvent = function () {
        //提交评论
        $('.action_issue').live('tap', function () {
            var content = $('#comment_input').val();
            var topic_id = $('#param_topic_id').val();
            var reply_id = $('#param_reply_id').val();
            var attachment = $('#attach_url').val();
            replyComment(topic_id, reply_id, content, attachment);
            return false;
        });
        //上传图片
        $('#upload_input').live('change', function(e){
            var file = e.target.files[0];
            $.when($$uploader.upload(file))
            .done(function(data){
                $('.kinds_upload').hide();
                $('.bar_del_pic img').attr('src', data.url);
                $('.bar_del_pic').show();
                $('#attach_url').val(data.url);
            })
            .fail(function(data){
                console.log(data.error_msg);
            });
        });
        //删除图片
        $('.bar_del span').live('tap', function(){
            $('.kinds_upload').show();
            $('.bar_del_pic').hide();
            $('.bar_del_pic img').attr('src', '');
            $('#attach_url').val('');
        });
        //取消回复
        $('.action_cancel,#sohu_CQ_mark').live('tap', function () {
            hideReply();
            return false;
        });
        //表情框
        $('#comment_face_btn').live('tap',function(){
            $(this).toggleClass('kinds_face_e');
            $('#comment_face_box').toggle();
            $('#comment_reply_container').toggleClass('face_hidden'); 
        });
        //表情点击
        $('#comment_face_box .face_box ul li').live('tap', function(){
            var code = $(this).data('code');
            var old_val = $('#comment_input').val();
            $('#comment_input').val(old_val + '[' + code + ']');
        });
        //表情滑动
        var start = [];
        $('#comment_face_box .face_box').live('touchstart', function(e){
            start[0] = e.touches[0].clientX;
            start[1] = e.touches[0].clientY;
        }).live('touchend', function(e){
            var end = [];
            end[0] = e.changedTouches[0].clientX;
            end[1] = e.changedTouches[0].clientY;
            var move_x = end[0] - start[0];
            var move_y = end[1] - start[1];
            if(Math.abs(move_x/move_y) > 1.5){
                rollFace(move_x);
            }
        });
    };

    var rollFace = function(direction){
        if(direction > 0){
            $('.face_page').animate({'margin-left':'0'}, 200);
            $('.face_box .box_page span').eq(0).addClass('page_now');
            $('.face_box .box_page span').eq(1).removeClass('page_now');
        }else{
            $('.face_page').animate({'margin-left':'-100%'}, 200);
            $('.face_box .box_page span').eq(1).addClass('page_now');
            $('.face_box .box_page span').eq(0).removeClass('page_now');
        }
    };

    var addReplyLayer = function(){
        var data = {};
        data.faces = $$face_utils.faces;
        data.face_base_url = $$face_utils.face_base_url;
        var layer_render = $$template.compile(reply_tmpl.reply_layer.join('\r\n'));
        var layer_html = layer_render(data);
        $('body').append(layer_html);
    };
    //弹出回复框
    var promptReply = function (topic_id, reply_id, reply_name) {
        if(reply_id){
            $('.kinds_upload').hide();
        }else{
            $('.kinds_upload').show();
        }
        $('#param_topic_id').val(topic_id);
        $('#param_reply_id').val(reply_id || 0);
        $('#sohu_CQ_mark').show();
        $('.reply_content').show();
        if(reply_id){
            $('#comment_input').attr('placeholder', '回复' + reply_name + '：');
        }
    },
    // 隐藏回复框
    hideReply = function () {
        $('#param_topic_id').val('');
        $('#param_reply_id').val('');
        $('#sohu_CQ_mark').hide();
        $('.reply_content').hide();
        $('#comment_input').attr('placeholder', '');
        $('#comment_input').val('');
    },
    replyComment = function(topic_id, reply_id, content, attachment){
        if(!content){
            alertMsg('请输入评论内容');
            return;
        }
        var params = {
            topic_id: topic_id,
            reply_id: reply_id,
            content: content,
            attachment: attachment
        };
        $.ajax({
            type: 'POST',
            url: 'http://changyan.sohu.com/api/bbs/postreply/' + topic_id,
            scriptCharset: 'utf-8',
            crossDomain: true,
            xhrFields: {
                withCredentials: true
            },
            data: params,
            success: function (data) {
                if(!data.error_code){
                    hideReply();
                    var enable = data.is_enable;
                    if(enable){
                        alertMsg('发表成功！');
                    }else{
                        alertMsg('回帖已发出，请等待管理员审核。');
                    }
                }else{
                    alertMsg('发表失败');
                }
            }
        });
    };
    var alertMsg = function(msg, post_fn){
        $('.issue_succeed span').text(msg);
        $('.issue_succeed').show();
        setTimeout(function(){
            $('.issue_succeed').hide();
            if(typeof post_fn == 'function'){
                post_fn();
            }
        }, 2000);
    };
    bindReplyEvent();
    addReplyLayer();
    var reply = {
        promptReply: promptReply,
        alertMsg: alertMsg
    };
    module.exports = reply;
});