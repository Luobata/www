/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true*/
/*global console: true, changquan: true*/


changquan.define(function (require, exports, module) {
    var $ = require('src/lib/zepto.cyan.js');
    var $$template = require('src/lib/template.cyan.js');
    var $$config = require('src/widget/global/changquan_config.js');
    var $$login_module = require('src/widget/user/changquan_login_module.js');
    var $$user = require('src/widget/global/changquan_user.js');
    var $$reply_module = require('src/widget/bbs/changquan_reply_module.js');
    var $page = require('src/widget/utils/changquan_page.js');

    var thread_tmpl = {};
    thread_tmpl.subcmt_piece_tmpl = [
        '<p class="cont_reply" id="sub_comment_{{sub_comment.comment_id}}" data-reply-name="{{sub_comment.passport.nickname}}" data-comment-id="{{sub_comment.comment_id}}">',
        '   <span class="reply_name">',
        '       <em class="user_name">{{sub_comment.passport.nickname}}</em>{{if sub_comment.reply_name}}回复<em class="user_name">{{sub_comment.reply_name}}</em>{{/if}} :',
        '   </span>{{#sub_comment.content | $escape | decodeFaceContent}}',
        '   <span class="cont_date"><em>{{sub_comment.create_time | getFormatDate}}</em></span>',
        '</p>'
    ];
    thread_tmpl.comment_piece_tmpl = [
        '<div class="reply_cont" id="comment_{{comment.comment_id}}">',
        '   <div class="clear_public cont_head">',
        '       <div class="head_pic"><img src="{{comment.passport.img_url||default_img}}" alt=""/></div>',
        '       <div class="head_msg">',
        '           <div class="msg_user_floor">',
        '               <span class="user_name"><em>{{comment.passport.nickname}}</em></span>',
        '               <span class="msg_level level_{{comment.userScore.level}}"></span>',
        '               {{if comment.passport.user_id == user.sid}}',
        '                   <span class="floor_main"><em>楼主</em></span>',
        '               {{/if}}',
        '               <span class="msg_floor"><em>{{comment.metadataAsJson.bbs_floor}}楼</em></span>',
        '           </div>',
        '           <div class="msg_date"><span>{{comment.create_time | getFormatDate}}</span></div>',
        '       </div>',
        '   </div>',
        '   <p class="cont_text" data-comment-id="{{comment.comment_id}}" data-reply-name="{{comment.passport.nickname}}">',
        '       <span>{{#comment.content | $escape | decodeFaceContent}}</span>',
        '   </p>',
        '   {{if comment.attachments && comment.attachments.length > 0}}',
        '       <div class="cont_pic">',
        '           <img src="{{comment.attachments[0].url.replace(base_url, base_url + "/c_fill,w_120,h_90/")}}">',
        '       </div>',
        '   {{/if}}',
        '   {{if comment.comments && comment.comments.length > 0 }}',
        '       {{each comment.comments as sub_comment index}}',
                    thread_tmpl.subcmt_piece_tmpl.join('\r\n'),
        '       {{/each}}',
        '   {{/if}}',
        '</div>'
    ];
    thread_tmpl.comment_list_tmpl = [
        '{{each comments as comment index}}',
            thread_tmpl.comment_piece_tmpl.join('\r\n'),
        '{{/each}}'
    ];
    thread_tmpl.topic_tmpl = [// 论坛帖子详细信息
        //畅圈 - 帖子页  Begin
        '   <div id="sohu_CQ_page4" class="reset_public wrapper_CQ_public">',
        //topBar  Begin
        '       <section class="top_bar_site">',
        '           <div class="top_bar_bg"></div>',
        '           <div class="top_bar_wrap">',
        '               <div class="bar_left">',
        '                   <div class="bar_left_prev">',
        '                       <span id="back_to_board" data-board-id="{{board.id}}" data-hash="board_{{board.id}}">上一页</span>',
        '                   </div>',
        '               </div>',
        '               <div class="bar_center">',
        '                   <h2 class="bar_center_name">{{board.name}}</h2>',
        '               </div>',
        '               <div class="bar_right">',
        //点击此按钮,显示"更多选择"窗口
        '                   <div class="bar_right_more"><span></span></div>',
        '               </div>',
        '           </div>',
        '       </section>',
        //topBar  End  
        //帖子  Begin 
        '       <section class="card_range">',
        '           <section class="range_main" data-topic-id="{{thread_id}}">',
        '               <div class="clear_public main_head">',
        '                   <div class="clear_public head_left">',
        '                       <div class="head_pic"><img src="{{user.tiny_avatar||default_img}}" alt=""/></div>',
        '                       <div class="user_name"><span>{{user.nick}}</span></div>',
        '                       <div class="floor_main"><span>楼主</span></div>',
        '                   </div>',
        '                   <div class="head_right">',
        '                       <span class="head_date">{{create_time | getFormatDate}}</span>',
        '                   </div>',
        '               </div>',
        '               <div class="main_title"><span>{{title}}</span></div>',
        '               {{if attachments && attachments.length > 0}}',
        '                   {{each attachments as attachment index}}',
        '                   {{if attachment}}',
        '                       <div class="main_pic"><img src="{{attachment}}" alt=""/></div>',
        '                   {{/if}}',
        '                   {{/each}}',
        '               {{/if}}',
        '               <div class="main_cont">',
        '               {{each split_content as con_item index}}',
        '                   <p><span>{{#con_item | $escape | decodeFaceContent}}</span></p>',
        '               {{/each}}',
        '               </div>',
        '               <div class="clear_public main_action">',
        '                   <div class="action_wrap">',
        '                   <span class="wrap_favour">赞<em>{{support_count}}</em></span>',
        '                   <span class="wrap_comment">评论<em>{{cmt_sum}}</em></span>',
        '               </div>',
        '               </div>',
        '           </section>',
        '           <section class="range_reply">',
                        thread_tmpl.comment_list_tmpl.join('\r\n'),
        '           </section>',
        '       </section>',
        //帖子  End   
        //赞，评论，分享  Begin
        '       <section class="action">',
        '           <ul>',
        '               <li id="favour"><span>赞({{support_count}})</span></li>',
        '               <li id="reply_thread"><span>评论({{cmt_sum}})</span></li>',
        //点击分享按钮,显示"分享选择"窗口
        '               <li id="share_thread"><span>分享</span></li>',
        '           </ul>',
        '       </section>',
        //赞，评论，分享  End  
        '   </div>'
        //畅圈 - 帖子页  End
    ];

    thread_tmpl.menus = [
            //分享选择: 点击悬浮的分享按钮后，弹出！
        '   <div class="reset_public share_select" style="display:none;">',
        '       <ul>',
        '           <li data-platform-id="2"><a href="javascript:void(0);">新浪微博</a></li>',
        '           <li data-platform-id="6"><a href="javascript:void(0);">人人网</a></li>',
        '           <li><a id="share_cancel" href="javascript:void(0);">取{{spaces}}消</a></li>',
        '       </ul>',
        '   </div>',
            //更多选择: 点击页面右上角的更多按钮，弹出！
        '   <div class="reset_public more_select" style="display:none;">',
        '       <ul>',
        '           <li><a id="floor_host_view" href="javascript:void(0);">只看楼主</a></li>',
        '           <li><a id="report" href="javascript:void(0);">投诉举报</a></li>',
        '           <li><a id="menu_cancel" href="javascript:void(0);">取{{spaces}}消</a></li>',
        '       </ul>',
        '   </div>'
    ];

    var bindThreadEvent = function () {
        //点赞
        $('#favour').live('tap', function () {
            if($(this).hasClass('clicked')){
                return;
            }
            $(this).addClass('clicked');
            var topic_id = $('.range_main').data('topic-id');
            favourTopic(topic_id);
        });
        //操作菜单
        $('.bar_right_more span').live('tap', function () {
            $('#sohu_CQ_mark').show();
            $('.more_select').show();
        });
        //隐藏操作菜单
        $('#menu_cancel,#sohu_CQ_mark').live('tap', function () {
            $('#sohu_CQ_mark').hide();
            $('.more_select').hide();
        });
        //只看楼主
        $('#floor_host_view').live('tap', function () {
            if($(this).hasClass('floot_host_only')){
                showTopic($('.range_main').data('topic-id'));
                $(this).text('只看楼主');
            }else{
                viewFloorHost($('.range_main').data('topic-id'));
                $(this).text('查看全部');
            }
            $(this).toggleClass('floot_host_only');
            $('#sohu_CQ_mark').hide();
            $('.more_select').hide();
        });
        //回帖
        $('#reply_thread').live('tap', function () {
            //用户未登录
            var user_info = $$user.cyan_user;
            if (!user_info || user_info.error_code == 10207) {
                $$login_module.showLoginLayer();
                return;
            }

            $$reply_module.promptReply($('.range_main').data('topic-id'), 0);
            return false;
        });
        //评论回复
        $('.reply_cont .cont_text,.cont_reply').live('tap', function () {
            //用户未登录
            var user_info = $$user.cyan_user;
            if (!user_info || user_info.error_code == 10207) {
                $$login_module.showLoginLayer();
                return;
            }

            var reply_id = $(this).data('comment-id');
            var reply_name = $(this).data('reply-name');
            $$reply_module.promptReply($('.range_main').data('topic-id'), reply_id, reply_name);
            return false;
        });
        //举报帖子
        $('#report').live('tap', function(){
            var topic_id = $('.range_main').data('topic-id');
            reportTopic(topic_id);
        });
        //分享帖子
        $('#share_thread').live('tap', function(){
            showShareMenu();
        });
        $('#share_cancel,#sohu_CQ_mark').live('tap', function(){
            hideShareMenu();
        });
        $('.share_select li[data-platform-id]').live('tap', function(){
            var platform_id = $(this).data('platform-id');
            var topic_id = $('.range_main').data('topic-id');
            var passports = $$user.cyan_user && $$user.cyan_user.passports;
            var shared_id;
            var i;
            if(passports){
                for( i = 0;i < passports.length;i++ ){
                    var passport = passports[i];
                    if(passport.platform_id == platform_id){
                        shared_id = passport.passport_id;
                        break;
                    }
                }
            }
            if(!shared_id){
                var url = encodeURIComponent(encodeURIComponent(window.location.href));
                window.location.href = 'http://changyan.sohu.com/api/2/login/passport?client_id=' + $$config.client_id + '&platform_id=' + platform_id + '&url=' + url + '&connName=changquan_wap&isMobile=true';
                return;
            }
            shareTopic(shared_id, topic_id);
        });
    };

    var showShareMenu = function () {
        $('#sohu_CQ_mark').show();
        $('.share_select').show();
    };
    var hideShareMenu = function () {
        $('#sohu_CQ_mark').hide();
        $('.share_select').hide();
    };

    var shareTopic = function (shared_id, topic_id) {
        $.ajax({
            url: 'http://changyan.sohu.com/api/bbs/topic/share',
            type: 'get',
            dataType: 'jsonp',
            jsonp: 'callback',
            jsonpCallback: 'shareTopicCallBack',
            data: {
                client_id: $$config.client_id,
                shared_pid: shared_id,
                topic_id: topic_id
            },
            success: function (data) {
                if (!data.error_code) {
                    $$reply_module.alertMsg('分享成功');
                } else {
                    $$reply_module.alertMsg('分享失败');
                }
                hideShareMenu();
            },
            error: function () {
                $$reply_module.alertMsg('分享失败');
                hideShareMenu();
            }
        });
    };

    var addMenus = function () {
        var data = {};
        data.spaces = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        var menus_render = $$template.compile(thread_tmpl.menus.join('\r\n'));
        var menus_html = menus_render(data);
        $('body').append(menus_html);
    };

    //当前页数
    var next_page;
    //总页数
    var total_page;
    var showTopic = function (topic_id, floor_host_only) {
        next_page = 1;
        getComments(topic_id, 1, 10, floor_host_only, function (data) {
            next_page++;
            var topic_load_render = $$template.compile(thread_tmpl.topic_tmpl.join('\r\n'));
            var load_html = topic_load_render(data);
            $('#sohu-changquan').html(load_html);
            //滚动分页效果
            $.when($page.getPageEvent('thread')).progress(function (a) {
                if (next_page <= total_page && a.type == 'thread')
                    nextPage(topic_id, floor_host_only);
            });
        });
    };

    var nextPage = function (topic_id, floor_host_only) {
        getComments(topic_id, next_page, 10, floor_host_only, function (data) {
            next_page++;
            var page_comments_render = $$template.compile(thread_tmpl.comment_list_tmpl.join('\r\n'));
            var comments_html = page_comments_render(data);
            $('.reply_cont').last().after(comments_html);
        });
    };

    // 只看楼主
    var viewFloorHost = function (topic_id) {
        showTopic(topic_id, true);
    };

    var getComments = function (topic_id, page_no, page_size, floor_host_only, render_fn) {
        var params =  {
            client_id: $$config.client_id,
            topic_id: topic_id,
            page_no: page_no,
            page_size: page_size
        };
        if (floor_host_only) {
            params.floor_host_only = true;
        }
        $.ajax({
            url: 'http://changyan.sohu.com/api/bbs/topic/comments',
            dataType: 'jsonp',
            jsonp: 'callback',
            jsonpCallback: 'loadTopicCallBack',
            scriptCharset: 'utf-8',
            cache: false,
            data: params,
            success: function (data) {
                total_page = data.total_page_no;
                //用户信息加载完成后在开始页面渲染
                $.when($$user.ready_trigger).done(function(){
                    data.login_user = $$user.cyan_user;
                    //图片域名
                    data.base_url = 'http://comment.bjcnc.img.sohucs.com';
                    //默认头像
                    data.default_img = 'http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png';
                    data.split_content = data.content.split(/[\r\n]/);
                    addReplyName(data.comments);
                    if (render_fn && typeof render_fn == 'function') {
                        render_fn(data);
                    }
                })
            }
        });
    };

    //显示树形结构列表的回复:XXX信息
    var addReplyName = function (comments) {
        var i, j;
        for (i in comments) {
            var comment = comments[i];
            //当前树中评论id和用户名的对应关系
            var comment_uname = {};
            //填充子评论的回复用户信息
            for (j in comment.comments) {
                var sub_comment = comment.comments[j];
                //缓存子评论的用户名信息
                comment_uname[sub_comment.comment_id] = sub_comment.passport.nickname;
                //填充当前子评论的回复用户信息
                sub_comment.reply_name = comment_uname[sub_comment.reply_id];
            }
        }
    };

    //帖子点赞
    var favourTopic = function (topic_id) {
        if($$user.cyan_user.error_code){
            $$login_module.showLoginLayer();
            return;
        }
        $.ajax({
            url: 'http://changyan.sohu.com/api/bbs/topic/favour',
            type: 'get',
            dataType: 'jsonp',
            jsonp: 'callback',
            data: {
                topic_id: topic_id
            },
            success: function (data) {
                var count = data.count;
                $('.wrap_favour em').html(count);
                $('#favour span').html('赞(' + count + ')');
                $('#thread_' + topic_id + ' .msg_ding em').html(count);
            }
        });
    };
    //举报帖子
    var reportTopic = function(topic_id){
        var user = $$user.cyan_user;
        if(!user || user.error_code){
            $$login_module.showLoginLayer();
            return;
        }
        $.ajax({
            url: 'http://changyan.sohu.com/api/bbs/topic/report',
            type: 'get',
            dataType: 'jsonp',
            jsonp: 'callback',
            data: {
                topicId: topic_id
            },
            success: function(data){
                if(!data.error_code){
                    $('.issue_succeed span').text('举报成功!');
                    $('.issue_succeed').show();
                }else{
                    $('.issue_succeed span').text('操作失败!');
                    $('.issue_succeed').show();
                }
                setTimeout(function(){
                    $('.issue_succeed').hide();
                    $('.more_select').hide();
                    $('#sohu_CQ_mark').hide();
                },1000);
            }
        });
    }
    addMenus();
    bindThreadEvent();
    var thread = {
        showTopic: showTopic,
        favourTopic: favourTopic
    };
    module.exports = thread;
});