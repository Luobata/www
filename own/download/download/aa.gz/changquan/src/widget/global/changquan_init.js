changquan.define(function (require, exports, module){

    var $ = require('src/lib/zepto.cyan.js');
    var $$config = require('src/widget/global/changquan_config.js');
    var $$utils = require('src/widget/utils/changquan_utils.js');
    var $$user = require('src/widget/global/changquan_user.js');
    var $$login_module = require('src/widget/user/changquan_login_module.js');
    var $$logout_module = require('src/widget/user/changquan_logout_module.js');
    var $$index_module = require('src/widget/bbs/changquan_index_module.js');
    var $$board_module = require('src/widget/bbs/changquan_board_module.js');
    var $$thread_module = require('src/widget/bbs/changquan_thread_module.js');
    var $$edit_thread_module = require('src/widget/bbs/changquan_edit_thread_module.js');
    var $$profile_module = require('src/widget/user/changquan_profile.js');
    var $$board_topic_manage = require('src/widget/moderator/changquan_board_topic_manage.js');
    var $$board_comment_manage = require('src/widget/moderator/changquan_comment_manage.js');

    var init_module = {
        init: function(){
            init();
        }
    }

    var init = function() {
        //设置页面内外边距
        $('body').css({padding: 0});
        $('body').css({margin: 0});
        //添加meta头信息，sb站长有可能不写这个东西，页面字体就会出问题
        var head = document.getElementsByTagName('head')[0];
        var meta = document.getElementsByName('viewport')[0];
        if (!meta) {
            meta = document.createElement('meta');
            meta.setAttribute('name', 'viewport');
            meta.setAttribute('content', 'initial-scale=1.0,user-scalable=no,minimum-scale=1.0,maximum-scale=1.0,width=device-width');
            head.appendChild(meta);
        }

        $(window).bind('popstate',loadPage);
        $$config.initConf();
        $.when($$config.ready_trigger).done(function(){
            $$login_module.initLogin();
            $$logout_module.initLogout();
            $$profile_module.initProfile();
            loadPage();  
        });

        //页面链接点击，无刷新改变浏览器地址栏
        var login_action = ['home', 'editthread'];
        $('[data-hash]').live('tap', function(){
            var hash = $(this).data('hash');
            var action = hash.split('_')[0];

            if($$utils.arrayContains(login_action, action)){
                //用户未登录
                var user_info = $$user.cyan_user;
                if(!user_info || user_info.error_code === 10207){
                    $$login_module.showLoginLayer();
                    return;
                }
            }
            
            var title = $(this).data('title');
            var href = window.location.href;
            href = href.replace(/#.*$/,'') + '#' + hash;
            window.history.pushState({}, title, href);
            //返回上级按钮点击
            var id = $(this).attr('id');
            switch(id){
                case 'back_to_index':
                    $$index_module.loadBoard();
                    return;
                case 'back_to_board':
                    var board_id = $(this).data('board-id');
                    $$board_module.loadTopics(board_id);
                    return;
                case 'back_to_boardtaudit':
                    var board_id = $(this).data('board-id');
                    $$board_topic_manage.boardTopicsManage(board_id, 'UNAUDIT');
                    return;
            }
        })
    }

    var loadPage = function() {
        var url = window.location.href.toString();
        var start = url.lastIndexOf('#');
        if (start != -1) {
            var load_params = url.substr(start + 1).split('_');
            switch (load_params[0]) {
                case 'board':
                    $$board_module.loadTopics(load_params[1]);
                    return;
                case 'topic':
                    $$thread_module.showTopic(load_params[1]);
                    return;
                case 'editthread':
                    $$edit_thread_module.editThread(load_params[1], load_params[2]);
                    return;
                case 'home':
                    $$profile_module.getUserReplies();
                    return;
                case 'boardtaudit':
                    $$board_topic_manage.boardTopicsManage(load_params[1], 'NORMAL');
                    return;
                case 'boardcaudit':
                    $$board_comment_manage.boardCommentsManage(load_params[1], 'UNAUDIT');
                    return;
                case 'threadcaudit':
                    $$board_comment_manage.threadCommentsManage(load_params[1], load_params[2], 'UNAUDIT');
                    return;
            }
        }
        $$index_module.loadBoard();
    }

    module.exports = init_module;
});