changquan.define(function (require, exports, module){
    
    var $ = require('src/lib/zepto.cyan.js');

    var conf = {
    	ready_trigger: $.Deferred(),
    	initConf: function(){
    		getConf();
    	},
        resourceRoot: undefined,
        client_id: undefined,
        backend_config: undefined,
        img_type: [ 'bmp', 'gif', 'jpeg', 'jpg', 'jpe', 'png' ]
    } 

	var getConf = function(){
        var params = {
            client_id: conf.client_id,
        };
        $.ajax({
            url: 'http://changyan.sohu.com/api/bbs/config',
            dataType: 'jsonp',
            jsonp: 'callback',
            jsonpCallback: 'loadConfig',
            scriptCharset: 'utf-8',
            cache: false,
            data: params,
            success: function(data) {
                $('#sohu-changquan').width('100%');
                conf.backend_config = data.config;
                //配置加载完成，触发事件，执行其他页面初始化操作
                conf.ready_trigger.resolve();
            },
        });
	}

    module.exports = conf;
});