changquan.define(function (require, exports, module){

    var $ = require('src/lib/zepto.cyan.js');

    var user = {
        ready_trigger: $.Deferred(),
        cyan_user: undefined,
        isv_user: undefined
    } 

    module.exports = user;
});