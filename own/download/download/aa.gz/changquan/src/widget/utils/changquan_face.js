/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true, white:true*/
/*global console: true, changquan: true, exports: true*/
changquan.define(function (require, exports, module) {

	var $$config = require('src/widget/global/changquan_config.js');

    var faces = {
        "/流汗": {img: "face09.png", turn: 1},
        "/大哭": {img: "face13.png", turn: 2},
        "/发怒": {img: "face03.png", turn: 3}, 
        "/鼓掌": {img: "face02.png", turn: 4},
        "/给力": {img: "face05.png", turn: 5},
        "/闭嘴": {img: "face17.png", turn: 6},
        "/憨笑": {img: "face06.png", turn: 7},
        "/色": {img: "face04.png", turn: 8},
        "/强": {img: "face10.png", turn: 9},
        "/弱": {img: "face11.png", turn: 10}, 
        "/鄙视": {img: "face15.png", turn: 11},
        "/可爱": {img: "face07.png", turn: 12},
        "/惊讶": {img: "face19.png", turn: 13},
        "/疑问": {img: "face14.png", turn: 14},
        "/抓狂": {img: "face08.png", turn: 15},
        "/浮云": {img: "face20.png", turn: 16},
        "/可怜": {img: "face18.png", turn: 17},
        "/玫瑰": {img: "face12.png", turn: 18},
        "/钱": {img: "face16.png", turn: 19},
        "/握手": {img: "face22.png", turn: 20},
        "/拳头": {img: "face23.png", turn: 21},
        "/酒": {img: "face24.png", turn: 22},
        "/奋斗": {img: "face01.png", turn: 23},
        "/打酱油": {img: "face21.png", turn: 24}
    };

	var face = {
		face_base_url: $$config.resourceRoot + 'src/css/main/images/face/',
		faces: faces,
		decodeFaceContent: function(content){
			var conFace = content.replace(/\[([^\]]+)\]+?/g, function (all, $1) {
                var img_data = faces[$1] && faces[$1].img;
                if(!img_data){
                    return all;
                }
                return '<img src="' + face.face_base_url + img_data +'">';
            });
            return conFace;
		}
	};

	module.exports = face;
});