changquan.define(function (require, exports, module) {
	var $ = require('src/lib/zepto.cyan.js');

	var page_type;
	var page_e = $.Deferred();
	//手机上拉翻页效果
	var start = [];
    $(document).live('touchmove', function(e){
    	if ($(document).height() - $(window).height() - $(window).scrollTop() <= 10 && start.length == 0) {
            start[0] = e.touches[0].clientX;
            start[1] = e.touches[0].clientY;
        }
    }).live('touchend', function (e) {
    	if ($(document).height() - $(window).height() - $(window).scrollTop() <= 10) {
	        var end = [];
	        end[0] = e.changedTouches[0].clientX;
	        end[1] = e.changedTouches[0].clientY;
	        if(end[1] - start[1] < -200){
	        	page_e.notifyWith(this, [{type: page_type}]);
	        }
	    }
	    start = [];
    });
    //方便pc下测试翻页
    $(document).live('mousewheel', function(e){
    	if(e.wheelDeltaY < 0 && $(document).height() - $(window).height() - $(window).scrollTop() <= 10){
    		page_e.notifyWith(this, [{type: page_type}]);
    	}
    });

    var page = {
    	getPageEvent: function(type){
    		page_type = type;
    		return page_e;
    	}
	};
	module.exports = page;
});