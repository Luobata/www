changquan.define(function (require, exports, module){
    //格式化日期
    var getFormatDate = function(l) {
        var now = new Date();
        var date = new Date(l);
        //一分钟内
        if(now.getTime() - l <= 60 * 1000){
            return '刚刚';
        }
        //一分钟到60分钟
        if(now.getTime() - l <= 3600 * 1000){
            var minute = Math.abs(l - now.getTime())/1000/60;
            var minute = Math.round(minute);
            return minute + '分钟之前';
        }
        //一分钟到60分钟
        if(now.getTime() - l <= 3600 * 1000 * 24){
            return formatDate(date, 'hh:mm');
        }
        return formatDate(date, 'MM月dd日');
    }
    var formatDate = function(date, format) {
        var o = {
            "M+": date.getMonth() + 1,
            "d+": date.getDate(),
            "h+": date.getHours(),
            "m+": date.getMinutes(),
            "s+": date.getSeconds(),
            "q+": Math.floor((date.getMonth() + 3) / 3),
            "S": date.getMilliseconds()
        }
        if (/(y+)/.test(format)) {
            format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(format)) {
                format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
            }
        }
        return format;
    }

    var arrayContains = function(array, a){
        for(var i = 0; i < array.length; i++){
            if(array[i] == a){
                return true;
            }
        }
        return false;
    }

    var util = {
        getFormatDate: getFormatDate,
        arrayContains: arrayContains
    }

    module.exports = util;
});