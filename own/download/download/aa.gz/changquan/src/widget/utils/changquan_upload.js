changquan.define(function (require, exports, module) {

    var $ = require('src/lib/zepto.cyan.js');
    var $$config = require('src/widget/global/changquan_config.js');

    var upload = function(file) {
        var deferred = $.Deferred();
        var params = {
            type: 'json'
        };
        if (window.FormData) {
            var suffix = file.name.replace(/^.+\.([^.]+)/, "$1").toLowerCase();
            for (var i in $$config.img_type) {
                var type = $$config.img_type[i];
                if (suffix == type) {
                    var fd = new FormData();
                    fd.append('file', file);
                    for(var key in params){
                        fd.append(key,params[key]);
                    }

                    var xhr = new XMLHttpRequest();
                    var upload_url = 'http://changyan.sohu.com/api/2/comment/attachment';
                    xhr.open("POST", upload_url, true);
                    xhr.setRequestHeader('Accept', '*/*');
                    xhr.onload = function() {
                        if (xhr.status == 200) {
                            if (xhr.responseText) {
                                var json = $.parseJSON(xhr.responseText);
                                deferred.resolveWith(this, [json]);
                            }
                        } else {
                            deferred.rejectWith(this, [{error_msg:'上传出错'}]);
                        }
                    };
                    xhr.send(fd);
                    return deferred;
                }
            }
            alert('文件类型不合法');
        }
    };

    var uploader = {
        upload: upload
    };

    module.exports = uploader;
});  