changquan.define(function (require, exports, module) {
    // 引入模块
    var $ = require('src/lib/zepto.cyan.js');
    var $$template = require('src/lib/template.cyan.js');
    var $$utils = require('src/widget/utils/changquan_utils.js');

    var $$config = require('src/widget/global/changquan_config.js');
    var params = window.changquan && window.changquan._tmp && window.changquan._tmp.params || {};
    window.changquan._tmp = undefined;
    $$config.client_id = params.client_id;
    $$config.resourceRoot = params.resourceRoot;

    var $$init_module = require('src/widget/global/changquan_init.js');
    var $$face_utils = require('src/widget/utils/changquan_face.js');

    var init = function () {
       
        $$template.helper('getFormatDate', $$utils.getFormatDate);
        $$template.helper('decodeFaceContent', $$face_utils.decodeFaceContent);
        $$template.helper('$escape', $$template.utils.$escape);
        $$template.helper('arrayContains', $$utils.arrayContains);
        $$init_module.init();
    };

    init();
});
