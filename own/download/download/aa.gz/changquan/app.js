/**
 * @author liangxiao
 * @version [v1.0]
 * @description SeaJs Loader
 */

/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 80, plusplus: true, sloppy: true*/
(function () {
    'use strict';

    var modules = {};

    function isFunction(obj) {
        return Object.prototype.toString.call(obj) === '[object Function]';
    }

    function define(name, deps, factory) {
        if (modules[name]) {
            throw new Error('Module ' + name + ' has been defined already.');
        }

        if (isFunction(deps)) {
            factory = deps;
        }

        modules[name] = {
            factory: factory,
            inited: false,
            exports: null
        };
    }

    function run(name) {
        var module, exports, mod, ret;

        module = modules[name];
        exports = {};
        mod = {};

        if (isFunction(module.factory)) {
            ret = module.factory.call(undefined, require, exports, mod);
            if (ret !== undefined) {
                module.exports = ret;
            } else {
                if (mod.hasOwnProperty('exports')) {
                    module.exports = mod.exports;
                } else {
                    module.exports = exports;
                }
            }
        } else {
            throw new Error('Module ' + name + ' has no factory.');
        }

        module.inited = true;
    }

    function require(name) {
        var module;

        module = modules[name];

        if (!module) {
            throw new Error('Module ' + name + ' is not defined.');
        }

        if (module.inited === false) {
            run(name);
        }

        return module.exports;
    }

    define("D:/workspaces/cyan/changquan/tmp-build/widget/moderator/changquan_comment_manage.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$template = require("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var comment_audit_tmpl = {};
        comment_audit_tmpl.comment_audit_tab = [ '\t\t<ul id="comment_audit_tab" class="nav nav-pills" role="tablist" data-comment-type="{{comment_status}}">', '\t\t\t<li data-comment-type="AUDITED" {{if comment_status == "AUDITED"}}class="active"{{/if}}><a href="javascript:void(0)">已审核</a></li>', '\t\t\t<li data-comment-type="UNAUDIT" {{if comment_status == "UNAUDIT"}}class="active"{{/if}}><a href="javascript:void(0)">未审核</a></li>', '\t\t\t<li data-comment-type="DELETED" {{if comment_status == "DELETED"}}class="active"{{/if}}><a href="javascript:void(0)">已删除</a></li>', "\t\t</ul>" ];
        comment_audit_tmpl.comment_list = [ "\t\t{{each comments as comment index}}", '\t\t\t<div class="media normal comment" data-comment-id="{{comment.comment_id}}" data-topic-id="{{comment.topic_id}}">', "\t\t\t\t{{if comment.attachment}}", '\t\t\t\t<a class="pull-left" href="#">', '\t\t\t\t\t<img src="{{comment.attachment.replace(base_url, base_url + \'/c_fill,w_64,h_64\')}}" style="width: 4em; height: 4em;">', "\t\t\t\t</a>", "\t\t\t\t{{/if}}", '\t\t\t\t<div class="media-body">', "\t\t\t\t\t{{if show_topic}}", '\t\t\t\t\t<h4 class="media-heading">帖子：{{comment.topic_title}}</h4>', "\t\t\t\t\t评论内容：", "\t\t\t\t\t{{/if}}", "\t\t\t\t\t{{comment.content.substring(0,50)}}", "\t\t\t\t</div>", '\t\t\t\t<div class="action-menu">', '\t\t\t\t\t{{if comment_status == "UNAUDIT"}}', "\t\t\t\t\t\t<!--{{col = 2}}-->", "\t\t\t\t\t{{else}}", "\t\t\t\t\t\t<!--{{col = 1}}-->", "\t\t\t\t\t{{/if}}", '\t\t\t\t\t{{if comment_status != "AUDITED"}}', '\t\t\t\t\t<span class="label label-success comment-pass" style="width:{{90/col}}%;display:inline-block">通过</span>', "\t\t\t\t\t{{/if}}", '\t\t\t\t\t{{if comment_status != "DELETED"}}', '\t\t\t\t\t<span class="label label-danger comment-del" style="width:{{90/col}}%;display:inline-block">删除</span>', "\t\t\t\t\t{{/if}}", "\t\t\t\t</div>", "\t\t\t</div>", "\t\t{{/each}}", "\t\t{{if comments.length > 0}}", '\t\t<div class="text-center margin-top1">', '\t\t\t<button id="comment_audit_btn" class="btn btn-primary" style="width:100%">确&nbsp;&nbsp;&nbsp;&nbsp;定</button>', "\t\t</div>", '\t\t<div class="text-center">', '\t\t\t<ul id="comment-pager" class="pagination">', '\t\t\t\t<li {{if page_no <= 1}}class="disabled"{{/if}}><a class="pre" href="javascript:void(0)">上一页</a></li>', '\t\t\t\t<li class="disabled"><a href="javascript:void(0)">{{page_no}}</a></li>', '\t\t\t\t<li {{if page_no >= board.total_page}}class="disabled"{{/if}}><a class="next" href="javascript:void(0)">下一页</a></li>', "\t\t\t</ul>", "\t\t</div>", "\t\t{{/if}}" ];
        comment_audit_tmpl.board_comment = [ '   <div id="sohu_CQ_moderator">', '\t\t<nav class="navbar-fixed-top" role="navigation">', '\t\t\t<a id="back_to_index" data-hash="" data-tile="{{config.bbs_name}}"', '\t\t\t\tclass="navbar-left">', "\t\t\t\t返回", "\t\t\t</a>", '\t\t\t<a id="thread_audit" data-hash="boardtaudit_{{board.board_id}}" data-title="{{board.name}}"', '\t\t\t\tclass="navbar-right" href="javascript:void(0)">', "\t\t\t\t帖子列表", "\t\t\t</a>", '      \t\t<p class="navbar-text" data-board-id="{{board.board_id}}">{{board.name}}</p>', "\t\t</nav>", comment_audit_tmpl.comment_audit_tab.join("\r\n"), comment_audit_tmpl.comment_list.join("\r\n"), "   </div>" ];
        comment_audit_tmpl.thread_comment = [ '   <div id="sohu_CQ_moderator">', '\t\t<nav class="navbar-fixed-top" role="navigation">', '\t\t\t<a id="back_to_boardtaudit" data-hash="boardtaudit_{{board_id}}" class="navbar-left"', '\t\t\t\tdata-board-id="{{board_id}}">', "\t\t\t\t返回", "\t\t\t</a>", '      \t\t<p class="navbar-text" data-topic-id="{{thread.thread_id}}">{{thread.title}}</p>', "\t\t</nav>", comment_audit_tmpl.comment_audit_tab.join("\r\n"), comment_audit_tmpl.comment_list.join("\r\n"), "   </div>" ];
        var initBoardManageEvent = function() {
            $("#comment_audit_tab li").live("tap", function() {
                page_no = 1;
                var category = $(this).data("comment-type");
                var board_id = $(".navbar-text").data("board-id");
                var topic_id = $(".navbar-text").data("topic-id");
                if (board_id) {
                    boardCommentsManage(board_id, category);
                }
                if (topic_id) {
                    threadCommentsManage(cur_board_id, topic_id, category);
                }
                return false;
            });
            $(".comment-pass").live("tap", function() {
                $(this).parents(".media").removeClass("del");
                $(this).parents(".media").toggleClass("pass");
            });
            $(".comment-del").live("tap", function() {
                $(this).parents(".media").removeClass("pass");
                $(this).parents(".media").toggleClass("del");
            });
            $("#comment_audit_btn").live("tap", function() {
                commentAudit();
            });
            $("#comment-pager .pre").live("tap", function() {
                if (page_no <= 1) {
                    return;
                }
                var category = $("#comment_audit_tab li.active").data("comment-type");
                var board_id = $(".navbar-text").data("board-id");
                var topic_id = $(".navbar-text").data("topic-id");
                page_no--;
                if (board_id) {
                    boardCommentsManage(board_id, category);
                }
                if (topic_id) {
                    threadCommentsManage(cur_board_id, topic_id, category);
                }
                return false;
            });
            $("#comment-pager .next").live("tap", function() {
                if (page_no >= total_page) {
                    return;
                }
                var category = $("#comment_audit_tab li.active").data("comment-type");
                var board_id = $(".navbar-text").data("board-id");
                var topic_id = $(".navbar-text").data("topic-id");
                page_no++;
                if (board_id) {
                    boardCommentsManage(board_id, category);
                }
                if (topic_id) {
                    threadCommentsManage(cur_board_id, topic_id, category);
                }
                return false;
            });
        };
        var page_no = 1;
        var total_page;
        var boardCommentsManage = function(board_id, category) {
            var params = {
                bid: board_id,
                page_no: page_no,
                page_size: 10
            };
            $.ajax({
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "loadBoardManagementCallBack",
                url: "http://changyan.sohu.com/api/bbs/admin/board/comments/" + category,
                scriptCharset: "utf-8",
                cache: false,
                data: params,
                success: function(data) {
                    data.config = $$config.backend_config;
                    data.base_url = "http://comment.bjcnc.img.sohucs.com";
                    data.page_no = page_no;
                    data.show_topic = true;
                    total_page = data.board.total_page;
                    var board_comments_render = $$template.compile(comment_audit_tmpl.board_comment.join("\r\n"));
                    var load_html = board_comments_render(data);
                    $("#sohu-changquan").html(load_html);
                }
            });
        };
        var cur_board_id;
        var threadCommentsManage = function(board_id, topic_id, category) {
            cur_board_id = board_id;
            var params = {
                bid: board_id,
                tid: topic_id,
                page_no: page_no,
                page_size: 10
            };
            $.ajax({
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "loadBoardManagementCallBack",
                url: "http://changyan.sohu.com/api/bbs/admin/topic/" + category,
                scriptCharset: "utf-8",
                cache: false,
                data: params,
                success: function(data) {
                    data.board_id = board_id;
                    data.base_url = "http://comment.bjcnc.img.sohucs.com";
                    data.page_no = page_no;
                    total_page = data.board.total_page;
                    var thread_comments_render = $$template.compile(comment_audit_tmpl.thread_comment.join("\r\n"));
                    var load_html = thread_comments_render(data);
                    $("#sohu-changquan").html(load_html);
                }
            });
        };
        var commentAudit = function() {
            var comments = [];
            var board_id = $(".navbar-text").data("board-id");
            $(".media").each(function() {
                if ($(this).hasClass("del")) {
                    var comment = {};
                    comment.cid = $(this).data("comment-id");
                    comment.tid = $(this).data("topic-id");
                    comment.status = 2;
                    comments.push(comment);
                }
                if ($(this).hasClass("pass")) {
                    var comment = {};
                    comment.cid = $(this).data("comment-id");
                    comment.tid = $(this).data("topic-id");
                    comment.status = 3;
                    comments.push(comment);
                }
            });
            $.ajax({
                type: "POST",
                url: "http://changyan.sohu.com/api/bbs/admin/comment/audit?bid=" + board_id,
                cache: false,
                crossDomain: true,
                xhrFields: {
                    withCredentials: true
                },
                contentType: "application/json",
                data: JSON.stringify(comments),
                success: function(data) {
                    var category = $("#comment_audit_tab").data("comment-type");
                    if (!data.error_code) {
                        boardCommentsManage(board_id, category);
                    } else {
                        alert("帖子审核失败");
                    }
                }
            });
        };
        initBoardManageEvent();
        var boardThreadAudit = {
            boardCommentsManage: boardCommentsManage,
            threadCommentsManage: threadCommentsManage
        };
        module.exports = boardThreadAudit;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/moderator/changquan_board_topic_manage.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$template = require("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var $$board_comment_manage = require("D:/workspaces/cyan/changquan/tmp-build/widget/moderator/changquan_comment_manage.js");
        var board_thread_audit_tmpl = [ '   <div id="sohu_CQ_moderator">', '\t\t<nav class="navbar-fixed-top" role="navigation">', '\t\t\t<a id="back_to_index" data-hash="" data-tile="{{config.bbs_name}}" class="navbar-left" data-hash="">', "\t\t\t\t返回", "\t\t\t</a>", '\t\t\t<a id="comment_audit" data-hash="boardcaudit_{{board.board_id}}" data-title="{{board.name}}"', '\t\t\t\tclass="navbar-right" href="javascript:void(0)">', "\t\t\t\t评论列表", "\t\t\t</a>", '      \t\t<p class="navbar-text" data-board-id="{{board.board_id}}">{{board.name}}</p>', "\t\t</nav>", '\t\t<ul id="thread_audit_tab" class="nav nav-pills" role="tablist" data-thread-type="{{topic_status}}">', '\t\t\t<li data-thread-type="NORMAL" {{if topic_status == "NORMAL"}}class="active"{{/if}}><a href="javascript:void(0)">已审核</a></li>', '\t\t\t<li data-thread-type="UNAUDIT" {{if topic_status == "UNAUDIT"}}class="active"{{/if}}><a href="javascript:void(0)">未审核</a></li>', '\t\t\t<li data-thread-type="DELETED" {{if topic_status == "DELETED"}}class="active"{{/if}}><a href="javascript:void(0)">已删除</a></li>', "\t\t</ul>", "\t\t{{each threads as thread index}}", '\t\t\t<div class="media normal" data-hash="threadcaudit_{{board.board_id}}_{{thread.thread_id}}" ', '\t\t\t\tdata-topic-id="{{thread.thread_id}}">', '\t\t\t\t<div class="media-main">', "\t\t\t\t\t{{if thread.attachment}}", '\t\t\t\t\t<a class="pull-left" href="#">', '\t\t\t\t\t\t<img src="{{thread.attachment.replace(base_url, base_url + \'/c_fill,w_64,h_64\')}}" style="width: 4em; height: 4em;">', "\t\t\t\t\t</a>", "\t\t\t\t\t{{/if}}", '\t\t\t\t\t<div class="media-body">', '\t\t\t\t\t\t<h4 class="media-heading">{{thread.title}}</h4>', "\t\t\t\t\t\t{{#thread.content.substring(0,50)}}", "\t\t\t\t\t</div>", "\t\t\t\t</div>", '\t\t\t\t<div class="action-menu">', '\t\t\t\t\t{{if topic_status == "UNAUDIT" || topic_status == "NORMAL"}}', "\t\t\t\t\t\t<!--{{col = 2}}-->", "\t\t\t\t\t{{else}}", "\t\t\t\t\t\t<!--{{col = 1}}-->", "\t\t\t\t\t{{/if}}", '\t\t\t\t\t{{if topic_status != "NORMAL"}}', '\t\t\t\t\t<span class="label label-success thread-pass" style="width:{{90/col}}%;display:inline-block">通过</span>', "\t\t\t\t\t{{/if}}", '\t\t\t\t\t{{if topic_status != "DELETED"}}', '\t\t\t\t\t<span class="label label-danger thread-del" style="width:{{90/col}}%;display:inline-block">删除</span>', "\t\t\t\t\t{{/if}}", '\t\t\t\t\t{{if topic_status == "NORMAL"}}', "\t\t\t\t\t\t{{if !thread.is_top}}", '\t\t\t\t\t\t<span class="label label-warning thread-top" style="width:{{90/col}}%;display:inline-block">置顶</span>', "\t\t\t\t\t\t{{else}}", '\t\t\t\t\t\t<span class="label label-warning thread-untop" style="width:{{90/col}}%;display:inline-block">取消置顶</span>', "\t\t\t\t\t\t{{/if}}", "\t\t\t\t\t{{/if}}", "\t\t\t\t</div>", "\t\t\t</div>", "\t\t{{/each}}", "\t\t{{if threads.length > 0}}", '\t\t<div class="text-center margin-top1">', '\t\t\t<button id="thread_audit_btn" class="btn btn-primary" style="width:100%">确&nbsp;&nbsp;&nbsp;&nbsp;定</button>', "\t\t</div>", '\t\t<div class="text-center">', '\t\t\t<ul id="thread-pager" class="pagination">', '\t\t\t\t<li {{if page_no <= 1}}class="disabled"{{/if}}><a class="pre" href="javascript:void(0)">上一页</a></li>', '\t\t\t\t<li class="disabled"><a href="javascript:void(0)">{{page_no}}</a></li>', '\t\t\t\t<li {{if page_no >= board.total_page}}class="disabled"{{/if}}><a class="next" href="javascript:void(0)">下一页</a></li>', "\t\t\t</ul>", "\t\t</div>", "\t\t{{/if}}", "   </div>" ];
        var initBoardManageEvent = function() {
            $("#comment_audit").live("tap", function() {
                var board_id = $(".navbar-text").data("board-id");
                $$board_comment_manage.boardCommentsManage(board_id, "UNAUDIT");
            });
            $("#thread_audit").live("tap", function() {
                var board_id = $(".navbar-text").data("board-id");
                boardTopicsManage(board_id, "UNAUDIT");
            });
            $("#thread_audit_tab li").live("tap", function() {
                page_no = 1;
                var category = $(this).data("thread-type");
                var board_id = $(".navbar-text").data("board-id");
                boardTopicsManage(board_id, category);
                return false;
            });
            $(".thread-pass").live("tap", function() {
                $(this).parents(".media").removeClass("del");
                $(this).parents(".media").toggleClass("pass");
            });
            $(".thread-del").live("tap", function() {
                $(this).parents(".media").removeClass("pass");
                $(this).parents(".media").toggleClass("del");
            });
            $("#thread_audit_btn").live("tap", function() {
                topicAudit();
            });
            $("#thread-pager .pre").live("tap", function() {
                if (page_no <= 1) {
                    return;
                }
                var category = $("#thread_audit_tab li.active").data("thread-type");
                var board_id = $(".navbar-text").data("board-id");
                page_no--;
                boardTopicsManage(board_id, category);
                return false;
            });
            $("#thread-pager .next").live("tap", function() {
                if (page_no >= total_page) {
                    return;
                }
                var category = $("#thread_audit_tab li.active").data("thread-type");
                var board_id = $(".navbar-text").data("board-id");
                page_no++;
                boardTopicsManage(board_id, category);
                return false;
            });
            $(".media").live("tap", function(e) {
                if ($(e.target).hasClass("label")) {
                    return;
                }
                var board_id = $(".navbar-text").data("board-id");
                var topic_id = $(this).data("topic-id");
                $$board_comment_manage.threadCommentsManage(board_id, topic_id, "UNAUDIT");
            });
            $(".thread-top").live("tap", function() {
                var tid = $(this).parents(".media").data("topic-id");
                changeThreadTop(tid, "ADD", this);
            });
            $(".thread-untop").live("tap", function() {
                var tid = $(this).parents(".media").data("topic-id");
                changeThreadTop(tid, "CANCEL", this);
            });
        };
        var changeThreadTop = function(tid, op, obj) {
            var board_id = $(".navbar-text").data("board-id");
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/admin/thread/top/" + op,
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "threadTopCallBack",
                scriptCharset: "utf-8",
                cache: false,
                data: {
                    bid: board_id,
                    tid: tid
                },
                success: function(data) {
                    if (!data.error_code) {
                        if (op == "ADD") {
                            $(obj).removeClass("thread-top");
                            $(obj).addClass("thread-untop");
                            $(obj).text("取消置顶");
                        } else {
                            $(obj).removeClass("thread-untop");
                            $(obj).addClass("thread-top");
                            $(obj).text("置顶");
                        }
                    } else {
                        alert("操作失败");
                    }
                },
                error: function() {
                    alert("操作失败");
                }
            });
        };
        var page_no = 1;
        var total_page;
        var boardTopicsManage = function(board_id, category) {
            var params = {
                bid: board_id,
                page_no: page_no,
                page_size: 10
            };
            $.ajax({
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "loadBoardManagementCallBack",
                url: "http://changyan.sohu.com/api/bbs/admin/board/topics/" + category,
                scriptCharset: "utf-8",
                cache: false,
                data: params,
                success: function(data) {
                    data.config = $$config.backend_config;
                    data.base_url = "http://comment.bjcnc.img.sohucs.com";
                    data.page_no = page_no;
                    total_page = data.board.total_page;
                    var topic_load_render = $$template.compile(board_thread_audit_tmpl.join("\r\n"));
                    var load_html = topic_load_render(data);
                    $("#sohu-changquan").html(load_html);
                }
            });
        };
        var topicAudit = function() {
            var topics = [];
            var board_id = $(".navbar-text").data("board-id");
            $(".media").each(function() {
                if ($(this).hasClass("del")) {
                    var topic = {};
                    topic.id = $(this).data("topic-id");
                    topic.status = 2;
                    topics.push(topic);
                }
                if ($(this).hasClass("pass")) {
                    var topic = {};
                    topic.id = $(this).data("topic-id");
                    topic.status = 3;
                    topics.push(topic);
                }
            });
            $.ajax({
                type: "POST",
                url: "http://changyan.sohu.com/api/bbs/admin/topic/audit?bid=" + board_id,
                cache: false,
                crossDomain: true,
                xhrFields: {
                    withCredentials: true
                },
                contentType: "application/json",
                data: JSON.stringify(topics),
                success: function(data) {
                    var category = $("#thread_audit_tab").data("thread-type");
                    if (!data.error_code) {
                        boardTopicsManage(board_id, category);
                    } else {
                        alert("帖子审核失败");
                    }
                }
            });
        };
        initBoardManageEvent();
        var boardThreadAudit = {
            boardTopicsManage: boardTopicsManage
        };
        module.exports = boardThreadAudit;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/user/changquan_profile.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$template = require("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var $$user = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_user.js");
        var $$thread_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_thread_module.js");
        var $page = require("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_page.js");
        var profile_tmpl = {};
        profile_tmpl.user_info = [ '\t\t<section class="top_bar_site">', '\t\t\t<div class="top_bar_bg"></div>', '\t\t\t<div class="top_bar_wrap">', '\t\t\t\t<div class="bar_left">', '\t\t\t\t\t<div class="bar_left_prev">', '\t\t\t\t\t\t<span id="back_to_index" data-hash="">上一页</span>', "\t\t\t\t\t</div>", "\t\t\t\t</div>", '\t\t\t\t<div class="bar_center">', '\t\t\t\t\t<h2 class="bar_center_name">个人中心</h2>', "\t\t\t\t</div>", "\t\t\t</div>", "\t\t</section>", '\t\t<section class="user_msg">', '\t\t\t<div class="clear_public msg_wrap">', '\t\t\t\t<div class="wrap_left"><img src="{{user.img_url || default_img}}" alt=""/></div>', '\t\t\t\t<div class="wrap_right">', '\t\t\t\t\t<div class="clear_public right_name_level">', '\t\t\t\t\t\t<span class="right_name"><em>{{user.nickname}}</em>', '\t\t\t\t\t\t</span><span class="right_level level_{{user.userScore.level}}"></span>', "\t\t\t\t\t</div>", '\t\t\t\t\t<div class="right_num right_card_num"><em>帖子：{{user.bbs_thread_count}}</em></div>', '\t\t\t\t\t<div class="right_num right_comment_num"><em>评论：{{user.bbs_post_reply_count}}</em></div>', "\t\t\t\t</div>", "\t\t\t</div>", "\t\t</section>" ];
        profile_tmpl.home_page_tabs = [ '\t\t\t<div class="msg_head" id="user_page_head">', "\t\t\t\t<ul>", '\t\t\t\t\t<li id="user-reply-list" {{if data_type == "replies"}}class="now"{{/if}}><span>最新回复</span></li>', '\t\t\t\t\t<li id="user-topic-list" {{if data_type == "topics"}}class="now"{{/if}}><span>我的帖子</span></li>', '\t\t\t\t\t<li id="user-comment-list" {{if data_type == "comments"}}class="now"{{/if}}><span>我的评论</span></li>', "\t\t\t\t</ul>", "\t\t\t</div>" ];
        profile_tmpl.reply_list_tmpl = [ "\t{{each replies as reply index}}", '\t<div class="clear_public reply_lump" data-hash="thread_{{reply.thread_id}}" data-title="{{reply.thread_title}}"', '\t\t\tdata-topic-id="{{reply.thread_id}}">', '\t\t<div class="lump_left"><img src="{{reply.user_img || default_img}}" alt=""/></div>', '\t\t<div class="lump_right">', '\t\t\t<div class="clear_public lump_head"><span class="head_name"><em>{{reply.user_nick}}</em></span><span class="head_level level_1"></span></div>', '\t\t\t<p class="lump_text"><span>{{#reply.comment_content | $escape | decodeFaceContent}}</span></p>', '\t\t\t<p class="reply_my_comment"><span>', "\t\t\t{{if reply.reply_id}}", "\t\t\t\t回复我的评论：{{reply.reply_content}}", "\t\t\t{{else}}", "\t\t\t\t回复我的帖子：{{reply.thread_title}}", "\t\t\t{{/if}}", "\t\t\t</span></p>", '\t\t\t<div class="clear_public lump_from_date">', '\t\t\t\t<div class="lump_from"><span>来自{{reply.board_name}}圈</span></div>', '\t\t\t\t<div class="lump_date"><span>{{reply.time | getFormatDate}}</span></div>', "\t\t\t</div>", "\t\t</div>", "\t</div>", "\t{{/each}}" ];
        profile_tmpl.user_replies_tmpl = [ '\t<div id="sohu_CQ_page5" class="reset_public wrapper_CQ_public">', profile_tmpl.user_info.join("\r\n"), '\t\t<section class="msg_cont">', profile_tmpl.home_page_tabs.join("\r\n"), '\t\t\t<div class="msg_body" id="user_page_body">', '\t\t\t\t<div class="body_block now">', '\t\t\t\t\t<div class="block_reply">', "\t\t\t\t\t{{if replies.length > 0}}", profile_tmpl.reply_list_tmpl.join("\r\n"), "\t\t\t\t\t{{/if}}", "\t\t\t\t\t</div>", '\t\t\t\t\t<section class="lump_loading" style="display:none">', '\t\t\t\t\t\t<div class="loading_wrap"><span class="loading_icon"></span><em>正在加载</em></div>', "\t\t\t\t\t</section>", "\t\t\t\t</div>", "\t\t\t</div>", "\t\t</section>", "\t</div>" ];
        profile_tmpl.topic_list_tmpl = [ "\t{{each threads as thread index}}", '\t<div class="card_lump" id="my_thread_{{thread.thread_id}}" data-hash="thread_{{thread.thread_id}}" ', '\t\t\tdata-title="{{thread.title}}" data-topic-id="{{thread.thread_id}}">', '\t\t<p class="lump_text"><span>{{thread.title}}</span></p>', "\t\t{{if thread.attachment}}", '\t\t<div class="cont_pic"><img src="{{thread.attachment}}" alt=""/></div>', "\t\t{{/if}}", '\t\t<div class="clear_public lump_date_action">', '\t\t\t<div class="lump_date"><span>{{thread.create_time | getFormatDate}}</span></div>', '\t\t\t<div class="lump_action">', '\t\t\t\t<span class="action_ding">', '\t\t\t\t\t<i class="ding_icon"></i><em>{{thread.support_count}}</em>', "\t\t\t\t</span>", '\t\t\t\t<span class="action_comment">', '\t\t\t\t\t<i class="comment_icon"></i><em>{{thread.cmt_sum}}</em>', "\t\t\t\t</span>", '\t\t\t\t<span class="wrap_del" data-topic-id="{{thread.thread_id}}"><em>删除</em></span>', "\t\t\t</div>", "\t\t</div>", "\t</div>", "\t{{/each}}" ];
        profile_tmpl.user_topics_tmpl = [ '\t<div id="sohu_CQ_page5" class="reset_public wrapper_CQ_public">', profile_tmpl.user_info.join("\r\n"), '\t\t<section class="msg_cont">', profile_tmpl.home_page_tabs.join("\r\n"), '\t\t\t<div class="msg_body" id="user_page_body">', '\t\t\t\t<div class="body_block now">', '\t\t\t\t\t<div class="block_card">', "\t\t\t\t\t{{if threads.length > 0}}", profile_tmpl.topic_list_tmpl.join("\r\n"), "\t\t\t\t\t{{/if}}", "\t\t\t\t\t</div>", '\t\t\t\t\t<section class="lump_loading" style="display:none">', '\t\t\t\t\t\t<div class="loading_wrap"><span class="loading_icon"></span><em>正在加载</em></div>', "\t\t\t\t\t</section>", "\t\t\t\t</div>", "\t\t\t</div>", "\t\t</section>", "\t</div>" ];
        profile_tmpl.comment_list_tmpl = [ "\t{{each comments as comment index}}", '\t<div class="comment_lump" id="my_comment_{{comment.comment_id}}" data-hash="thread_{{comment.thread_id}}" ', '\t\t\tdata-title="{{comment.thread_title}}}" data-topic-id="{{comment.thread_id}}">', '\t\t<p class="lump_text"><span>{{#comment.content | $escape | decodeFaceContent}}</span></p>', "\t\t{{if comment.attachment}}", '\t\t<div class="cont_pic"><img src="{{comment.attachment}}" alt=""/></div>', "\t\t{{/if}}", '\t\t<div class="clear_public lump_msg">', '\t\t\t<div class="msg_from"><span><em>{{comment.thread_title}}}</em></span></div>', '\t\t\t<div class="msg_date_del">', '\t\t\t\t<span class="date"><em>{{comment.create_time | getFormatDate}}</em></span>', '\t\t\t\t<span class="del" data-comment-id="{{comment.comment_id}}"><em>删除</em></span>', "\t\t\t</div>", "\t\t</div>", "\t</div>", "\t{{/each}}" ];
        profile_tmpl.user_comments_tmpl = [ '\t<div id="sohu_CQ_page5" class="reset_public wrapper_CQ_public">', profile_tmpl.user_info.join("\r\n"), '\t\t<section class="msg_cont">', profile_tmpl.home_page_tabs.join("\r\n"), '\t\t\t<div class="msg_body" id="user_page_body">', '\t\t\t\t<div class="body_block now">', '\t\t\t\t\t<div class="block_comment">', "\t\t\t\t\t{{if comments.length > 0}}", profile_tmpl.comment_list_tmpl.join("\r\n"), "\t\t\t\t\t{{/if}}", "\t\t\t\t\t</div>", '\t\t\t\t\t<section class="lump_loading" style="display:none">', '\t\t\t\t\t\t<div class="loading_wrap"><span class="loading_icon"></span><em>正在加载</em></div>', "\t\t\t\t\t</section>", "\t\t\t\t</div>", "\t\t\t</div>", "\t\t</section>", "\t</div>" ];
        var initProfileEvent = function() {
            $("#user-topic-list").live("tap", function() {
                initUserTopics();
                return false;
            });
            $("#user-comment-list").live("tap", function() {
                initUserComments();
                return false;
            });
            $("#user-reply-list").live("tap", function() {
                initUserReplies();
                return false;
            });
            $(".reply_lump,.card_lump,.comment_lump").live("tap", function(e) {
                var target = $(e.target);
                if (target.hasClass("wrap_del") || target.hasClass("del") || target.parents(".wrap_del").length > 0 || target.parents(".del").length > 0) {
                    return;
                }
                $$thread_module.showTopic($(this).data("topic-id"));
                return false;
            });
            $(".block_card .wrap_del").live("tap", function() {
                var topic_id = $(this).data("topic-id");
                delTopic(topic_id);
            });
            $(".block_comment .del").live("tap", function() {
                var comment_id = $(this).data("comment-id");
                delComment(comment_id);
            });
        };
        var page_size = 10;
        var next_page;
        var total_page;
        var initUserTopics = function() {
            next_page = 1;
            getUserTopics(next_page, page_size, function(data) {
                var topics_render = $$template.compile(profile_tmpl.user_topics_tmpl.join("\r\n"));
                var topics_html = topics_render(data);
                $("#sohu-changquan").html(topics_html);
                $.when($page.getPageEvent("profile_topic")).progress(function(a) {
                    if (next_page <= total_page && a.type == "profile_topic") nextPageUserTopics();
                });
            });
        };
        var nextPageUserTopics = function() {
            getUserTopics(next_page, page_size, function(data) {
                var topics_render = $$template.compile(profile_tmpl.topic_list_tmpl.join("\r\n"));
                var topics_html = topics_render(data);
                $(".block_card").append(topics_html);
            });
        };
        var getUserTopics = function(page_no, page_size, render_fn) {
            var params = {
                client_id: $$config.client_id,
                page_no: page_no,
                page_size: page_size
            };
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/user/topics",
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "loadUserTopics",
                scriptCharset: "utf-8",
                cache: false,
                data: params,
                beforeSend: function() {
                    $(".lump_loading").show();
                },
                success: function(data) {
                    $(".lump_loading").hide();
                    data.default_img = "http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png";
                    data.data_type = "topics";
                    total_page = data.total_page;
                    next_page++;
                    $.when($$user.ready_trigger).done(function() {
                        data.user = $$user.cyan_user;
                        if (render_fn && typeof render_fn == "function") {
                            render_fn(data);
                        }
                    });
                }
            });
        };
        var initUserReplies = function() {
            next_page = 1;
            getUserReplies(next_page, page_size, function(data) {
                var replies_render = $$template.compile(profile_tmpl.user_replies_tmpl.join("\r\n"));
                var replies_html = replies_render(data);
                $("#sohu-changquan").html(replies_html);
                $.when($page.getPageEvent("profile_reply")).progress(function(a) {
                    if (next_page <= total_page && a.type == "profile_reply") nextPageUserReplies();
                });
            });
        };
        var nextPageUserReplies = function() {
            getUserReplies(next_page, page_size, function(data) {
                var replies_render = $$template.compile(profile_tmpl.reply_list_tmpl.join("\r\n"));
                var replies_html = replies_render(data);
                $(".block_reply").append(replies_html);
            });
        };
        var getUserReplies = function(page_no, page_size, render_fn) {
            var params = {
                page_no: page_no,
                page_size: page_size,
                client_id: $$config.client_id
            };
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/user/replies",
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "loadUserReplies",
                scriptCharset: "utf-8",
                cache: false,
                data: params,
                beforeSend: function() {
                    $(".lump_loading").show();
                },
                success: function(data) {
                    $(".lump_loading").hide();
                    next_page++;
                    total_page = data.total_page;
                    data.data_type = "replies";
                    data.default_img = "http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png";
                    $.when($$user.ready_trigger).done(function() {
                        data.user = $$user.cyan_user;
                        if (render_fn && typeof render_fn == "function") {
                            render_fn(data);
                        }
                    });
                }
            });
        };
        var initUserComments = function() {
            next_page = 1;
            getUserComments(next_page, page_size, function(data) {
                var comments_render = $$template.compile(profile_tmpl.user_comments_tmpl.join("\r\n"));
                var comments_html = comments_render(data);
                $("#sohu-changquan").html(comments_html);
                $.when($page.getPageEvent("profile_comment")).progress(function(a) {
                    if (next_page <= total_page && a.type == "profile_comment") nextPageUserComments();
                });
            });
        };
        var nextPageUserComments = function() {
            getUserComments(next_page, page_size, function(data) {
                var comments_render = $$template.compile(profile_tmpl.comment_list_tmpl.join("\r\n"));
                var comments_html = comments_render(data);
                $(".block_comment").append(comments_html);
            });
        };
        var getUserComments = function(page_no, page_size, render_fn) {
            var params = {
                page_no: page_no,
                page_size: page_size,
                client_id: $$config.client_id
            };
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/user/comments",
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "loadUserComments",
                scriptCharset: "utf-8",
                cache: false,
                data: params,
                beforeSend: function() {
                    $(".lump_loading").show();
                },
                success: function(data) {
                    $(".lump_loading").hide();
                    data.data_type = "comments";
                    data.default_img = "http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png";
                    total_page = data.total_page;
                    next_page++;
                    $.when($$user.ready_trigger).done(function() {
                        data.user = $$user.cyan_user;
                        if (render_fn && typeof render_fn == "function") {
                            render_fn(data);
                        }
                    });
                }
            });
        };
        var delTopic = function(topic_id) {
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/user/del/topic",
                type: "get",
                dataType: "jsonp",
                jsonp: "callback",
                data: {
                    client_id: $$config.client_id,
                    thread_id: topic_id
                },
                success: function(data) {
                    $("#my_thread_" + topic_id).remove();
                }
            });
        };
        var delComment = function(comment_id) {
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/user/del/comment",
                type: "get",
                dataType: "jsonp",
                jsonp: "callback",
                data: {
                    client_id: $$config.client_id,
                    comment_id: comment_id
                },
                success: function(data) {
                    $("#my_comment_" + comment_id).remove();
                }
            });
        };
        var profile = {
            initProfile: initProfileEvent,
            getUserReplies: initUserReplies,
            getUserComments: initUserComments,
            getUserTopics: initUserTopics
        };
        module.exports = profile;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_edit_thread_module.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$template = require("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var $$face_utils = require("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_face.js");
        var $$uploader = require("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_upload.js");
        var edit_thread_tmpl = [ '   <div id="sohu_CQ_page3" class="reset_public wrapper_CQ_public">', '       <section class="top_bar_site">', '           <div class="top_bar_bg"></div>', '           <div class="top_bar_wrap">', '               <div class="bar_left">', '                   <div class="bar_left_prev">', '                       <span id="back_to_board" data-board-id="{{board_id}}" data-hash="board_{{board_id}}">上一页</span>', "                   </div>", "               </div>", '               <div class="bar_center">', '                   <h2 class="bar_center_name">{{board_name}}</h2>', "               </div>", '               <div class="bar_right">', '                   <div class="bar_right_issue"><span></span></div>', "               </div>", "           </div>", "       </section>", '       <section class="issue_card">', '           <div class="card_title_text">', '               <div class="clear_public card_title">', '                   <div class="title_left"><span>标题：</span></div>', '                   <div class="title_right">', '                       <input id="title_input" type="text" value="" />', '                       <input id="attach_url" type="hidden">', '                       <input id="board_id" type="hidden" value="{{board_id}}">', "                   </div>", "               </div>", '               <div class="card_text"><span><em>内容：</em></span>', '               <textarea id="thread_input" name="" style="height:100%"></textarea></div>', "           </div>", '           <div id="thread_bar" class="issue_action face_hidden">', '               <div class="clear_public action_bar">', '                   <div class="bar_kinds">', '                       <ul class="clear_public">', '                           <li id="thread_face_btn" class="kinds_face"><a href="javascript:;"></a></li>', '                           <li class="kinds_upload"><a href="javascript:void(0);">', '                               <input id="upload_input" style="font-size:1.5em;opacity: 0.01;" type="file">', "                           </a></li>", "                       </ul>", "                   </div>", '                   <div class="clear_public bar_del_pic" style="display:none;">', '                       <div class="bar_pic"><img id="" src="" alt=""/></div>', '                       <div class="bar_del"><span>删除</span></div>', "                   </div>", '                   <div id="thread_face_box" class="bar_face_lump" style="display:none">', '                        <div class="face_box">', "                               {{each faces as face index}}", "                                   {{if face.turn % 6 == 1}}", '                                       <ul class="clear_public">', "                                   {{/if}}", '                                   <li data-code="{{index}}"><img src="{{face_base_url + face.img}}"/></li>', "                                   {{if face.turn % 6 == 0}}", "                                       </ul>", "                                   {{/if}}", "                               {{/each}}", '                               <div class="box_arrow"><span></span></div>', "                        </div>", "                   </div>", "               </div>", "           </div>", "       </section>", "   </div>" ];
        var initThreadEditEvent = function() {
            $(".bar_right_issue span").live("tap", function() {
                var content = $("#thread_input").val();
                var title = $("#title_input").val();
                var img_url = $("#attach_url").val();
                var board_id = $("#board_id").val();
                addTopic(title, content, img_url, board_id);
            });
            $("#upload_input").live("change", function(e) {
                var file = e.target.files[0];
                $.when($$uploader.upload(file)).done(function(data) {
                    $(".kinds_upload").hide();
                    $(".bar_del_pic img").attr("src", data.url);
                    $(".bar_del_pic").show();
                    $("#attach_url").val(data.url);
                }).fail(function(data) {
                    console.log(data.error_msg);
                });
            });
            $(".bar_del span").live("tap", function() {
                $(".kinds_upload").show();
                $(".bar_del_pic").hide();
                $(".bar_del_pic img").attr("src", "");
                $("#attach_url").val("");
            });
            $("#thread_face_btn").live("tap", function() {
                $(this).toggleClass("kinds_face_e");
                $("#thread_face_box").toggle();
                $("#thread_bar").toggleClass("face_hidden");
                changeTextSize();
            });
            $("#thread_face_box .face_box ul li").live("tap", function() {
                var code = $(this).data("code");
                var old_val = $("#thread_input").val();
                $("#thread_input").val(old_val + "[" + code + "]");
            });
            $(window).resize(function() {
                changeTextSize();
            });
        };
        var changeTextSize = function() {
            var height = $(window).height() - $(".top_bar_wrap").height() - $(".card_title").height() - $(".issue_action").height() - $(".bar_face_lump").height();
            $(".card_text").height(height);
        };
        var editThread = function(board_id, board_name) {
            var data = {};
            data.board_id = board_id;
            data.board_name = board_name;
            data.face_base_url = $$face_utils.face_base_url;
            data.faces = $$face_utils.faces;
            var edit_thread_render = $$template.compile(edit_thread_tmpl.join("\r\n"));
            var edit_html = edit_thread_render(data);
            $("#sohu-changquan").html(edit_html);
            changeTextSize();
        };
        var addTopic = function(title, content, img_url, board_id) {
            if (!title) {
                alertMsg("请填写帖子标题");
            }
            if (!content) {
                alertMsg("请填写帖子内容");
            }
            var params = {
                content: content,
                title: title,
                attachment: img_url
            };
            $.ajax({
                type: "POST",
                url: "http://changyan.sohu.com/api/bbs/postthread/" + board_id,
                cache: false,
                crossDomain: true,
                xhrFields: {
                    withCredentials: true
                },
                data: params,
                success: function(result) {
                    if (!result.error_code) {
                        if (result.topic_status == "NORMAL") {
                            alertMsg("发表成功", function() {
                                $("#back_to_board").tap();
                            });
                        } else {
                            alertMsg("帖子已发出，请等待管理员审核", function() {
                                $("#back_to_board").tap();
                            });
                        }
                    } else {
                        alertMsg("发表失败");
                    }
                }
            });
        };
        var alertMsg = function(msg, post_fn) {
            $(".issue_succeed span").text(msg);
            $(".issue_succeed").show();
            setTimeout(function() {
                $(".issue_succeed").hide();
                if (typeof post_fn == "function") {
                    post_fn();
                }
            }, 2e3);
        };
        initThreadEditEvent();
        var edit_thread_module = {
            editThread: editThread
        };
        module.exports = edit_thread_module;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_page.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var page_type;
        var page_e = $.Deferred();
        var start = [];
        $(document).live("touchmove", function(e) {
            if ($(document).height() - $(window).height() - $(window).scrollTop() <= 10 && start.length == 0) {
                start[0] = e.touches[0].clientX;
                start[1] = e.touches[0].clientY;
            }
        }).live("touchend", function(e) {
            if ($(document).height() - $(window).height() - $(window).scrollTop() <= 10) {
                var end = [];
                end[0] = e.changedTouches[0].clientX;
                end[1] = e.changedTouches[0].clientY;
                if (end[1] - start[1] < -200) {
                    page_e.notifyWith(this, [ {
                        type: page_type
                    } ]);
                }
            }
            start = [];
        });
        $(document).live("mousewheel", function(e) {
            if (e.wheelDeltaY < 0 && $(document).height() - $(window).height() - $(window).scrollTop() <= 10) {
                page_e.notifyWith(this, [ {
                    type: page_type
                } ]);
            }
        });
        var page = {
            getPageEvent: function(type) {
                page_type = type;
                return page_e;
            }
        };
        module.exports = page;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_face.js", function(require, exports, module) {
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var faces = {
            "/流汗": {
                img: "face09.png",
                turn: 1
            },
            "/大哭": {
                img: "face13.png",
                turn: 2
            },
            "/发怒": {
                img: "face03.png",
                turn: 3
            },
            "/鼓掌": {
                img: "face02.png",
                turn: 4
            },
            "/给力": {
                img: "face05.png",
                turn: 5
            },
            "/闭嘴": {
                img: "face17.png",
                turn: 6
            },
            "/憨笑": {
                img: "face06.png",
                turn: 7
            },
            "/色": {
                img: "face04.png",
                turn: 8
            },
            "/强": {
                img: "face10.png",
                turn: 9
            },
            "/弱": {
                img: "face11.png",
                turn: 10
            },
            "/鄙视": {
                img: "face15.png",
                turn: 11
            },
            "/可爱": {
                img: "face07.png",
                turn: 12
            },
            "/惊讶": {
                img: "face19.png",
                turn: 13
            },
            "/疑问": {
                img: "face14.png",
                turn: 14
            },
            "/抓狂": {
                img: "face08.png",
                turn: 15
            },
            "/浮云": {
                img: "face20.png",
                turn: 16
            },
            "/可怜": {
                img: "face18.png",
                turn: 17
            },
            "/玫瑰": {
                img: "face12.png",
                turn: 18
            },
            "/钱": {
                img: "face16.png",
                turn: 19
            },
            "/握手": {
                img: "face22.png",
                turn: 20
            },
            "/拳头": {
                img: "face23.png",
                turn: 21
            },
            "/酒": {
                img: "face24.png",
                turn: 22
            },
            "/奋斗": {
                img: "face01.png",
                turn: 23
            },
            "/打酱油": {
                img: "face21.png",
                turn: 24
            }
        };
        var face = {
            face_base_url: $$config.resourceRoot + "src/css/main/images/face/",
            faces: faces,
            decodeFaceContent: function(content) {
                var conFace = content.replace(/\[([^\]]+)\]+?/g, function(all, $1) {
                    var img_data = faces[$1] && faces[$1].img;
                    if (!img_data) {
                        return all;
                    }
                    return '<img src="' + face.face_base_url + img_data + '">';
                });
                return conFace;
            }
        };
        module.exports = face;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_upload.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var upload = function(file) {
            var deferred = $.Deferred();
            var params = {
                type: "json"
            };
            if (window.FormData) {
                var suffix = file.name.replace(/^.+\.([^.]+)/, "$1").toLowerCase();
                for (var i in $$config.img_type) {
                    var type = $$config.img_type[i];
                    if (suffix == type) {
                        var fd = new FormData;
                        fd.append("file", file);
                        for (var key in params) {
                            fd.append(key, params[key]);
                        }
                        var xhr = new XMLHttpRequest;
                        var upload_url = "http://changyan.sohu.com/api/2/comment/attachment";
                        xhr.open("POST", upload_url, true);
                        xhr.setRequestHeader("Accept", "*/*");
                        xhr.onload = function() {
                            if (xhr.status == 200) {
                                if (xhr.responseText) {
                                    var json = $.parseJSON(xhr.responseText);
                                    deferred.resolveWith(this, [ json ]);
                                }
                            } else {
                                deferred.rejectWith(this, [ {
                                    error_msg: "上传出错"
                                } ]);
                            }
                        };
                        xhr.send(fd);
                        return deferred;
                    }
                }
                alert("文件类型不合法");
            }
        };
        var uploader = {
            upload: upload
        };
        module.exports = uploader;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_reply_module.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js"), $$template = require("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js"), $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js"), $$uploader = require("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_upload.js"), $$face_utils = require("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_face.js");
        var reply_tmpl = {};
        reply_tmpl.reply_layer = [ '   <div class="reset_public issue_succeed" style="display:none">', '       <div class="succeed_wrap"><span>发表成功！</span></div>', "   </div>", '   <div id="comment_reply_container" class="reset_public reply_content face_hidden" style="display:none;">', '       <div class="content_wrap">', '           <div class="wrap_box">', '               <div class="box_action">', '                   <div class="action_cancel"><span>取消</span></div>', '                   <div class="action_title"><span>回复</span></div>', '                   <div class="action_issue"><span>发表</span></div>', "               </div>", '               <div class="box_reply">', '                   <input type="hidden" id="param_topic_id">', '                   <input type="hidden" id="param_reply_id">', '                   <input type="hidden" id="attach_url">', '                   <textarea class="entry_text_e" id="comment_input" name="comment_input"></textarea>', "               </div>", '               <div class="clear_public action_bar">', '                   <div class="bar_kinds">', '                       <ul class="clear_public">', '                           <li id="comment_face_btn" class="kinds_face"><a href="javascript:void(0);"></a></li>', '                           <li class="kinds_upload"><a href="javascript:void(0);">', '                               <input id="upload_input" style="font-size:1.5em;opacity: 0.01;" type="file">', "                           </a></li>", "                       </ul>", "                   </div>", '                   <div class="clear_public bar_del_pic" style="display:none">', '                       <div class="bar_pic"><img src="" alt=""/></div>', '                       <div class="bar_del"><span>删除</span></div>', "                   </div>", '                   <div id="comment_face_box" class="bar_face_lump" style="display:none;">', '                       <div class="face_box">', '                           <div class="clear_public face_page">', "                               {{each faces as face index}}", "                                   {{if face.turn % 12 == 1}}", '                                       <div class="page_wrap">', "                                   {{/if}}", "                                   {{if face.turn % 6 == 1}}", '                                       <ul class="clear_public">', "                                   {{/if}}", '                                   <li data-code="{{index}}"><img src="{{face_base_url + face.img}}"/></li>', "                                   {{if face.turn % 6 == 0}}", "                                       </ul>", "                                   {{/if}}", "                                   {{if face.turn % 12 == 0}}", "                                       </div>", "                                   {{/if}}", "                               {{/each}}", "                           </div>", '                           <div class="box_page"><span class="page_now"></span><span></span></div>', '                           <div class="box_arrow"><span></span></div>', "                       </div>", "                   </div>", "               </div>", "           </div>", "       </div>", "   </div>" ];
        var bindReplyEvent = function() {
            $(".action_issue").live("tap", function() {
                var content = $("#comment_input").val();
                var topic_id = $("#param_topic_id").val();
                var reply_id = $("#param_reply_id").val();
                var attachment = $("#attach_url").val();
                replyComment(topic_id, reply_id, content, attachment);
                return false;
            });
            $("#upload_input").live("change", function(e) {
                var file = e.target.files[0];
                $.when($$uploader.upload(file)).done(function(data) {
                    $(".kinds_upload").hide();
                    $(".bar_del_pic img").attr("src", data.url);
                    $(".bar_del_pic").show();
                    $("#attach_url").val(data.url);
                }).fail(function(data) {
                    console.log(data.error_msg);
                });
            });
            $(".bar_del span").live("tap", function() {
                $(".kinds_upload").show();
                $(".bar_del_pic").hide();
                $(".bar_del_pic img").attr("src", "");
                $("#attach_url").val("");
            });
            $(".action_cancel,#sohu_CQ_mark").live("tap", function() {
                hideReply();
                return false;
            });
            $("#comment_face_btn").live("tap", function() {
                $(this).toggleClass("kinds_face_e");
                $("#comment_face_box").toggle();
                $("#comment_reply_container").toggleClass("face_hidden");
            });
            $("#comment_face_box .face_box ul li").live("tap", function() {
                var code = $(this).data("code");
                var old_val = $("#comment_input").val();
                $("#comment_input").val(old_val + "[" + code + "]");
            });
            var start = [];
            $("#comment_face_box .face_box").live("touchstart", function(e) {
                start[0] = e.touches[0].clientX;
                start[1] = e.touches[0].clientY;
            }).live("touchend", function(e) {
                var end = [];
                end[0] = e.changedTouches[0].clientX;
                end[1] = e.changedTouches[0].clientY;
                var move_x = end[0] - start[0];
                var move_y = end[1] - start[1];
                if (Math.abs(move_x / move_y) > 1.5) {
                    rollFace(move_x);
                }
            });
        };
        var rollFace = function(direction) {
            if (direction > 0) {
                $(".face_page").animate({
                    "margin-left": "0"
                }, 200);
                $(".face_box .box_page span").eq(0).addClass("page_now");
                $(".face_box .box_page span").eq(1).removeClass("page_now");
            } else {
                $(".face_page").animate({
                    "margin-left": "-100%"
                }, 200);
                $(".face_box .box_page span").eq(1).addClass("page_now");
                $(".face_box .box_page span").eq(0).removeClass("page_now");
            }
        };
        var addReplyLayer = function() {
            var data = {};
            data.faces = $$face_utils.faces;
            data.face_base_url = $$face_utils.face_base_url;
            var layer_render = $$template.compile(reply_tmpl.reply_layer.join("\r\n"));
            var layer_html = layer_render(data);
            $("body").append(layer_html);
        };
        var promptReply = function(topic_id, reply_id, reply_name) {
            if (reply_id) {
                $(".kinds_upload").hide();
            } else {
                $(".kinds_upload").show();
            }
            $("#param_topic_id").val(topic_id);
            $("#param_reply_id").val(reply_id || 0);
            $("#sohu_CQ_mark").show();
            $(".reply_content").show();
            if (reply_id) {
                $("#comment_input").attr("placeholder", "回复" + reply_name + "：");
            }
        }, hideReply = function() {
            $("#param_topic_id").val("");
            $("#param_reply_id").val("");
            $("#sohu_CQ_mark").hide();
            $(".reply_content").hide();
            $("#comment_input").attr("placeholder", "");
            $("#comment_input").val("");
        }, replyComment = function(topic_id, reply_id, content, attachment) {
            if (!content) {
                alertMsg("请输入评论内容");
                return;
            }
            var params = {
                topic_id: topic_id,
                reply_id: reply_id,
                content: content,
                attachment: attachment
            };
            $.ajax({
                type: "POST",
                url: "http://changyan.sohu.com/api/bbs/postreply/" + topic_id,
                scriptCharset: "utf-8",
                crossDomain: true,
                xhrFields: {
                    withCredentials: true
                },
                data: params,
                success: function(data) {
                    if (!data.error_code) {
                        hideReply();
                        var enable = data.is_enable;
                        if (enable) {
                            alertMsg("发表成功！");
                        } else {
                            alertMsg("回帖已发出，请等待管理员审核。");
                        }
                    } else {
                        alertMsg("发表失败");
                    }
                }
            });
        };
        var alertMsg = function(msg, post_fn) {
            $(".issue_succeed span").text(msg);
            $(".issue_succeed").show();
            setTimeout(function() {
                $(".issue_succeed").hide();
                if (typeof post_fn == "function") {
                    post_fn();
                }
            }, 2e3);
        };
        bindReplyEvent();
        addReplyLayer();
        var reply = {
            promptReply: promptReply,
            alertMsg: alertMsg
        };
        module.exports = reply;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_thread_module.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$template = require("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var $$login_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/user/changquan_login_module.js");
        var $$user = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_user.js");
        var $$reply_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_reply_module.js");
        var $page = require("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_page.js");
        var thread_tmpl = {};
        thread_tmpl.subcmt_piece_tmpl = [ '<p class="cont_reply" id="sub_comment_{{sub_comment.comment_id}}" data-reply-name="{{sub_comment.passport.nickname}}" data-comment-id="{{sub_comment.comment_id}}">', '   <span class="reply_name">', '       <em class="user_name">{{sub_comment.passport.nickname}}</em>{{if sub_comment.reply_name}}回复<em class="user_name">{{sub_comment.reply_name}}</em>{{/if}} :', "   </span>{{#sub_comment.content | $escape | decodeFaceContent}}", '   <span class="cont_date"><em>{{sub_comment.create_time | getFormatDate}}</em></span>', "</p>" ];
        thread_tmpl.comment_piece_tmpl = [ '<div class="reply_cont" id="comment_{{comment.comment_id}}">', '   <div class="clear_public cont_head">', '       <div class="head_pic"><img src="{{comment.passport.img_url||default_img}}" alt=""/></div>', '       <div class="head_msg">', '           <div class="msg_user_floor">', '               <span class="user_name"><em>{{comment.passport.nickname}}</em></span>', '               <span class="msg_level level_{{comment.userScore.level}}"></span>', "               {{if comment.passport.user_id == user.sid}}", '                   <span class="floor_main"><em>楼主</em></span>', "               {{/if}}", '               <span class="msg_floor"><em>{{comment.metadataAsJson.bbs_floor}}楼</em></span>', "           </div>", '           <div class="msg_date"><span>{{comment.create_time | getFormatDate}}</span></div>', "       </div>", "   </div>", '   <p class="cont_text" data-comment-id="{{comment.comment_id}}" data-reply-name="{{comment.passport.nickname}}">', "       <span>{{#comment.content | $escape | decodeFaceContent}}</span>", "   </p>", "   {{if comment.attachments && comment.attachments.length > 0}}", '       <div class="cont_pic">', '           <img src="{{comment.attachments[0].url.replace(base_url, base_url + "/c_fill,w_120,h_90/")}}">', "       </div>", "   {{/if}}", "   {{if comment.comments && comment.comments.length > 0 }}", "       {{each comment.comments as sub_comment index}}", thread_tmpl.subcmt_piece_tmpl.join("\r\n"), "       {{/each}}", "   {{/if}}", "</div>" ];
        thread_tmpl.comment_list_tmpl = [ "{{each comments as comment index}}", thread_tmpl.comment_piece_tmpl.join("\r\n"), "{{/each}}" ];
        thread_tmpl.topic_tmpl = [ '   <div id="sohu_CQ_page4" class="reset_public wrapper_CQ_public">', '       <section class="top_bar_site">', '           <div class="top_bar_bg"></div>', '           <div class="top_bar_wrap">', '               <div class="bar_left">', '                   <div class="bar_left_prev">', '                       <span id="back_to_board" data-board-id="{{board.id}}" data-hash="board_{{board.id}}">上一页</span>', "                   </div>", "               </div>", '               <div class="bar_center">', '                   <h2 class="bar_center_name">{{board.name}}</h2>', "               </div>", '               <div class="bar_right">', '                   <div class="bar_right_more"><span></span></div>', "               </div>", "           </div>", "       </section>", '       <section class="card_range">', '           <section class="range_main" data-topic-id="{{thread_id}}">', '               <div class="clear_public main_head">', '                   <div class="clear_public head_left">', '                       <div class="head_pic"><img src="{{user.tiny_avatar||default_img}}" alt=""/></div>', '                       <div class="user_name"><span>{{user.nick}}</span></div>', '                       <div class="floor_main"><span>楼主</span></div>', "                   </div>", '                   <div class="head_right">', '                       <span class="head_date">{{create_time | getFormatDate}}</span>', "                   </div>", "               </div>", '               <div class="main_title"><span>{{title}}</span></div>', "               {{if attachments && attachments.length > 0}}", "                   {{each attachments as attachment index}}", "                   {{if attachment}}", '                       <div class="main_pic"><img src="{{attachment}}" alt=""/></div>', "                   {{/if}}", "                   {{/each}}", "               {{/if}}", '               <div class="main_cont">', "               {{each split_content as con_item index}}", "                   <p><span>{{#con_item | $escape | decodeFaceContent}}</span></p>", "               {{/each}}", "               </div>", '               <div class="clear_public main_action">', '                   <div class="action_wrap">', '                   <span class="wrap_favour">赞<em>{{support_count}}</em></span>', '                   <span class="wrap_comment">评论<em>{{cmt_sum}}</em></span>', "               </div>", "               </div>", "           </section>", '           <section class="range_reply">', thread_tmpl.comment_list_tmpl.join("\r\n"), "           </section>", "       </section>", '       <section class="action">', "           <ul>", '               <li id="favour"><span>赞({{support_count}})</span></li>', '               <li id="reply_thread"><span>评论({{cmt_sum}})</span></li>', '               <li id="share_thread"><span>分享</span></li>', "           </ul>", "       </section>", "   </div>" ];
        thread_tmpl.menus = [ '   <div class="reset_public share_select" style="display:none;">', "       <ul>", '           <li data-platform-id="2"><a href="javascript:void(0);">新浪微博</a></li>', '           <li data-platform-id="6"><a href="javascript:void(0);">人人网</a></li>', '           <li><a id="share_cancel" href="javascript:void(0);">取{{spaces}}消</a></li>', "       </ul>", "   </div>", '   <div class="reset_public more_select" style="display:none;">', "       <ul>", '           <li><a id="floor_host_view" href="javascript:void(0);">只看楼主</a></li>', '           <li><a id="report" href="javascript:void(0);">投诉举报</a></li>', '           <li><a id="menu_cancel" href="javascript:void(0);">取{{spaces}}消</a></li>', "       </ul>", "   </div>" ];
        var bindThreadEvent = function() {
            $("#favour").live("tap", function() {
                if ($(this).hasClass("clicked")) {
                    return;
                }
                $(this).addClass("clicked");
                var topic_id = $(".range_main").data("topic-id");
                favourTopic(topic_id);
            });
            $(".bar_right_more span").live("tap", function() {
                $("#sohu_CQ_mark").show();
                $(".more_select").show();
            });
            $("#menu_cancel,#sohu_CQ_mark").live("tap", function() {
                $("#sohu_CQ_mark").hide();
                $(".more_select").hide();
            });
            $("#floor_host_view").live("tap", function() {
                if ($(this).hasClass("floot_host_only")) {
                    showTopic($(".range_main").data("topic-id"));
                    $(this).text("只看楼主");
                } else {
                    viewFloorHost($(".range_main").data("topic-id"));
                    $(this).text("查看全部");
                }
                $(this).toggleClass("floot_host_only");
                $("#sohu_CQ_mark").hide();
                $(".more_select").hide();
            });
            $("#reply_thread").live("tap", function() {
                var user_info = $$user.cyan_user;
                if (!user_info || user_info.error_code == 10207) {
                    $$login_module.showLoginLayer();
                    return;
                }
                $$reply_module.promptReply($(".range_main").data("topic-id"), 0);
                return false;
            });
            $(".reply_cont .cont_text,.cont_reply").live("tap", function() {
                var user_info = $$user.cyan_user;
                if (!user_info || user_info.error_code == 10207) {
                    $$login_module.showLoginLayer();
                    return;
                }
                var reply_id = $(this).data("comment-id");
                var reply_name = $(this).data("reply-name");
                $$reply_module.promptReply($(".range_main").data("topic-id"), reply_id, reply_name);
                return false;
            });
            $("#report").live("tap", function() {
                var topic_id = $(".range_main").data("topic-id");
                reportTopic(topic_id);
            });
            $("#share_thread").live("tap", function() {
                showShareMenu();
            });
            $("#share_cancel,#sohu_CQ_mark").live("tap", function() {
                hideShareMenu();
            });
            $(".share_select li[data-platform-id]").live("tap", function() {
                var platform_id = $(this).data("platform-id");
                var topic_id = $(".range_main").data("topic-id");
                var passports = $$user.cyan_user && $$user.cyan_user.passports;
                var shared_id;
                var i;
                if (passports) {
                    for (i = 0; i < passports.length; i++) {
                        var passport = passports[i];
                        if (passport.platform_id == platform_id) {
                            shared_id = passport.passport_id;
                            break;
                        }
                    }
                }
                if (!shared_id) {
                    var url = encodeURIComponent(encodeURIComponent(window.location.href));
                    window.location.href = "http://changyan.sohu.com/api/2/login/passport?client_id=" + $$config.client_id + "&platform_id=" + platform_id + "&url=" + url + "&connName=changquan_wap&isMobile=true";
                    return;
                }
                shareTopic(shared_id, topic_id);
            });
        };
        var showShareMenu = function() {
            $("#sohu_CQ_mark").show();
            $(".share_select").show();
        };
        var hideShareMenu = function() {
            $("#sohu_CQ_mark").hide();
            $(".share_select").hide();
        };
        var shareTopic = function(shared_id, topic_id) {
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/topic/share",
                type: "get",
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "shareTopicCallBack",
                data: {
                    client_id: $$config.client_id,
                    shared_pid: shared_id,
                    topic_id: topic_id
                },
                success: function(data) {
                    if (!data.error_code) {
                        $$reply_module.alertMsg("分享成功");
                    } else {
                        $$reply_module.alertMsg("分享失败");
                    }
                    hideShareMenu();
                },
                error: function() {
                    $$reply_module.alertMsg("分享失败");
                    hideShareMenu();
                }
            });
        };
        var addMenus = function() {
            var data = {};
            data.spaces = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            var menus_render = $$template.compile(thread_tmpl.menus.join("\r\n"));
            var menus_html = menus_render(data);
            $("body").append(menus_html);
        };
        var next_page;
        var total_page;
        var showTopic = function(topic_id, floor_host_only) {
            next_page = 1;
            getComments(topic_id, 1, 10, floor_host_only, function(data) {
                next_page++;
                var topic_load_render = $$template.compile(thread_tmpl.topic_tmpl.join("\r\n"));
                var load_html = topic_load_render(data);
                $("#sohu-changquan").html(load_html);
                $.when($page.getPageEvent("thread")).progress(function(a) {
                    if (next_page <= total_page && a.type == "thread") nextPage(topic_id, floor_host_only);
                });
            });
        };
        var nextPage = function(topic_id, floor_host_only) {
            getComments(topic_id, next_page, 10, floor_host_only, function(data) {
                next_page++;
                var page_comments_render = $$template.compile(thread_tmpl.comment_list_tmpl.join("\r\n"));
                var comments_html = page_comments_render(data);
                $(".reply_cont").last().after(comments_html);
            });
        };
        var viewFloorHost = function(topic_id) {
            showTopic(topic_id, true);
        };
        var getComments = function(topic_id, page_no, page_size, floor_host_only, render_fn) {
            var params = {
                client_id: $$config.client_id,
                topic_id: topic_id,
                page_no: page_no,
                page_size: page_size
            };
            if (floor_host_only) {
                params.floor_host_only = true;
            }
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/topic/comments",
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "loadTopicCallBack",
                scriptCharset: "utf-8",
                cache: false,
                data: params,
                success: function(data) {
                    total_page = data.total_page_no;
                    $.when($$user.ready_trigger).done(function() {
                        data.login_user = $$user.cyan_user;
                        data.base_url = "http://comment.bjcnc.img.sohucs.com";
                        data.default_img = "http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png";
                        data.split_content = data.content.split(/[\r\n]/);
                        addReplyName(data.comments);
                        if (render_fn && typeof render_fn == "function") {
                            render_fn(data);
                        }
                    });
                }
            });
        };
        var addReplyName = function(comments) {
            var i, j;
            for (i in comments) {
                var comment = comments[i];
                var comment_uname = {};
                for (j in comment.comments) {
                    var sub_comment = comment.comments[j];
                    comment_uname[sub_comment.comment_id] = sub_comment.passport.nickname;
                    sub_comment.reply_name = comment_uname[sub_comment.reply_id];
                }
            }
        };
        var favourTopic = function(topic_id) {
            if ($$user.cyan_user.error_code) {
                $$login_module.showLoginLayer();
                return;
            }
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/topic/favour",
                type: "get",
                dataType: "jsonp",
                jsonp: "callback",
                data: {
                    topic_id: topic_id
                },
                success: function(data) {
                    var count = data.count;
                    $(".wrap_favour em").html(count);
                    $("#favour span").html("赞(" + count + ")");
                    $("#thread_" + topic_id + " .msg_ding em").html(count);
                }
            });
        };
        var reportTopic = function(topic_id) {
            var user = $$user.cyan_user;
            if (!user || user.error_code) {
                $$login_module.showLoginLayer();
                return;
            }
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/topic/report",
                type: "get",
                dataType: "jsonp",
                jsonp: "callback",
                data: {
                    topicId: topic_id
                },
                success: function(data) {
                    if (!data.error_code) {
                        $(".issue_succeed span").text("举报成功!");
                        $(".issue_succeed").show();
                    } else {
                        $(".issue_succeed span").text("操作失败!");
                        $(".issue_succeed").show();
                    }
                    setTimeout(function() {
                        $(".issue_succeed").hide();
                        $(".more_select").hide();
                        $("#sohu_CQ_mark").hide();
                    }, 1e3);
                }
            });
        };
        addMenus();
        bindThreadEvent();
        var thread = {
            showTopic: showTopic,
            favourTopic: favourTopic
        };
        module.exports = thread;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_board_module.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$template = require("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var $$thread_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_thread_module.js");
        var $$login_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/user/changquan_login_module.js");
        var $$user = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_user.js");
        var $$edit_thread_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_edit_thread_module.js");
        var $page = require("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_page.js");
        var board_template = {};
        board_template.top_threads_tmpl = [ "{{each top_threads as thread index}}", '    <div class="clear_public activity_lump" data-topic-id="{{thread.thread_id}}"', '           data-hash="topic_{{thread.thread_id}}" data-title="{{thread.title}}">', '        <div class="lump_ding"><span>顶</span></div>', '        <p class="lump_text"><span>', '            <a href="javascript:void(0)">{{thread.title}}</a>', "        </span></p>", "    </div>", "{{/each}}" ];
        board_template.topic_list_piece = [ "{{each threads as thread index}}", '   <section class="group_gap"></section>', '    <section id="thread_{{thread.thread_id}}" class="group_details" >', '        <div class="details_lump">', '            <div class="lump_title" data-topic-id="{{thread.thread_id}}"', '                   data-hash="topic_{{thread.thread_id}}" data-title="{{thread.title}}">', '               <a href="javascript:void(0)">{{thread.title}}</a>', "            </div>", '            <div class="clear_public lump_pic_text {{if !thread.attachment || !thread.attachment.length}}lump_pic_not{{/if}}" data-topic-id="{{thread.thread_id}}"', '                   data-hash="topic_{{thread.thread_id}}" data-title="{{thread.title}}">', "                {{if thread.attachment}}", '                    <div class="lump_pic">', '                       <img src="{{thread.attachment.replace(base_url, base_url + \'/c_fill,w_160,h_110/\')}}" alt=""/>', "                    </div>", "                {{/if}}", '                <div class="lump_text">', '                    <p class="text "><span>{{#thread.content.substring(0,50)}}</span></p>', "                </div>", "            </div>", '            <div class="clear_public lump_msg">', '                <div class="msg_name_level_date">', '                    <span class="msg_name"><i>{{thread.user_name}}</i></span>', '                    <span class="msg_level level_{{thread.user_score.level}}"></span>', '                    <span class="msg_date"><i>{{thread.create_time | getFormatDate}}</i></span>', "                </div>", '                <div class="msg_ding_comment">', '                    <span class="msg_ding" data-topic-id="{{thread.thread_id}}">', '                       <i class="ding_icon"></i><em>{{thread.support_count}}</em>', "                    </span>", '                    <span class="msg_comment" data-topic-id="{{thread.thread_id}}"', '                           data-hash="topic_{{thread.thread_id}}" data-title="{{thread.title}}">', '                       <i class="comment_icon"></i><em>{{thread.cmt_sum}}</em>', "                    </span>", "                </div>", "            </div>", "        </div>", "    </section>", "{{/each}}" ];
        board_template.topic_list_tmpl = [ '<div id="sohu_CQ_page2" class="reset_public wrapper_CQ_public">', '    <section class="top_bar_site">', '        <div class="top_bar_bg"></div>', '        <div class="top_bar_wrap">', '            <div class="bar_left">', '                <div class="bar_left_prev">', '                   <span id="back_to_index" data-hash="" data-title="{{config[0].bbs_name}}">上一页</span>', "               </div>", "            </div>", '            <div class="bar_center">', '                <h2 class="bar_center_name">{{board.name}}</h2>', "            </div>", '            <div class="bar_right">', "                {{if !user || user.error_code}}", '                    <div class="bar_right_user"><a href="javascript:void(0)"></a></div>', "                {{else}}", '                    <div class="bar_right_user bar_right_logined" data-hash="home" data-title="用户中心">', '                        <span href="javascript:void(0)">', '                            <img src="{{user.img_url||default_img}}" alt=""/>', "                        </span>", "                        {{if user.bbs_new_reply_count}}", '                            <div class="bar_right_logined_msg"></div>', "                        {{/if}}", "                    </div>", "                {{/if}}", "            </div>", "        </div>", "    </section>", '   <section class="group_intro">', '       <div class="clear_public intro_wrap">', '           <div class="intro_left">', '               <div class="intro_head">', "                   {{if board.icon}}", '                   <img src="{{board.icon.replace(base_url,base_url + \'/c_fill,w_128,h_128/\')}}" alt=""/>', "                   {{else}}", '                   <img src="http://changyan.sohu.com/changquan/css/main/images/pic/pic03.png" alt=""/>', "                   {{/if}}", "               </div>", "           </div>", '           <div class="intro_right">', '               <div class="clear_public intro_right_msg">', '                   <h3 class="msg_title">{{board.name}}</h3>', '                   <div class="msg_gross">帖子<span>{{board.thread_num}}</span></div>', "               </div>", '               <p class="intro_right_cont"><span>{{board.description}}</span></p>', "           </div>", "       </div>", "   </section>", "    {{if top_threads.length > 0}}", '        <section class="group_activity">', board_template.top_threads_tmpl.join("\r\n"), "        </section>", "    {{/if}}", "    {{if threads.length > 0}}", board_template.topic_list_piece.join("\r\n"), "    {{else}}", '       <section class="group_details">', '           <div class="details_lump">', '               <div class="lump_title"><a href="#">该圈子还没有帖子，快来抢沙发吧</a></div>', "           </div>", "       </section>", "    {{/if}}", '    <section class="group_loading" style="display:none;">', '        <div class="loading_wrap"><span class="loading_icon"></span><em>正在加载</em></div>', "    </section>", '    <section class="group_issue">', '       <div class="issue_btn">', '           <a id="edit_thread" data-board-id="{{board.board_id}}" data-board-name="{{board.board_name}}"', '               data-hash="editthread" data-title="发表话题" href="javascript:void(0)"><em>发帖</em></a>', "       </div>", "    </section>", "</div>" ];
        var initBoardEvent = function() {
            $(".lump_title,.lump_pic_text,.msg_comment,.activity_lump").live("tap", function(e) {
                $$thread_module.showTopic($(this).data("topic-id"));
                return false;
            });
            $("#edit_thread").live("tap", function() {
                var user_info = $$user.cyan_user;
                if (!user_info || user_info.error_code == 10207) {
                    return;
                }
                $$edit_thread_module.editThread($(this).data("board-id"), $(this).data("board-name"));
            });
            $(".msg_ding").live("tap", function() {
                if ($(this).hasClass("msg_ding_e")) {
                    return;
                }
                $(this).addClass("msg_ding_e");
                $$thread_module.favourTopic($(this).data("topic-id"));
                return false;
            });
        };
        var next_page = 2;
        var total_page;
        var loadTopics = function(board_id) {
            getThreads(board_id, 1, 10, function(data) {
                var topic_load_render = $$template.compile(board_template.topic_list_tmpl.join("\r\n"));
                var load_html = topic_load_render(data);
                $("#sohu-changquan").html(load_html);
                next_page = 2;
                total_page = data.board.total_page;
                $.when($page.getPageEvent("board")).progress(function(a) {
                    if (next_page <= total_page && a.type == "board") nextPage(board_id);
                });
            });
        };
        var nextPage = function(board_id) {
            getThreads(board_id, next_page, 10, function(data) {
                var page_comment_render = $$template.compile(board_template.topic_list_piece.join("\r\n"));
                var page_html = page_comment_render(data);
                $(".group_details").last().after(page_html);
                next_page++;
            });
        };
        var getThreads = function(board_id, page_no, page_size, render_fn) {
            var params = {
                board_id: board_id,
                page_no: page_no,
                page_size: page_size
            };
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/board/threads",
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "loadTopicsCallBack",
                scriptCharset: "utf-8",
                cache: false,
                data: params,
                beforeSend: function() {
                    $(".group_loading").show();
                },
                success: function(data) {
                    $.when($$user.ready_trigger).done(function() {
                        data.config = $$config.backend_config;
                        data.base_url = "http://comment.bjcnc.img.sohucs.com";
                        data.default_img = "http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png";
                        data.user = $$user.cyan_user;
                        if (render_fn && typeof render_fn == "function") {
                            render_fn(data);
                        }
                        $(".group_loading").hide();
                    });
                }
            });
        };
        initBoardEvent();
        var board_module = {
            loadTopics: loadTopics
        };
        module.exports = board_module;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_index_module.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$template = require("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var $$user = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_user.js");
        var $$login_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/user/changquan_login_module.js");
        var $$board_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_board_module.js");
        var $$thread_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_thread_module.js");
        var $$profile_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/user/changquan_profile.js");
        var $$board_topic_manage = require("D:/workspaces/cyan/changquan/tmp-build/widget/moderator/changquan_board_topic_manage.js");
        var index_tmpl = {};
        index_tmpl.board_list_tmpl = [ '<div id="sohu_CQ_page1" class="reset_public wrapper_CQ_public">', '\t<section class="top_bar_site">', '\t\t<div class="top_bar_bg"></div>', '\t\t<div class="top_bar_wrap">', '\t\t\t<div class="bar_left">', '\t\t\t\t<div class="bar_left_prev">', "\t\t\t\t\t<span {{if config[0].home_page}}onclick=\"window.location.href='{{config[0].home_page}}'\"{{/if}}", '\t\t\t\t\t\tstyle="background-image:url({{config[0].home_logo}})">上一页</span>', "\t\t\t\t</div>", "\t\t\t</div>", '\t\t\t<div class="bar_center">', '\t\t\t\t<h2 class="bar_center_name">{{config[0].bbs_name}}</h2>', "\t\t\t</div>", '\t\t\t<div class="bar_right">', "\t\t\t\t{{if !user || user.error_code}}", '\t\t\t\t\t<div class="bar_right_user"><span data-hash="home" data-title="用户中心"></span></div>', "\t\t\t\t{{else}}", '\t\t\t\t\t<div class="bar_right_user bar_right_logined" data-hash="home" data-title="用户中心">', '\t\t\t\t\t\t<span href="javascript:void(0);"><img src="{{user.img_url||default_img}}" alt=""/></span>', "\t\t\t\t\t\t{{if user.bbs_new_reply_count}}", '\t\t\t\t\t\t\t<div class="bar_right_logined_msg"></div>', "\t\t\t\t\t\t{{/if}}", "\t\t\t\t\t</div>", "\t\t\t\t{{/if}}", "\t\t\t</div>", "\t\t</div>", "\t</section>", '\t<section class="turn_pic">', '\t\t<div class="turn_wrap">', '\t\t\t<ul class="trun_box clear_pbulic" style="width:{{topics.length*100}}%;margin-left:-100%">', "\t\t\t\t<!-- {{length = topics.length}} -->", "\t\t\t\t<!-- {{last = topics[length - 1]}} -->", '\t\t\t\t<li data-pic-num="{{length - 1}}" style="width:{{100/length}}%">', '\t\t\t\t\t<a href="javascript:void(0)" data-hash="thread_{{last.thread_id}}" ', '\t\t\t\t\t\t\tdata-title="{{last.title}}" data-thread-id="{{last.thread_id}}">', '\t\t\t\t\t\t<img src="{{last.attachment}}" style="width:100%;height:12.5em" alt=""/>', "\t\t\t\t\t</a>", "\t\t\t\t</li>", "\t\t\t\t{{each topics as thread index}}", "\t\t\t\t\t{{if index < length - 1}}", '\t\t\t\t\t<li {{if index == 0}}class="now"{{/if}} data-pic-num="{{index}}" style="width:{{100/length}}%">', '\t\t\t\t\t\t<a href="javascript:void(0)" data-hash="thread_{{thread.thread_id}}" ', '\t\t\t\t\t\t\t\tdata-title="{{thread.title}}" data-thread-id="{{thread.thread_id}}">', '\t\t\t\t\t\t\t<img src="{{thread.attachment}}" style="width:100%;height:12.5em" alt=""/>', "\t\t\t\t\t\t</a>", "\t\t\t\t\t</li>", "\t\t\t\t\t{{/if}}", "\t\t\t\t{{/each}}", "\t\t\t</ul>", '\t\t\t<div class="trun_pic_title">', '\t\t\t\t<ul class="clear_public">', "\t\t\t\t\t{{each topics as thread index}}", '\t\t\t\t\t\t<li {{if index == 0}}class="now" {{/if}}>{{thread.title}}</li>', "\t\t\t\t\t{{/each}}", "\t\t\t\t</ul>", "\t\t\t</div>", '\t\t\t<div class="trun_pic_num">', '\t\t\t\t<ul class="clear_public">', "\t\t\t\t\t{{each topics as thread index}}", '\t\t\t\t\t\t<li {{if index == 0}}class="now" {{/if}}>{{index}}</li>', "\t\t\t\t\t{{/each}}", "\t\t\t\t</ul>", "\t\t\t</div>", "\t\t</div>", "\t</section>", '\t<section class="article_list">', "\t\t{{each boards as board index}}", '\t\t<div class="clear_public article_lump" data-hash="board_{{board.board_id}}" data-title="{{board.name}}"', '\t\t\t\tdata-board-id="{{board.board_id}}" data-board-name="{{board.name}}">', '\t\t\t<div class="lump_left">', '\t\t\t\t<div class="lump_head">', "\t\t\t\t\t{{if board.icon}}", '\t\t\t\t\t<img src="{{board.icon.replace(base_url, base_url + \'/c_fill,w_128,h_128/\')}}" alt=""/>', "\t\t\t\t\t{{else}}", '\t\t\t\t\t<img src="http://changyan.sohu.com/changquan/css/main/images/pic/pic03.png" alt=""/>', "\t\t\t\t\t{{/if}}", "\t\t\t\t</div>", "\t\t\t</div>", '\t\t\t<div class="lump_right">', '\t\t\t\t<div class="clear_public lump_right_msg">', '\t\t\t\t\t<h3 class="msg_title">{{board.name}}</h3>', '\t\t\t\t\t<div class="msg_num"><span>{{board.thread_num}}</span></div>', "\t\t\t\t</div>", '\t\t\t    <p class="lump_right_cont"><span>{{board.description}}</span></p>', '\t\t\t\t{{if board.moderators && arrayContains(board.moderators.split(","), user.user_id)}}', '\t\t\t\t\t<a class="board_manage" data-hash="boardtaudit_{{board.board_id}}" ', '\t\t\t\t\t\tstyle="font-size:0.75em;margin-top:0.5em;">板块管理</a>', "\t\t\t\t{{/if}}", "\t\t\t</div>", "\t\t</div>", "\t\t{{/each}}", "\t</section>", '\t<section class="article_foot">', '\t\t<div class="foot_wrap"></div>', "\t</section>", "</div>" ];
        var nextDiagram = function() {
            var width = $(".turn_wrap").width();
            var cur_diagram = $(".trun_box li.now");
            var next_idx = parseInt(cur_diagram.data("pic-num")) + 1;
            if (next_idx == $(".trun_box li").length) {
                next_idx = 0;
            }
            var next_diagram = $('.trun_box li[data-pic-num="' + next_idx + '"]');
            $(".trun_box li").eq(0).animate({
                "margin-left": -width
            }, 500, "ease", function() {
                cur_diagram.removeClass("now");
                next_diagram.addClass("now");
                var first = $(".trun_box li").eq(0);
                first.css("margin-left", 0);
                first.remove();
                $(".trun_box").append(first);
                $(".trun_pic_title ul li").removeClass("now");
                $(".trun_pic_title ul li").eq(next_idx).addClass("now");
                $(".trun_pic_num ul li").removeClass("now");
                $(".trun_pic_num ul li").eq(next_idx).addClass("now");
            });
        };
        var preDiagram = function() {
            var width = $(".turn_wrap").width();
            var cur_diagram = $(".trun_box li.now");
            var pre_idx = parseInt(cur_diagram.data("pic-num")) - 1;
            if (pre_idx == -1) {
                pre_idx = $(".trun_box li").length - 1;
            }
            var next_diagram = $('.trun_box li[data-pic-num="' + pre_idx + '"]');
            $(".trun_box li").eq(0).animate({
                "margin-left": width
            }, 500, "ease", function() {
                cur_diagram.removeClass("now");
                next_diagram.addClass("now");
                var last = $(".trun_box li").eq($(".trun_box li").length - 1);
                last.css("margin-left", 0);
                last.remove();
                $(".trun_box").prepend(last);
                $(this).css("margin-left", 0);
                $(".trun_pic_title ul li").removeClass("now");
                $(".trun_pic_title ul li").eq(pre_idx).addClass("now");
                $(".trun_pic_num ul li").removeClass("now");
                $(".trun_pic_num ul li").eq(pre_idx).addClass("now");
            });
        };
        var initIndexEvent = function() {
            $(".article_lump").live("tap", function(e) {
                if ($(e.target).hasClass("board_manage")) {
                    return false;
                }
                $$board_module.loadTopics($(this).data("board-id"));
                return false;
            });
            $(".bar_right_user").live("tap", function() {
                var user_info = $$user.cyan_user;
                if (!user_info || user_info.error_code === 10207) {
                    return;
                }
                $$profile_module.getUserReplies();
                return false;
            });
            $(".trun_box li a").live("tap", function() {
                $$thread_module.showTopic($(this).data("thread-id"));
            });
            var start = [];
            var end = [];
            $(".turn_wrap").live("touchstart", function(e) {
                start[0] = e.touches[0].clientX;
                start[1] = e.touches[0].clientY;
            }).live("touchend", function(e) {
                end[0] = e.changedTouches[0].clientX;
                end[1] = e.changedTouches[0].clientY;
                if (Math.abs(end[0] - start[0]) > 100 && Math.abs((end[0] - start[0]) / (end[1] - start[1])) > 2) {
                    if (end[0] - start[0] < 0) {
                        nextDiagram();
                    } else {
                        preDiagram();
                    }
                }
            });
            $(".board_manage").live("tap", function() {
                var board_id = $(this).parents(".article_lump").data("board-id");
                $$board_topic_manage.boardTopicsManage(board_id, "UNAUDIT");
                return false;
            });
        };
        var loadBoard = function() {
            var params = {
                client_id: $$config.client_id
            };
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/index",
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "loadBoardCallBack",
                scriptCharset: "utf-8",
                cache: false,
                data: params,
                success: function(data) {
                    data.config = $$config.backend_config;
                    data.base_url = "http://comment.bjcnc.img.sohucs.com";
                    data.default_img = "http://changyan.itc.cn/upload/mobile/wap-imgs/wapb11.png";
                    $.when($$user.ready_trigger).done(function() {
                        data.user = $$user.cyan_user;
                        var topic_load_render = $$template.compile(index_tmpl.board_list_tmpl.join("\r\n"));
                        var load_html = topic_load_render(data);
                        $("#sohu-changquan").html(load_html);
                    });
                }
            });
        };
        initIndexEvent();
        var index_module = {
            loadBoard: loadBoard
        };
        module.exports = index_module;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/user/changquan_logout_module.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$template = require("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var $$user = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_user.js");
        var sso_isv_login;
        var sso_isv_logout;
        var sso_isv_userinfo;
        var mobile_isv_login_url;
        var client_id;
        function logout() {
            var sohuplus_logout = "http://plus.sohu.com/a/spassport/logoutservice";
            var passport_logout = "http://passport.sohu.com/sso/logout.jsp";
            var cyan_logout_api = "http://changyan.sohu.com/api/2/logout";
            $.ajax({
                url: cyan_logout_api,
                dataType: "jsonp",
                jsonp: "callback",
                data: {
                    client_id: client_id
                },
                success: function(data) {
                    if (!data.error_code) {
                        $$user.cyan_user = undefined;
                        var sso = sso_isv_login && sso_isv_logout && sso_isv_userinfo && mobile_isv_login_url;
                        var isv_user = $$user.isv_user;
                        if (sso && isv_user && isv_user.is_login) {
                            logoutIsv();
                        }
                    }
                }
            });
            $.ajax({
                url: sohuplus_logout,
                dataType: "jsonp",
                jsonp: "cb",
                jsonpCallback: "quit",
                cache: false,
                success: function(data) {
                    if (data.code == 0) {
                        $$user.cyan_user = undefined;
                    } else {
                        console.log("登出失败");
                    }
                }
            });
            $.ajax({
                url: passport_logout,
                dataType: "jsonp",
                cache: false,
                success: function(data) {
                    console.log(data.logout_status);
                }
            });
        }
        function logoutIsv() {
            var isv_logout_api = decodeURIComponent(sso_isv_logout);
            $.ajax({
                url: isv_logout_api,
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "isv_logout_cb",
                success: function(data) {
                    if (data.code == 1) {
                        if (data.js_src) {
                            var js_src = data.js_src;
                            var ready = [];
                            for (var i = 0; i < js_src.length; i++) {
                                ready[i] = false;
                            }
                            var is_ready = function() {
                                for (var i = 0; i < js_src.length; i++) {
                                    if (!ready[i]) return false;
                                }
                                return true;
                            };
                            for (var i = 0; i < js_src.length; i++) {
                                $.ajax({
                                    url: js_src[i],
                                    type: "get",
                                    dataType: "jsonp",
                                    success: function() {
                                        ready[i] = true;
                                        if (is_ready() && data.reload_page) {
                                            window.location.reload();
                                        }
                                    }
                                });
                            }
                            if (data.reload_page) {
                                setTimeout(function() {
                                    window.location.reload();
                                }, 2e3);
                            }
                        } else {
                            window.location.reload();
                        }
                    }
                }
            });
        }
        var initLogout = function() {
            client_id = $$config.client_id;
            var bbs_global_conf = $$config.backend_config["0"];
            sso_isv_login = bbs_global_conf.sso_isv_login;
            sso_isv_logout = bbs_global_conf.sso_isv_logout;
            sso_isv_userinfo = bbs_global_conf.sso_isv_userInfo;
            mobile_isv_login_url = bbs_global_conf.mobile_isv_login_url;
        };
        var logout_module = {
            initLogout: initLogout,
            logout: logout
        };
        module.exports = logout_module;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/user/changquan_login_module.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$template = require("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var $$user = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_user.js");
        var $$logout_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/user/changquan_logout_module.js");
        var login_tmpl = [ '<div id="sohu_CQ_mark" class="reset_public" style="display:none;"></div>', '<section id="login_layer" class="reset_public wrapper_CQ_public home_login" style="display:none;">', '<section class="home_login_wrap">', '<h3 class="login_name"><span>登&nbsp;&nbsp;录</span></h3>', '<div class="login_select">', '<ul class="clear_public">', "{{if sso}}", '<li><span id="sso_login" class="select_single" style="background-image:url(\'{{mobile_isv_login_icon}}\')">单点</span></li>', "{{/if}}", '<li><span class="select_sina platform-login" data-platform-id="2">新浪</span></li>', '<li><span class="select_qq platform-login" data-platform-id="3">腾讯</span></li>', '<li><span class="select_renren platform-login" data-platform-id="6">人人</span></li>', "</ul>", "</div>", "</section>", "</section>" ];
        var sso_isv_login;
        var sso_isv_logout;
        var sso_isv_userinfo;
        var mobile_isv_login_url;
        var mobile_isv_login_icon;
        var sso_type;
        var client_id;
        var addLoginLayer = function() {
            var data = {};
            data.sso = sso_isv_login && sso_isv_logout && sso_isv_userinfo && mobile_isv_login_url;
            data.mobile_isv_login_icon = mobile_isv_login_icon;
            var login_layer_render = $$template.compile(login_tmpl.join("\r\n"));
            var login_layer = login_layer_render(data);
            $("body").append(login_layer);
            $("#sso_login").live("tap", function() {
                var login_url = decodeURIComponent(mobile_isv_login_url);
                var param_from = encodeURIComponent(window.location.href);
                login_url = login_url.indexOf("?") >= 0 ? login_url + "&from=" + param_from : login_url + "?from=" + param_from;
                window.location.href = login_url;
            });
            $(".platform-login").live("tap", function() {
                var client_id = $$config.client_id;
                var platform_id = $(this).data("platform-id");
                var url = encodeURIComponent(encodeURIComponent(window.location.href));
                var login_url = "http://changyan.sohu.com/api/2/login/passport?client_id=" + client_id + "&platform_id=" + platform_id + "&url=" + url + "&connName=changquan_wap&isMobile=true";
                window.location.href = login_url;
            });
            $("#sohu_CQ_mark").live("tap", function() {
                $(this).hide();
                $("#login_layer").hide();
            });
        };
        function getUserInfo(login_sso) {
            var param = {
                client_id: client_id
            };
            $.ajax({
                url: "http://changyan.sohu.com/api/2/user/info",
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "user_info_cb",
                cache: false,
                data: param,
                success: function(data) {
                    $$user.cyan_user = data;
                    $$user.ready_trigger.resolve();
                    if (!data.error_code) {
                        if (login_sso) loginIsv($$user.cyan_user);
                    }
                }
            });
        }
        function getIsvUserInfo() {
            var user_info_api = decodeURIComponent(sso_isv_userinfo);
            $.ajax({
                url: user_info_api,
                cache: false,
                dataType: "jsonp",
                jsonp: "callback",
                success: function(data) {
                    $$user.isv_user = data;
                    if (data.is_login) {
                        loginCyan(data.user, data.sign);
                    } else if (sso_type == 1) {
                        getUserInfo(true);
                    } else {
                        $$logout_module.logout();
                        getUserInfo();
                    }
                },
                error: function() {
                    getUserInfo(true);
                }
            });
        }
        function loginIsv(user) {
            if (user && !user.error_code) {
                var isv_sso_login_api = decodeURIComponent(sso_isv_login);
                $.ajax({
                    url: isv_sso_login_api,
                    dataType: "jsonp",
                    data: {
                        cy_user_id: user.user_id,
                        user_id: user.isv_refer_id,
                        nickname: encodeURIComponent(user.nickname),
                        img_url: encodeURIComponent(user.img_url),
                        profile_url: encodeURIComponent(user.profile_url),
                        sign: encodeURIComponent(user.sign)
                    },
                    jsonp: "callback",
                    jsonpCallback: "isv_login_cb",
                    success: function(data) {
                        if (data.user_id) {
                            if (data.js_src) {
                                var js_src = data.js_src;
                                var ready = [];
                                for (var i = 0; i < js_src.length; i++) {
                                    ready[i] = false;
                                }
                                var is_ready = function() {
                                    for (var i = 0; i < js_src.length; i++) {
                                        if (!ready[i]) return false;
                                    }
                                    return true;
                                };
                                for (var i = 0; i < js_src.length; i++) {
                                    $.ajax({
                                        url: js_src[i],
                                        type: "get",
                                        dataType: "jsonp",
                                        success: function(data) {
                                            ready[i] = true;
                                            if (is_ready()) {
                                                window.location.reload();
                                            }
                                        }
                                    });
                                }
                                setTimeout(function() {
                                    window.location.reload();
                                }, 2e3);
                            } else {
                                window.location.reload();
                            }
                        }
                    }
                });
            }
        }
        function loginCyan(isv_user, sign) {
            var login_isv_api = "http://changyan.sohu.com/api/2/login/isv";
            $.ajax({
                url: login_isv_api,
                cache: false,
                dataType: "jsonp",
                jsonp: "callback",
                data: {
                    client_id: client_id,
                    nickname: isv_user.nickname,
                    img_url: isv_user.img_url,
                    profile_url: isv_user.profile_url,
                    isv_user_id: isv_user.user_id,
                    sign: sign
                },
                success: function(data) {
                    if (data.error_code) {
                        $.ajax({
                            url: data.error_msg,
                            cache: false,
                            dataType: "jsonp",
                            jsonp: "cb",
                            jsonpCallback: "cb",
                            success: function() {
                                loginCyan(isv_user, sign);
                            }
                        });
                    } else {
                        $$user.cyan_user = data;
                        $$user.ready_trigger.resolve();
                    }
                }
            });
        }
        var initLogin = function() {
            client_id = $$config.client_id;
            var bbs_global_conf = $$config.backend_config["0"];
            sso_isv_login = bbs_global_conf.sso_isv_login;
            sso_isv_logout = bbs_global_conf.sso_isv_logout;
            sso_isv_userinfo = bbs_global_conf.sso_isv_userInfo;
            mobile_isv_login_url = bbs_global_conf.mobile_isv_login_url;
            mobile_isv_login_icon = bbs_global_conf.mobile_isv_login_icon;
            sso_type = bbs_global_conf.sso_type;
            addLoginLayer();
            var sso = sso_isv_login && sso_isv_logout && sso_isv_userinfo && mobile_isv_login_url;
            if (sso) getIsvUserInfo(); else getUserInfo();
        };
        var login_module = {
            initLogin: initLogin,
            showLoginLayer: function() {
                $("#sohu_CQ_mark").show();
                $("#login_layer").show();
            },
            hideLoginLayer: function() {
                $("#sohu_CQ_mark").hide();
                $("#login_layer").hide();
            }
        };
        module.exports = login_module;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_user.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var user = {
            ready_trigger: $.Deferred(),
            cyan_user: undefined,
            isv_user: undefined
        };
        module.exports = user;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_init.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var $$utils = require("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_utils.js");
        var $$user = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_user.js");
        var $$login_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/user/changquan_login_module.js");
        var $$logout_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/user/changquan_logout_module.js");
        var $$index_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_index_module.js");
        var $$board_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_board_module.js");
        var $$thread_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_thread_module.js");
        var $$edit_thread_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/bbs/changquan_edit_thread_module.js");
        var $$profile_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/user/changquan_profile.js");
        var $$board_topic_manage = require("D:/workspaces/cyan/changquan/tmp-build/widget/moderator/changquan_board_topic_manage.js");
        var $$board_comment_manage = require("D:/workspaces/cyan/changquan/tmp-build/widget/moderator/changquan_comment_manage.js");
        var init_module = {
            init: function() {
                init();
            }
        };
        var init = function() {
            $("body").css({
                padding: 0
            });
            $("body").css({
                margin: 0
            });
            var head = document.getElementsByTagName("head")[0];
            var meta = document.getElementsByName("viewport")[0];
            if (!meta) {
                meta = document.createElement("meta");
                meta.setAttribute("name", "viewport");
                meta.setAttribute("content", "initial-scale=1.0,user-scalable=no,minimum-scale=1.0,maximum-scale=1.0,width=device-width");
                head.appendChild(meta);
            }
            $(window).bind("popstate", loadPage);
            $$config.initConf();
            $.when($$config.ready_trigger).done(function() {
                $$login_module.initLogin();
                $$logout_module.initLogout();
                $$profile_module.initProfile();
                loadPage();
            });
            var login_action = [ "home", "editthread" ];
            $("[data-hash]").live("tap", function() {
                var hash = $(this).data("hash");
                var action = hash.split("_")[0];
                if ($$utils.arrayContains(login_action, action)) {
                    var user_info = $$user.cyan_user;
                    if (!user_info || user_info.error_code === 10207) {
                        $$login_module.showLoginLayer();
                        return;
                    }
                }
                var title = $(this).data("title");
                var href = window.location.href;
                href = href.replace(/#.*$/, "") + "#" + hash;
                window.history.pushState({}, title, href);
                var id = $(this).attr("id");
                switch (id) {
                  case "back_to_index":
                    $$index_module.loadBoard();
                    return;
                  case "back_to_board":
                    var board_id = $(this).data("board-id");
                    $$board_module.loadTopics(board_id);
                    return;
                  case "back_to_boardtaudit":
                    var board_id = $(this).data("board-id");
                    $$board_topic_manage.boardTopicsManage(board_id, "UNAUDIT");
                    return;
                }
            });
        };
        var loadPage = function() {
            var url = window.location.href.toString();
            var start = url.lastIndexOf("#");
            if (start != -1) {
                var load_params = url.substr(start + 1).split("_");
                switch (load_params[0]) {
                  case "board":
                    $$board_module.loadTopics(load_params[1]);
                    return;
                  case "topic":
                    $$thread_module.showTopic(load_params[1]);
                    return;
                  case "editthread":
                    $$edit_thread_module.editThread(load_params[1], load_params[2]);
                    return;
                  case "home":
                    $$profile_module.getUserReplies();
                    return;
                  case "boardtaudit":
                    $$board_topic_manage.boardTopicsManage(load_params[1], "NORMAL");
                    return;
                  case "boardcaudit":
                    $$board_comment_manage.boardCommentsManage(load_params[1], "UNAUDIT");
                    return;
                  case "threadcaudit":
                    $$board_comment_manage.threadCommentsManage(load_params[1], load_params[2], "UNAUDIT");
                    return;
                }
            }
            $$index_module.loadBoard();
        };
        module.exports = init_module;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var conf = {
            ready_trigger: $.Deferred(),
            initConf: function() {
                getConf();
            },
            resourceRoot: undefined,
            client_id: undefined,
            backend_config: undefined,
            img_type: [ "bmp", "gif", "jpeg", "jpg", "jpe", "png" ]
        };
        var getConf = function() {
            var params = {
                client_id: conf.client_id
            };
            $.ajax({
                url: "http://changyan.sohu.com/api/bbs/config",
                dataType: "jsonp",
                jsonp: "callback",
                jsonpCallback: "loadConfig",
                scriptCharset: "utf-8",
                cache: false,
                data: params,
                success: function(data) {
                    $("#sohu-changquan").width("100%");
                    conf.backend_config = data.config;
                    conf.ready_trigger.resolve();
                }
            });
        };
        module.exports = conf;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_utils.js", function(require, exports, module) {
        var getFormatDate = function(l) {
            var now = new Date;
            var date = new Date(l);
            if (now.getTime() - l <= 60 * 1e3) {
                return "刚刚";
            }
            if (now.getTime() - l <= 3600 * 1e3) {
                var minute = Math.abs(l - now.getTime()) / 1e3 / 60;
                var minute = Math.round(minute);
                return minute + "分钟之前";
            }
            if (now.getTime() - l <= 3600 * 1e3 * 24) {
                return formatDate(date, "hh:mm");
            }
            return formatDate(date, "MM月dd日");
        };
        var formatDate = function(date, format) {
            var o = {
                "M+": date.getMonth() + 1,
                "d+": date.getDate(),
                "h+": date.getHours(),
                "m+": date.getMinutes(),
                "s+": date.getSeconds(),
                "q+": Math.floor((date.getMonth() + 3) / 3),
                S: date.getMilliseconds()
            };
            if (/(y+)/.test(format)) {
                format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            for (var k in o) {
                if ((new RegExp("(" + k + ")")).test(format)) {
                    format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
                }
            }
            return format;
        };
        var arrayContains = function(array, a) {
            for (var i = 0; i < array.length; i++) {
                if (array[i] == a) {
                    return true;
                }
            }
            return false;
        };
        var util = {
            getFormatDate: getFormatDate,
            arrayContains: arrayContains
        };
        module.exports = util;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js", function(require, exports, module) {
        var template = function(filename, content) {
            return typeof content === "string" ? compile(content, {
                filename: filename
            }) : renderFile(filename, content);
        };
        template.version = "3.0.0";
        template.config = function(name, value) {
            defaults[name] = value;
        };
        var defaults = template.defaults = {
            openTag: "<%",
            closeTag: "%>",
            escape: true,
            cache: true,
            compress: false,
            parser: null
        };
        var cacheStore = template.cache = {};
        template.render = function(source, options) {
            return compile(source, options);
        };
        var renderFile = template.renderFile = function(filename, data) {
            var fn = template.get(filename) || showDebugInfo({
                filename: filename,
                name: "Render Error",
                message: "Template not found"
            });
            return data ? fn(data) : fn;
        };
        template.get = function(filename) {
            var cache;
            if (cacheStore[filename]) {
                cache = cacheStore[filename];
            } else if (typeof document === "object") {
                var elem = document.getElementById(filename);
                if (elem) {
                    var source = (elem.value || elem.innerHTML).replace(/^\s*|\s*$/g, "");
                    cache = compile(source, {
                        filename: filename
                    });
                }
            }
            return cache;
        };
        var toString = function(value, type) {
            if (typeof value !== "string") {
                type = typeof value;
                if (type === "number") {
                    value += "";
                } else if (type === "function") {
                    value = toString(value.call(value));
                } else {
                    value = "";
                }
            }
            return value;
        };
        var escapeMap = {
            "<": "&#60;",
            ">": "&#62;",
            '"': "&#34;",
            "'": "&#39;",
            "&": "&#38;"
        };
        var escapeFn = function(s) {
            return escapeMap[s];
        };
        var escapeHTML = function(content) {
            return toString(content).replace(/&(?![\w#]+;)|[<>"']/g, escapeFn);
        };
        var isArray = Array.isArray || function(obj) {
            return {}.toString.call(obj) === "[object Array]";
        };
        var each = function(data, callback) {
            var i, len;
            if (isArray(data)) {
                for (i = 0, len = data.length; i < len; i++) {
                    callback.call(data, data[i], i, data);
                }
            } else {
                for (i in data) {
                    callback.call(data, data[i], i);
                }
            }
        };
        var utils = template.utils = {
            $helpers: {},
            $include: renderFile,
            $string: toString,
            $escape: escapeHTML,
            $each: each
        };
        template.helper = function(name, helper) {
            helpers[name] = helper;
        };
        var helpers = template.helpers = utils.$helpers;
        template.onerror = function(e) {
            var message = "Template Error\n\n";
            for (var name in e) {
                message += "<" + name + ">\n" + e[name] + "\n\n";
            }
            if (typeof console === "object") {
                console.error(message);
            }
        };
        var showDebugInfo = function(e) {
            template.onerror(e);
            return function() {
                return "{Template Error}";
            };
        };
        var compile = template.compile = function(source, options) {
            options = options || {};
            for (var name in defaults) {
                if (options[name] === undefined) {
                    options[name] = defaults[name];
                }
            }
            var filename = options.filename;
            try {
                var Render = compiler(source, options);
            } catch (e) {
                e.filename = filename || "anonymous";
                e.name = "Syntax Error";
                return showDebugInfo(e);
            }
            function render(data) {
                try {
                    return new Render(data, filename) + "";
                } catch (e) {
                    if (!options.debug) {
                        options.debug = true;
                        return compile(source, options)(data);
                    }
                    return showDebugInfo(e)();
                }
            }
            render.prototype = Render.prototype;
            render.toString = function() {
                return Render.toString();
            };
            if (filename && options.cache) {
                cacheStore[filename] = render;
            }
            return render;
        };
        var forEach = utils.$each;
        var KEYWORDS = "break,case,catch,continue,debugger,default,delete,do,else,false" + ",finally,for,function,if,in,instanceof,new,null,return,switch,this" + ",throw,true,try,typeof,var,void,while,with" + ",abstract,boolean,byte,char,class,const,double,enum,export,extends" + ",final,float,goto,implements,import,int,interface,long,native" + ",package,private,protected,public,short,static,super,synchronized" + ",throws,transient,volatile" + ",arguments,let,yield" + ",undefined";
        var REMOVE_RE = /\/\*[\w\W]*?\*\/|\/\/[^\n]*\n|\/\/[^\n]*$|"(?:[^"\\]|\\[\w\W])*"|'(?:[^'\\]|\\[\w\W])*'|\s*\.\s*[$\w\.]+/g;
        var SPLIT_RE = /[^\w$]+/g;
        var KEYWORDS_RE = new RegExp([ "\\b" + KEYWORDS.replace(/,/g, "\\b|\\b") + "\\b" ].join("|"), "g");
        var NUMBER_RE = /^\d[^,]*|,\d[^,]*/g;
        var BOUNDARY_RE = /^,+|,+$/g;
        var SPLIT2_RE = /^$|,+/;
        function getVariable(code) {
            return code.replace(REMOVE_RE, "").replace(SPLIT_RE, ",").replace(KEYWORDS_RE, "").replace(NUMBER_RE, "").replace(BOUNDARY_RE, "").split(SPLIT2_RE);
        }
        function stringify(code) {
            return "'" + code.replace(/('|\\)/g, "\\$1").replace(/\r/g, "\\r").replace(/\n/g, "\\n") + "'";
        }
        function compiler(source, options) {
            var debug = options.debug;
            var openTag = options.openTag;
            var closeTag = options.closeTag;
            var parser = options.parser;
            var compress = options.compress;
            var escape = options.escape;
            var line = 1;
            var uniq = {
                $data: 1,
                $filename: 1,
                $utils: 1,
                $helpers: 1,
                $out: 1,
                $line: 1
            };
            var isNewEngine = "".trim;
            var replaces = isNewEngine ? [ "$out='';", "$out+=", ";", "$out" ] : [ "$out=[];", "$out.push(", ");", "$out.join('')" ];
            var concat = isNewEngine ? "$out+=text;return $out;" : "$out.push(text);";
            var print = "function(){" + "var text=''.concat.apply('',arguments);" + concat + "}";
            var include = "function(filename,data){" + "data=data||$data;" + "var text=$utils.$include(filename,data,$filename);" + concat + "}";
            var headerCode = "'use strict';" + "var $utils=this,$helpers=$utils.$helpers," + (debug ? "$line=0," : "");
            var mainCode = replaces[0];
            var footerCode = "return new String(" + replaces[3] + ");";
            forEach(source.split(openTag), function(code) {
                code = code.split(closeTag);
                var $0 = code[0];
                var $1 = code[1];
                if (code.length === 1) {
                    mainCode += html($0);
                } else {
                    mainCode += logic($0);
                    if ($1) {
                        mainCode += html($1);
                    }
                }
            });
            var code = headerCode + mainCode + footerCode;
            if (debug) {
                code = "try{" + code + "}catch(e){" + "throw {" + "filename:$filename," + "name:'Render Error'," + "message:e.message," + "line:$line," + "source:" + stringify(source) + ".split(/\\n/)[$line-1].replace(/^\\s+/,'')" + "};" + "}";
            }
            try {
                var Render = new Function("$data", "$filename", code);
                Render.prototype = utils;
                return Render;
            } catch (e) {
                e.temp = "function anonymous($data,$filename) {" + code + "}";
                throw e;
            }
            function html(code) {
                line += code.split(/\n/).length - 1;
                if (compress) {
                    code = code.replace(/\s+/g, " ").replace(/<!--[\w\W]*?-->/g, "");
                }
                if (code) {
                    code = replaces[1] + stringify(code) + replaces[2] + "\n";
                }
                return code;
            }
            function logic(code) {
                var thisLine = line;
                if (parser) {
                    code = parser(code, options);
                } else if (debug) {
                    code = code.replace(/\n/g, function() {
                        line++;
                        return "$line=" + line + ";";
                    });
                }
                if (code.indexOf("=") === 0) {
                    var escapeSyntax = escape && !/^=[=#]/.test(code);
                    code = code.replace(/^=[=#]?|[\s;]*$/g, "");
                    if (escapeSyntax) {
                        var name = code.replace(/\s*\([^\)]+\)/, "");
                        if (!utils[name] && !/^(include|print)$/.test(name)) {
                            code = "$escape(" + code + ")";
                        }
                    } else {
                        code = "$string(" + code + ")";
                    }
                    code = replaces[1] + code + replaces[2];
                }
                if (debug) {
                    code = "$line=" + thisLine + ";" + code;
                }
                forEach(getVariable(code), function(name) {
                    if (!name || uniq[name]) {
                        return;
                    }
                    var value;
                    if (name === "print") {
                        value = print;
                    } else if (name === "include") {
                        value = include;
                    } else if (utils[name]) {
                        value = "$utils." + name;
                    } else if (helpers[name]) {
                        value = "$helpers." + name;
                    } else {
                        value = "$data." + name;
                    }
                    headerCode += name + "=" + value + ",";
                    uniq[name] = true;
                });
                return code + "\n";
            }
        }
        defaults.openTag = "{{";
        defaults.closeTag = "}}";
        var filtered = function(js, filter) {
            var parts = filter.split(":");
            var name = parts.shift();
            var args = parts.join(":") || "";
            if (args) {
                args = ", " + args;
            }
            return "$helpers." + name + "(" + js + args + ")";
        };
        defaults.parser = function(code, options) {
            code = code.replace(/^\s/, "");
            var split = code.split(" ");
            var key = split.shift();
            var args = split.join(" ");
            switch (key) {
              case "if":
                code = "if(" + args + "){";
                break;
              case "else":
                if (split.shift() === "if") {
                    split = " if(" + split.join(" ") + ")";
                } else {
                    split = "";
                }
                code = "}else" + split + "{";
                break;
              case "/if":
                code = "}";
                break;
              case "each":
                var object = split[0] || "$data";
                var as = split[1] || "as";
                var value = split[2] || "$value";
                var index = split[3] || "$index";
                var param = value + "," + index;
                if (as !== "as") {
                    object = "[]";
                }
                code = "$each(" + object + ",function(" + param + "){";
                break;
              case "/each":
                code = "});";
                break;
              case "echo":
                code = "print(" + args + ");";
                break;
              case "print":
              case "include":
                code = key + "(" + split.join(",") + ");";
                break;
              default:
                if (/^\s*\|\s*[\w\$]/.test(args)) {
                    var escape = true;
                    if (code.indexOf("#") === 0) {
                        code = code.substr(1);
                        escape = false;
                    }
                    var i = 0;
                    var array = code.split("|");
                    var len = array.length;
                    var val = array[i++];
                    for (; i < len; i++) {
                        val = filtered(val, array[i]);
                    }
                    code = (escape ? "=" : "=#") + val;
                } else if (template.helpers[key]) {
                    code = "=#" + key + "(" + split.join(",") + ");";
                } else {
                    code = "=" + code;
                }
                break;
            }
            return code;
        };
        module.exports = template;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js", function(require, exports, module) {
        var Zepto = function() {
            var undefined, key, $, classList, emptyArray = [], slice = emptyArray.slice, filter = emptyArray.filter, document = window.document, elementDisplay = {}, classCache = {}, cssNumber = {
                "column-count": 1,
                columns: 1,
                "font-weight": 1,
                "line-height": 1,
                opacity: 1,
                "z-index": 1,
                zoom: 1
            }, fragmentRE = /^\s*<(\w+|!)[^>]*>/, singleTagRE = /^<(\w+)\s*\/?>(?:<\/\1>|)$/, tagExpanderRE = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/ig, rootNodeRE = /^(?:body|html)$/i, capitalRE = /([A-Z])/g, methodAttributes = [ "val", "css", "html", "text", "data", "width", "height", "offset" ], adjacencyOperators = [ "after", "prepend", "before", "append" ], table = document.createElement("table"), tableRow = document.createElement("tr"), containers = {
                tr: document.createElement("tbody"),
                tbody: table,
                thead: table,
                tfoot: table,
                td: tableRow,
                th: tableRow,
                "*": document.createElement("div")
            }, readyRE = /complete|loaded|interactive/, simpleSelectorRE = /^[\w-]*$/, class2type = {}, toString = class2type.toString, zepto = {}, camelize, uniq, tempParent = document.createElement("div"), propMap = {
                tabindex: "tabIndex",
                readonly: "readOnly",
                "for": "htmlFor",
                "class": "className",
                maxlength: "maxLength",
                cellspacing: "cellSpacing",
                cellpadding: "cellPadding",
                rowspan: "rowSpan",
                colspan: "colSpan",
                usemap: "useMap",
                frameborder: "frameBorder",
                contenteditable: "contentEditable"
            }, isArray = Array.isArray || function(object) {
                return object instanceof Array;
            };
            zepto.matches = function(element, selector) {
                if (!selector || !element || element.nodeType !== 1) return false;
                var matchesSelector = element.webkitMatchesSelector || element.mozMatchesSelector || element.oMatchesSelector || element.matchesSelector;
                if (matchesSelector) return matchesSelector.call(element, selector);
                var match, parent = element.parentNode, temp = !parent;
                if (temp) (parent = tempParent).appendChild(element);
                match = ~zepto.qsa(parent, selector).indexOf(element);
                temp && tempParent.removeChild(element);
                return match;
            };
            function type(obj) {
                return obj == null ? String(obj) : class2type[toString.call(obj)] || "object";
            }
            function isFunction(value) {
                return type(value) == "function";
            }
            function isWindow(obj) {
                return obj != null && obj == obj.window;
            }
            function isDocument(obj) {
                return obj != null && obj.nodeType == obj.DOCUMENT_NODE;
            }
            function isObject(obj) {
                return type(obj) == "object";
            }
            function isPlainObject(obj) {
                return isObject(obj) && !isWindow(obj) && Object.getPrototypeOf(obj) == Object.prototype;
            }
            function likeArray(obj) {
                return typeof obj.length == "number";
            }
            function compact(array) {
                return filter.call(array, function(item) {
                    return item != null;
                });
            }
            function flatten(array) {
                return array.length > 0 ? $.fn.concat.apply([], array) : array;
            }
            camelize = function(str) {
                return str.replace(/-+(.)?/g, function(match, chr) {
                    return chr ? chr.toUpperCase() : "";
                });
            };
            function dasherize(str) {
                return str.replace(/::/g, "/").replace(/([A-Z]+)([A-Z][a-z])/g, "$1_$2").replace(/([a-z\d])([A-Z])/g, "$1_$2").replace(/_/g, "-").toLowerCase();
            }
            uniq = function(array) {
                return filter.call(array, function(item, idx) {
                    return array.indexOf(item) == idx;
                });
            };
            function classRE(name) {
                return name in classCache ? classCache[name] : classCache[name] = new RegExp("(^|\\s)" + name + "(\\s|$)");
            }
            function maybeAddPx(name, value) {
                return typeof value == "number" && !cssNumber[dasherize(name)] ? value + "px" : value;
            }
            function defaultDisplay(nodeName) {
                var element, display;
                if (!elementDisplay[nodeName]) {
                    element = document.createElement(nodeName);
                    document.body.appendChild(element);
                    display = getComputedStyle(element, "").getPropertyValue("display");
                    element.parentNode.removeChild(element);
                    display == "none" && (display = "block");
                    elementDisplay[nodeName] = display;
                }
                return elementDisplay[nodeName];
            }
            function children(element) {
                return "children" in element ? slice.call(element.children) : $.map(element.childNodes, function(node) {
                    if (node.nodeType == 1) return node;
                });
            }
            zepto.fragment = function(html, name, properties) {
                var dom, nodes, container;
                if (singleTagRE.test(html)) dom = $(document.createElement(RegExp.$1));
                if (!dom) {
                    if (html.replace) html = html.replace(tagExpanderRE, "<$1></$2>");
                    if (name === undefined) name = fragmentRE.test(html) && RegExp.$1;
                    if (!(name in containers)) name = "*";
                    container = containers[name];
                    container.innerHTML = "" + html;
                    dom = $.each(slice.call(container.childNodes), function() {
                        container.removeChild(this);
                    });
                }
                if (isPlainObject(properties)) {
                    nodes = $(dom);
                    $.each(properties, function(key, value) {
                        if (methodAttributes.indexOf(key) > -1) nodes[key](value); else nodes.attr(key, value);
                    });
                }
                return dom;
            };
            zepto.Z = function(dom, selector) {
                dom = dom || [];
                dom.__proto__ = $.fn;
                dom.selector = selector || "";
                return dom;
            };
            zepto.isZ = function(object) {
                return object instanceof zepto.Z;
            };
            zepto.init = function(selector, context) {
                var dom;
                if (!selector) return zepto.Z(); else if (typeof selector == "string") {
                    selector = selector.trim();
                    if (selector[0] == "<" && fragmentRE.test(selector)) dom = zepto.fragment(selector, RegExp.$1, context), selector = null; else if (context !== undefined) return $(context).find(selector); else dom = zepto.qsa(document, selector);
                } else if (isFunction(selector)) return $(document).ready(selector); else if (zepto.isZ(selector)) return selector; else {
                    if (isArray(selector)) dom = compact(selector); else if (isObject(selector)) dom = [ selector ], selector = null; else if (fragmentRE.test(selector)) dom = zepto.fragment(selector.trim(), RegExp.$1, context), selector = null; else if (context !== undefined) return $(context).find(selector); else dom = zepto.qsa(document, selector);
                }
                return zepto.Z(dom, selector);
            };
            $ = function(selector, context) {
                return zepto.init(selector, context);
            };
            function extend(target, source, deep) {
                for (key in source) if (deep && (isPlainObject(source[key]) || isArray(source[key]))) {
                    if (isPlainObject(source[key]) && !isPlainObject(target[key])) target[key] = {};
                    if (isArray(source[key]) && !isArray(target[key])) target[key] = [];
                    extend(target[key], source[key], deep);
                } else if (source[key] !== undefined) target[key] = source[key];
            }
            $.extend = function(target) {
                var deep, args = slice.call(arguments, 1);
                if (typeof target == "boolean") {
                    deep = target;
                    target = args.shift();
                }
                args.forEach(function(arg) {
                    extend(target, arg, deep);
                });
                return target;
            };
            zepto.qsa = function(element, selector) {
                var found, maybeID = selector[0] == "#", maybeClass = !maybeID && selector[0] == ".", nameOnly = maybeID || maybeClass ? selector.slice(1) : selector, isSimple = simpleSelectorRE.test(nameOnly);
                return isDocument(element) && isSimple && maybeID ? (found = element.getElementById(nameOnly)) ? [ found ] : [] : element.nodeType !== 1 && element.nodeType !== 9 ? [] : slice.call(isSimple && !maybeID ? maybeClass ? element.getElementsByClassName(nameOnly) : element.getElementsByTagName(selector) : element.querySelectorAll(selector));
            };
            function filtered(nodes, selector) {
                return selector == null ? $(nodes) : $(nodes).filter(selector);
            }
            $.contains = document.documentElement.contains ? function(parent, node) {
                return parent !== node && parent.contains(node);
            } : function(parent, node) {
                while (node && (node = node.parentNode)) if (node === parent) return true;
                return false;
            };
            function funcArg(context, arg, idx, payload) {
                return isFunction(arg) ? arg.call(context, idx, payload) : arg;
            }
            function setAttribute(node, name, value) {
                value == null ? node.removeAttribute(name) : node.setAttribute(name, value);
            }
            function className(node, value) {
                var klass = node.className, svg = klass && klass.baseVal !== undefined;
                if (value === undefined) return svg ? klass.baseVal : klass;
                svg ? klass.baseVal = value : node.className = value;
            }
            function deserializeValue(value) {
                var num;
                try {
                    return value ? value == "true" || (value == "false" ? false : value == "null" ? null : !/^0/.test(value) && !isNaN(num = Number(value)) ? num : /^[\[\{]/.test(value) ? $.parseJSON(value) : value) : value;
                } catch (e) {
                    return value;
                }
            }
            $.type = type;
            $.isFunction = isFunction;
            $.isWindow = isWindow;
            $.isArray = isArray;
            $.isPlainObject = isPlainObject;
            $.isEmptyObject = function(obj) {
                var name;
                for (name in obj) return false;
                return true;
            };
            $.inArray = function(elem, array, i) {
                return emptyArray.indexOf.call(array, elem, i);
            };
            $.camelCase = camelize;
            $.trim = function(str) {
                return str == null ? "" : String.prototype.trim.call(str);
            };
            $.uuid = 0;
            $.support = {};
            $.expr = {};
            $.map = function(elements, callback) {
                var value, values = [], i, key;
                if (likeArray(elements)) for (i = 0; i < elements.length; i++) {
                    value = callback(elements[i], i);
                    if (value != null) values.push(value);
                } else for (key in elements) {
                    value = callback(elements[key], key);
                    if (value != null) values.push(value);
                }
                return flatten(values);
            };
            $.each = function(elements, callback) {
                var i, key;
                if (likeArray(elements)) {
                    for (i = 0; i < elements.length; i++) if (callback.call(elements[i], i, elements[i]) === false) return elements;
                } else {
                    for (key in elements) if (callback.call(elements[key], key, elements[key]) === false) return elements;
                }
                return elements;
            };
            $.grep = function(elements, callback) {
                return filter.call(elements, callback);
            };
            if (window.JSON) $.parseJSON = JSON.parse;
            $.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(i, name) {
                class2type["[object " + name + "]"] = name.toLowerCase();
            });
            $.fn = {
                forEach: emptyArray.forEach,
                reduce: emptyArray.reduce,
                push: emptyArray.push,
                sort: emptyArray.sort,
                indexOf: emptyArray.indexOf,
                concat: emptyArray.concat,
                map: function(fn) {
                    return $($.map(this, function(el, i) {
                        return fn.call(el, i, el);
                    }));
                },
                slice: function() {
                    return $(slice.apply(this, arguments));
                },
                ready: function(callback) {
                    if (readyRE.test(document.readyState) && document.body) callback($); else document.addEventListener("DOMContentLoaded", function() {
                        callback($);
                    }, false);
                    return this;
                },
                get: function(idx) {
                    return idx === undefined ? slice.call(this) : this[idx >= 0 ? idx : idx + this.length];
                },
                toArray: function() {
                    return this.get();
                },
                size: function() {
                    return this.length;
                },
                remove: function() {
                    return this.each(function() {
                        if (this.parentNode != null) this.parentNode.removeChild(this);
                    });
                },
                each: function(callback) {
                    emptyArray.every.call(this, function(el, idx) {
                        return callback.call(el, idx, el) !== false;
                    });
                    return this;
                },
                filter: function(selector) {
                    if (isFunction(selector)) return this.not(this.not(selector));
                    return $(filter.call(this, function(element) {
                        return zepto.matches(element, selector);
                    }));
                },
                add: function(selector, context) {
                    return $(uniq(this.concat($(selector, context))));
                },
                is: function(selector) {
                    return this.length > 0 && zepto.matches(this[0], selector);
                },
                not: function(selector) {
                    var nodes = [];
                    if (isFunction(selector) && selector.call !== undefined) this.each(function(idx) {
                        if (!selector.call(this, idx)) nodes.push(this);
                    }); else {
                        var excludes = typeof selector == "string" ? this.filter(selector) : likeArray(selector) && isFunction(selector.item) ? slice.call(selector) : $(selector);
                        this.forEach(function(el) {
                            if (excludes.indexOf(el) < 0) nodes.push(el);
                        });
                    }
                    return $(nodes);
                },
                has: function(selector) {
                    return this.filter(function() {
                        return isObject(selector) ? $.contains(this, selector) : $(this).find(selector).size();
                    });
                },
                eq: function(idx) {
                    return idx === -1 ? this.slice(idx) : this.slice(idx, +idx + 1);
                },
                first: function() {
                    var el = this[0];
                    return el && !isObject(el) ? el : $(el);
                },
                last: function() {
                    var el = this[this.length - 1];
                    return el && !isObject(el) ? el : $(el);
                },
                find: function(selector) {
                    var result, $this = this;
                    if (!selector) result = []; else if (typeof selector == "object") result = $(selector).filter(function() {
                        var node = this;
                        return emptyArray.some.call($this, function(parent) {
                            return $.contains(parent, node);
                        });
                    }); else if (this.length == 1) result = $(zepto.qsa(this[0], selector)); else result = this.map(function() {
                        return zepto.qsa(this, selector);
                    });
                    return result;
                },
                closest: function(selector, context) {
                    var node = this[0], collection = false;
                    if (typeof selector == "object") collection = $(selector);
                    while (node && !(collection ? collection.indexOf(node) >= 0 : zepto.matches(node, selector))) node = node !== context && !isDocument(node) && node.parentNode;
                    return $(node);
                },
                parents: function(selector) {
                    var ancestors = [], nodes = this;
                    while (nodes.length > 0) nodes = $.map(nodes, function(node) {
                        if ((node = node.parentNode) && !isDocument(node) && ancestors.indexOf(node) < 0) {
                            ancestors.push(node);
                            return node;
                        }
                    });
                    return filtered(ancestors, selector);
                },
                parent: function(selector) {
                    return filtered(uniq(this.pluck("parentNode")), selector);
                },
                children: function(selector) {
                    return filtered(this.map(function() {
                        return children(this);
                    }), selector);
                },
                contents: function() {
                    return this.map(function() {
                        return slice.call(this.childNodes);
                    });
                },
                siblings: function(selector) {
                    return filtered(this.map(function(i, el) {
                        return filter.call(children(el.parentNode), function(child) {
                            return child !== el;
                        });
                    }), selector);
                },
                empty: function() {
                    return this.each(function() {
                        this.innerHTML = "";
                    });
                },
                pluck: function(property) {
                    return $.map(this, function(el) {
                        return el[property];
                    });
                },
                show: function() {
                    return this.each(function() {
                        this.style.display == "none" && (this.style.display = "");
                        if (getComputedStyle(this, "").getPropertyValue("display") == "none") this.style.display = defaultDisplay(this.nodeName);
                    });
                },
                replaceWith: function(newContent) {
                    return this.before(newContent).remove();
                },
                wrap: function(structure) {
                    var func = isFunction(structure);
                    if (this[0] && !func) var dom = $(structure).get(0), clone = dom.parentNode || this.length > 1;
                    return this.each(function(index) {
                        $(this).wrapAll(func ? structure.call(this, index) : clone ? dom.cloneNode(true) : dom);
                    });
                },
                wrapAll: function(structure) {
                    if (this[0]) {
                        $(this[0]).before(structure = $(structure));
                        var children;
                        while ((children = structure.children()).length) structure = children.first();
                        $(structure).append(this);
                    }
                    return this;
                },
                wrapInner: function(structure) {
                    var func = isFunction(structure);
                    return this.each(function(index) {
                        var self = $(this), contents = self.contents(), dom = func ? structure.call(this, index) : structure;
                        contents.length ? contents.wrapAll(dom) : self.append(dom);
                    });
                },
                unwrap: function() {
                    this.parent().each(function() {
                        $(this).replaceWith($(this).children());
                    });
                    return this;
                },
                clone: function() {
                    return this.map(function() {
                        return this.cloneNode(true);
                    });
                },
                hide: function() {
                    return this.css("display", "none");
                },
                toggle: function(setting) {
                    return this.each(function() {
                        var el = $(this);
                        (setting === undefined ? el.css("display") == "none" : setting) ? el.show() : el.hide();
                    });
                },
                prev: function(selector) {
                    return $(this.pluck("previousElementSibling")).filter(selector || "*");
                },
                next: function(selector) {
                    return $(this.pluck("nextElementSibling")).filter(selector || "*");
                },
                html: function(html) {
                    return 0 in arguments ? this.each(function(idx) {
                        var originHtml = this.innerHTML;
                        $(this).empty().append(funcArg(this, html, idx, originHtml));
                    }) : 0 in this ? this[0].innerHTML : null;
                },
                text: function(text) {
                    return 0 in arguments ? this.each(function(idx) {
                        var newText = funcArg(this, text, idx, this.textContent);
                        this.textContent = newText == null ? "" : "" + newText;
                    }) : 0 in this ? this[0].textContent : null;
                },
                attr: function(name, value) {
                    var result;
                    return typeof name == "string" && !(1 in arguments) ? !this.length || this[0].nodeType !== 1 ? undefined : !(result = this[0].getAttribute(name)) && name in this[0] ? this[0][name] : result : this.each(function(idx) {
                        if (this.nodeType !== 1) return;
                        if (isObject(name)) for (key in name) setAttribute(this, key, name[key]); else setAttribute(this, name, funcArg(this, value, idx, this.getAttribute(name)));
                    });
                },
                removeAttr: function(name) {
                    return this.each(function() {
                        this.nodeType === 1 && setAttribute(this, name);
                    });
                },
                prop: function(name, value) {
                    name = propMap[name] || name;
                    return 1 in arguments ? this.each(function(idx) {
                        this[name] = funcArg(this, value, idx, this[name]);
                    }) : this[0] && this[0][name];
                },
                data: function(name, value) {
                    var attrName = "data-" + name.replace(capitalRE, "-$1").toLowerCase();
                    var data = 1 in arguments ? this.attr(attrName, value) : this.attr(attrName);
                    return data !== null ? deserializeValue(data) : undefined;
                },
                val: function(value) {
                    return 0 in arguments ? this.each(function(idx) {
                        this.value = funcArg(this, value, idx, this.value);
                    }) : this[0] && (this[0].multiple ? $(this[0]).find("option").filter(function() {
                        return this.selected;
                    }).pluck("value") : this[0].value);
                },
                offset: function(coordinates) {
                    if (coordinates) return this.each(function(index) {
                        var $this = $(this), coords = funcArg(this, coordinates, index, $this.offset()), parentOffset = $this.offsetParent().offset(), props = {
                            top: coords.top - parentOffset.top,
                            left: coords.left - parentOffset.left
                        };
                        if ($this.css("position") == "static") props["position"] = "relative";
                        $this.css(props);
                    });
                    if (!this.length) return null;
                    var obj = this[0].getBoundingClientRect();
                    return {
                        left: obj.left + window.pageXOffset,
                        top: obj.top + window.pageYOffset,
                        width: Math.round(obj.width),
                        height: Math.round(obj.height)
                    };
                },
                css: function(property, value) {
                    if (arguments.length < 2) {
                        var element = this[0], computedStyle = getComputedStyle(element, "");
                        if (!element) return;
                        if (typeof property == "string") return element.style[camelize(property)] || computedStyle.getPropertyValue(property); else if (isArray(property)) {
                            var props = {};
                            $.each(isArray(property) ? property : [ property ], function(_, prop) {
                                props[prop] = element.style[camelize(prop)] || computedStyle.getPropertyValue(prop);
                            });
                            return props;
                        }
                    }
                    var css = "";
                    if (type(property) == "string") {
                        if (!value && value !== 0) this.each(function() {
                            this.style.removeProperty(dasherize(property));
                        }); else css = dasherize(property) + ":" + maybeAddPx(property, value);
                    } else {
                        for (key in property) if (!property[key] && property[key] !== 0) this.each(function() {
                            this.style.removeProperty(dasherize(key));
                        }); else css += dasherize(key) + ":" + maybeAddPx(key, property[key]) + ";";
                    }
                    return this.each(function() {
                        this.style.cssText += ";" + css;
                    });
                },
                index: function(element) {
                    return element ? this.indexOf($(element)[0]) : this.parent().children().indexOf(this[0]);
                },
                hasClass: function(name) {
                    if (!name) return false;
                    return emptyArray.some.call(this, function(el) {
                        return this.test(className(el));
                    }, classRE(name));
                },
                addClass: function(name) {
                    if (!name) return this;
                    return this.each(function(idx) {
                        classList = [];
                        var cls = className(this), newName = funcArg(this, name, idx, cls);
                        newName.split(/\s+/g).forEach(function(klass) {
                            if (!$(this).hasClass(klass)) classList.push(klass);
                        }, this);
                        classList.length && className(this, cls + (cls ? " " : "") + classList.join(" "));
                    });
                },
                removeClass: function(name) {
                    return this.each(function(idx) {
                        if (name === undefined) return className(this, "");
                        classList = className(this);
                        funcArg(this, name, idx, classList).split(/\s+/g).forEach(function(klass) {
                            classList = classList.replace(classRE(klass), " ");
                        });
                        className(this, classList.trim());
                    });
                },
                toggleClass: function(name, when) {
                    if (!name) return this;
                    return this.each(function(idx) {
                        var $this = $(this), names = funcArg(this, name, idx, className(this));
                        names.split(/\s+/g).forEach(function(klass) {
                            (when === undefined ? !$this.hasClass(klass) : when) ? $this.addClass(klass) : $this.removeClass(klass);
                        });
                    });
                },
                scrollTop: function(value) {
                    if (!this.length) return;
                    var hasScrollTop = "scrollTop" in this[0];
                    if (value === undefined) return hasScrollTop ? this[0].scrollTop : this[0].pageYOffset;
                    return this.each(hasScrollTop ? function() {
                        this.scrollTop = value;
                    } : function() {
                        this.scrollTo(this.scrollX, value);
                    });
                },
                scrollLeft: function(value) {
                    if (!this.length) return;
                    var hasScrollLeft = "scrollLeft" in this[0];
                    if (value === undefined) return hasScrollLeft ? this[0].scrollLeft : this[0].pageXOffset;
                    return this.each(hasScrollLeft ? function() {
                        this.scrollLeft = value;
                    } : function() {
                        this.scrollTo(value, this.scrollY);
                    });
                },
                position: function() {
                    if (!this.length) return;
                    var elem = this[0], offsetParent = this.offsetParent(), offset = this.offset(), parentOffset = rootNodeRE.test(offsetParent[0].nodeName) ? {
                        top: 0,
                        left: 0
                    } : offsetParent.offset();
                    offset.top -= parseFloat($(elem).css("margin-top")) || 0;
                    offset.left -= parseFloat($(elem).css("margin-left")) || 0;
                    parentOffset.top += parseFloat($(offsetParent[0]).css("border-top-width")) || 0;
                    parentOffset.left += parseFloat($(offsetParent[0]).css("border-left-width")) || 0;
                    return {
                        top: offset.top - parentOffset.top,
                        left: offset.left - parentOffset.left
                    };
                },
                offsetParent: function() {
                    return this.map(function() {
                        var parent = this.offsetParent || document.body;
                        while (parent && !rootNodeRE.test(parent.nodeName) && $(parent).css("position") == "static") parent = parent.offsetParent;
                        return parent;
                    });
                }
            };
            $.fn.detach = $.fn.remove;
            [ "width", "height" ].forEach(function(dimension) {
                var dimensionProperty = dimension.replace(/./, function(m) {
                    return m[0].toUpperCase();
                });
                $.fn[dimension] = function(value) {
                    var offset, el = this[0];
                    if (value === undefined) return isWindow(el) ? el["inner" + dimensionProperty] : isDocument(el) ? el.documentElement["scroll" + dimensionProperty] : (offset = this.offset()) && offset[dimension]; else return this.each(function(idx) {
                        el = $(this);
                        el.css(dimension, funcArg(this, value, idx, el[dimension]()));
                    });
                };
            });
            function traverseNode(node, fun) {
                fun(node);
                for (var i = 0, len = node.childNodes.length; i < len; i++) traverseNode(node.childNodes[i], fun);
            }
            adjacencyOperators.forEach(function(operator, operatorIndex) {
                var inside = operatorIndex % 2;
                $.fn[operator] = function() {
                    var argType, nodes = $.map(arguments, function(arg) {
                        argType = type(arg);
                        return argType == "object" || argType == "array" || arg == null ? arg : zepto.fragment(arg);
                    }), parent, copyByClone = this.length > 1;
                    if (nodes.length < 1) return this;
                    return this.each(function(_, target) {
                        parent = inside ? target : target.parentNode;
                        target = operatorIndex == 0 ? target.nextSibling : operatorIndex == 1 ? target.firstChild : operatorIndex == 2 ? target : null;
                        var parentInDocument = $.contains(document.documentElement, parent);
                        nodes.forEach(function(node) {
                            if (copyByClone) node = node.cloneNode(true); else if (!parent) return $(node).remove();
                            parent.insertBefore(node, target);
                            if (parentInDocument) traverseNode(node, function(el) {
                                if (el.nodeName != null && el.nodeName.toUpperCase() === "SCRIPT" && (!el.type || el.type === "text/javascript") && !el.src) window["eval"].call(window, el.innerHTML);
                            });
                        });
                    });
                };
                $.fn[inside ? operator + "To" : "insert" + (operatorIndex ? "Before" : "After")] = function(html) {
                    $(html)[operator](this);
                    return this;
                };
            });
            zepto.Z.prototype = $.fn;
            zepto.uniq = uniq;
            zepto.deserializeValue = deserializeValue;
            $.zepto = zepto;
            return $;
        }();
        (function($) {
            var _zid = 1, undefined, slice = Array.prototype.slice, isFunction = $.isFunction, isString = function(obj) {
                return typeof obj == "string";
            }, handlers = {}, specialEvents = {}, focusinSupported = "onfocusin" in window, focus = {
                focus: "focusin",
                blur: "focusout"
            }, hover = {
                mouseenter: "mouseover",
                mouseleave: "mouseout"
            };
            specialEvents.click = specialEvents.mousedown = specialEvents.mouseup = specialEvents.mousemove = "MouseEvents";
            function zid(element) {
                return element._zid || (element._zid = _zid++);
            }
            function findHandlers(element, event, fn, selector) {
                event = parse(event);
                if (event.ns) var matcher = matcherFor(event.ns);
                return (handlers[zid(element)] || []).filter(function(handler) {
                    return handler && (!event.e || handler.e == event.e) && (!event.ns || matcher.test(handler.ns)) && (!fn || zid(handler.fn) === zid(fn)) && (!selector || handler.sel == selector);
                });
            }
            function parse(event) {
                var parts = ("" + event).split(".");
                return {
                    e: parts[0],
                    ns: parts.slice(1).sort().join(" ")
                };
            }
            function matcherFor(ns) {
                return new RegExp("(?:^| )" + ns.replace(" ", " .* ?") + "(?: |$)");
            }
            function eventCapture(handler, captureSetting) {
                return handler.del && !focusinSupported && handler.e in focus || !!captureSetting;
            }
            function realEvent(type) {
                return hover[type] || focusinSupported && focus[type] || type;
            }
            function add(element, events, fn, data, selector, delegator, capture) {
                var id = zid(element), set = handlers[id] || (handlers[id] = []);
                events.split(/\s/).forEach(function(event) {
                    if (event == "ready") return $(document).ready(fn);
                    var handler = parse(event);
                    handler.fn = fn;
                    handler.sel = selector;
                    if (handler.e in hover) fn = function(e) {
                        var related = e.relatedTarget;
                        if (!related || related !== this && !$.contains(this, related)) return handler.fn.apply(this, arguments);
                    };
                    handler.del = delegator;
                    var callback = delegator || fn;
                    handler.proxy = function(e) {
                        e = compatible(e);
                        if (e.isImmediatePropagationStopped()) return;
                        e.data = data;
                        var result = callback.apply(element, e._args == undefined ? [ e ] : [ e ].concat(e._args));
                        if (result === false) e.preventDefault(), e.stopPropagation();
                        return result;
                    };
                    handler.i = set.length;
                    set.push(handler);
                    if ("addEventListener" in element) element.addEventListener(realEvent(handler.e), handler.proxy, eventCapture(handler, capture));
                });
            }
            function remove(element, events, fn, selector, capture) {
                var id = zid(element);
                (events || "").split(/\s/).forEach(function(event) {
                    findHandlers(element, event, fn, selector).forEach(function(handler) {
                        delete handlers[id][handler.i];
                        if ("removeEventListener" in element) element.removeEventListener(realEvent(handler.e), handler.proxy, eventCapture(handler, capture));
                    });
                });
            }
            $.event = {
                add: add,
                remove: remove
            };
            $.proxy = function(fn, context) {
                var args = 2 in arguments && slice.call(arguments, 2);
                if (isFunction(fn)) {
                    var proxyFn = function() {
                        return fn.apply(context, args ? args.concat(slice.call(arguments)) : arguments);
                    };
                    proxyFn._zid = zid(fn);
                    return proxyFn;
                } else if (isString(context)) {
                    if (args) {
                        args.unshift(fn[context], fn);
                        return $.proxy.apply(null, args);
                    } else {
                        return $.proxy(fn[context], fn);
                    }
                } else {
                    throw new TypeError("expected function");
                }
            };
            $.fn.bind = function(event, data, callback) {
                return this.on(event, data, callback);
            };
            $.fn.unbind = function(event, callback) {
                return this.off(event, callback);
            };
            $.fn.one = function(event, selector, data, callback) {
                return this.on(event, selector, data, callback, 1);
            };
            var returnTrue = function() {
                return true;
            }, returnFalse = function() {
                return false;
            }, ignoreProperties = /^([A-Z]|returnValue$|layer[XY]$)/, eventMethods = {
                preventDefault: "isDefaultPrevented",
                stopImmediatePropagation: "isImmediatePropagationStopped",
                stopPropagation: "isPropagationStopped"
            };
            function compatible(event, source) {
                if (source || !event.isDefaultPrevented) {
                    source || (source = event);
                    $.each(eventMethods, function(name, predicate) {
                        var sourceMethod = source[name];
                        event[name] = function() {
                            this[predicate] = returnTrue;
                            return sourceMethod && sourceMethod.apply(source, arguments);
                        };
                        event[predicate] = returnFalse;
                    });
                    if (source.defaultPrevented !== undefined ? source.defaultPrevented : "returnValue" in source ? source.returnValue === false : source.getPreventDefault && source.getPreventDefault()) event.isDefaultPrevented = returnTrue;
                }
                return event;
            }
            function createProxy(event) {
                var key, proxy = {
                    originalEvent: event
                };
                for (key in event) if (!ignoreProperties.test(key) && event[key] !== undefined) proxy[key] = event[key];
                return compatible(proxy, event);
            }
            $.fn.delegate = function(selector, event, callback) {
                return this.on(event, selector, callback);
            };
            $.fn.undelegate = function(selector, event, callback) {
                return this.off(event, selector, callback);
            };
            $.fn.live = function(event, callback) {
                $(document.body).delegate(this.selector, event, callback);
                return this;
            };
            $.fn.die = function(event, callback) {
                $(document.body).undelegate(this.selector, event, callback);
                return this;
            };
            $.fn.on = function(event, selector, data, callback, one) {
                var autoRemove, delegator, $this = this;
                if (event && !isString(event)) {
                    $.each(event, function(type, fn) {
                        $this.on(type, selector, data, fn, one);
                    });
                    return $this;
                }
                if (!isString(selector) && !isFunction(callback) && callback !== false) callback = data, data = selector, selector = undefined;
                if (isFunction(data) || data === false) callback = data, data = undefined;
                if (callback === false) callback = returnFalse;
                return $this.each(function(_, element) {
                    if (one) autoRemove = function(e) {
                        remove(element, e.type, callback);
                        return callback.apply(this, arguments);
                    };
                    if (selector) delegator = function(e) {
                        var evt, match = $(e.target).closest(selector, element).get(0);
                        if (match && match !== element) {
                            evt = $.extend(createProxy(e), {
                                currentTarget: match,
                                liveFired: element
                            });
                            return (autoRemove || callback).apply(match, [ evt ].concat(slice.call(arguments, 1)));
                        }
                    };
                    add(element, event, callback, data, selector, delegator || autoRemove);
                });
            };
            $.fn.off = function(event, selector, callback) {
                var $this = this;
                if (event && !isString(event)) {
                    $.each(event, function(type, fn) {
                        $this.off(type, selector, fn);
                    });
                    return $this;
                }
                if (!isString(selector) && !isFunction(callback) && callback !== false) callback = selector, selector = undefined;
                if (callback === false) callback = returnFalse;
                return $this.each(function() {
                    remove(this, event, callback, selector);
                });
            };
            $.fn.trigger = function(event, args) {
                event = isString(event) || $.isPlainObject(event) ? $.Event(event) : compatible(event);
                event._args = args;
                return this.each(function() {
                    if ("dispatchEvent" in this) this.dispatchEvent(event); else $(this).triggerHandler(event, args);
                });
            };
            $.fn.triggerHandler = function(event, args) {
                var e, result;
                this.each(function(i, element) {
                    e = createProxy(isString(event) ? $.Event(event) : event);
                    e._args = args;
                    e.target = element;
                    $.each(findHandlers(element, event.type || event), function(i, handler) {
                        result = handler.proxy(e);
                        if (e.isImmediatePropagationStopped()) return false;
                    });
                });
                return result;
            };
            ("focusin focusout load resize scroll unload click dblclick " + "mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave " + "change select keydown keypress keyup error").split(" ").forEach(function(event) {
                $.fn[event] = function(callback) {
                    return callback ? this.bind(event, callback) : this.trigger(event);
                };
            });
            [ "focus", "blur" ].forEach(function(name) {
                $.fn[name] = function(callback) {
                    if (callback) this.bind(name, callback); else this.each(function() {
                        try {
                            this[name]();
                        } catch (e) {}
                    });
                    return this;
                };
            });
            $.Event = function(type, props) {
                if (!isString(type)) props = type, type = props.type;
                var event = document.createEvent(specialEvents[type] || "Events"), bubbles = true;
                if (props) for (var name in props) name == "bubbles" ? bubbles = !!props[name] : event[name] = props[name];
                event.initEvent(type, bubbles, true);
                return compatible(event);
            };
        })(Zepto);
        (function($) {
            var jsonpID = 0, document = window.document, key, name, rscript = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, scriptTypeRE = /^(?:text|application)\/javascript/i, xmlTypeRE = /^(?:text|application)\/xml/i, jsonType = "application/json", htmlType = "text/html", blankRE = /^\s*$/;
            function triggerAndReturn(context, eventName, data) {
                var event = $.Event(eventName);
                $(context).trigger(event, data);
                return !event.isDefaultPrevented();
            }
            function triggerGlobal(settings, context, eventName, data) {
                if (settings.global) return triggerAndReturn(context || document, eventName, data);
            }
            $.active = 0;
            function ajaxStart(settings) {
                if (settings.global && $.active++ === 0) triggerGlobal(settings, null, "ajaxStart");
            }
            function ajaxStop(settings) {
                if (settings.global && !--$.active) triggerGlobal(settings, null, "ajaxStop");
            }
            function ajaxBeforeSend(xhr, settings) {
                var context = settings.context;
                if (settings.beforeSend.call(context, xhr, settings) === false || triggerGlobal(settings, context, "ajaxBeforeSend", [ xhr, settings ]) === false) return false;
                triggerGlobal(settings, context, "ajaxSend", [ xhr, settings ]);
            }
            function ajaxSuccess(data, xhr, settings, deferred) {
                var context = settings.context, status = "success";
                settings.success.call(context, data, status, xhr);
                if (deferred) deferred.resolveWith(context, [ data, status, xhr ]);
                triggerGlobal(settings, context, "ajaxSuccess", [ xhr, settings, data ]);
                ajaxComplete(status, xhr, settings);
            }
            function ajaxError(error, type, xhr, settings, deferred) {
                var context = settings.context;
                settings.error.call(context, xhr, type, error);
                if (deferred) deferred.rejectWith(context, [ xhr, type, error ]);
                triggerGlobal(settings, context, "ajaxError", [ xhr, settings, error || type ]);
                ajaxComplete(type, xhr, settings);
            }
            function ajaxComplete(status, xhr, settings) {
                var context = settings.context;
                settings.complete.call(context, xhr, status);
                triggerGlobal(settings, context, "ajaxComplete", [ xhr, settings ]);
                ajaxStop(settings);
            }
            function empty() {}
            $.ajaxJSONP = function(options, deferred) {
                if (!("type" in options)) return $.ajax(options);
                var _callbackName = options.jsonpCallback, callbackName = ($.isFunction(_callbackName) ? _callbackName() : _callbackName) || "jsonp" + ++jsonpID, script = document.createElement("script"), originalCallback = window[callbackName], responseData, abort = function(errorType) {
                    $(script).triggerHandler("error", errorType || "abort");
                }, xhr = {
                    abort: abort
                }, abortTimeout;
                if (deferred) deferred.promise(xhr);
                $(script).on("load error", function(e, errorType) {
                    clearTimeout(abortTimeout);
                    $(script).off().remove();
                    if (e.type == "error" || !responseData) {
                        ajaxError(null, errorType || "error", xhr, options, deferred);
                    } else {
                        ajaxSuccess(responseData[0], xhr, options, deferred);
                    }
                    window[callbackName] = originalCallback;
                    if (responseData && $.isFunction(originalCallback)) originalCallback(responseData[0]);
                    originalCallback = responseData = undefined;
                });
                if (ajaxBeforeSend(xhr, options) === false) {
                    abort("abort");
                    return xhr;
                }
                window[callbackName] = function() {
                    responseData = arguments;
                };
                script.src = options.url.replace(/\?(.+)=\?/, "?$1=" + callbackName);
                document.head.appendChild(script);
                if (options.timeout > 0) abortTimeout = setTimeout(function() {
                    abort("timeout");
                }, options.timeout);
                return xhr;
            };
            $.ajaxSettings = {
                type: "GET",
                beforeSend: empty,
                success: empty,
                error: empty,
                complete: empty,
                context: null,
                global: true,
                xhr: function() {
                    return new window.XMLHttpRequest;
                },
                accepts: {
                    script: "text/javascript, application/javascript, application/x-javascript",
                    json: jsonType,
                    xml: "application/xml, text/xml",
                    html: htmlType,
                    text: "text/plain"
                },
                crossDomain: false,
                timeout: 0,
                processData: true,
                cache: true
            };
            function mimeToDataType(mime) {
                if (mime) mime = mime.split(";", 2)[0];
                return mime && (mime == htmlType ? "html" : mime == jsonType ? "json" : scriptTypeRE.test(mime) ? "script" : xmlTypeRE.test(mime) && "xml") || "text";
            }
            function appendQuery(url, query) {
                if (query == "") return url;
                return (url + "&" + query).replace(/[&?]{1,2}/, "?");
            }
            function serializeData(options) {
                if (options.processData && options.data && $.type(options.data) != "string") options.data = $.param(options.data, options.traditional);
                if (options.data && (!options.type || options.type.toUpperCase() == "GET")) options.url = appendQuery(options.url, options.data), options.data = undefined;
            }
            $.ajax = function(options) {
                var settings = $.extend({}, options || {}), deferred = $.Deferred && $.Deferred();
                for (key in $.ajaxSettings) if (settings[key] === undefined) settings[key] = $.ajaxSettings[key];
                ajaxStart(settings);
                if (!settings.crossDomain) settings.crossDomain = /^([\w-]+:)?\/\/([^\/]+)/.test(settings.url) && RegExp.$2 != window.location.host;
                if (!settings.url) settings.url = window.location.toString();
                serializeData(settings);
                var dataType = settings.dataType, hasPlaceholder = /\?.+=\?/.test(settings.url);
                if (hasPlaceholder) dataType = "jsonp";
                if (settings.cache === false || (!options || options.cache !== true) && ("script" == dataType || "jsonp" == dataType)) settings.url = appendQuery(settings.url, "_=" + Date.now());
                if ("jsonp" == dataType) {
                    if (!hasPlaceholder) settings.url = appendQuery(settings.url, settings.jsonp ? settings.jsonp + "=?" : settings.jsonp === false ? "" : "callback=?");
                    return $.ajaxJSONP(settings, deferred);
                }
                var mime = settings.accepts[dataType], headers = {}, setHeader = function(name, value) {
                    headers[name.toLowerCase()] = [ name, value ];
                }, protocol = /^([\w-]+:)\/\//.test(settings.url) ? RegExp.$1 : window.location.protocol, xhr = settings.xhr(), nativeSetHeader = xhr.setRequestHeader, abortTimeout;
                if (deferred) deferred.promise(xhr);
                if (!settings.crossDomain) setHeader("X-Requested-With", "XMLHttpRequest");
                setHeader("Accept", mime || "*/*");
                if (mime = settings.mimeType || mime) {
                    if (mime.indexOf(",") > -1) mime = mime.split(",", 2)[0];
                    xhr.overrideMimeType && xhr.overrideMimeType(mime);
                }
                if (settings.contentType || settings.contentType !== false && settings.data && settings.type.toUpperCase() != "GET") setHeader("Content-Type", settings.contentType || "application/x-www-form-urlencoded");
                if (settings.headers) for (name in settings.headers) setHeader(name, settings.headers[name]);
                xhr.setRequestHeader = setHeader;
                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4) {
                        xhr.onreadystatechange = empty;
                        clearTimeout(abortTimeout);
                        var result, error = false;
                        if (xhr.status >= 200 && xhr.status < 300 || xhr.status == 304 || xhr.status == 0 && protocol == "file:") {
                            dataType = dataType || mimeToDataType(settings.mimeType || xhr.getResponseHeader("content-type"));
                            result = xhr.responseText;
                            try {
                                if (dataType == "script") (1, eval)(result); else if (dataType == "xml") result = xhr.responseXML; else if (dataType == "json") result = blankRE.test(result) ? null : $.parseJSON(result);
                            } catch (e) {
                                error = e;
                            }
                            if (error) ajaxError(error, "parsererror", xhr, settings, deferred); else ajaxSuccess(result, xhr, settings, deferred);
                        } else {
                            ajaxError(xhr.statusText || null, xhr.status ? "error" : "abort", xhr, settings, deferred);
                        }
                    }
                };
                if (ajaxBeforeSend(xhr, settings) === false) {
                    xhr.abort();
                    ajaxError(null, "abort", xhr, settings, deferred);
                    return xhr;
                }
                if (settings.xhrFields) for (name in settings.xhrFields) xhr[name] = settings.xhrFields[name];
                var async = "async" in settings ? settings.async : true;
                xhr.open(settings.type, settings.url, async, settings.username, settings.password);
                for (name in headers) nativeSetHeader.apply(xhr, headers[name]);
                if (settings.timeout > 0) abortTimeout = setTimeout(function() {
                    xhr.onreadystatechange = empty;
                    xhr.abort();
                    ajaxError(null, "timeout", xhr, settings, deferred);
                }, settings.timeout);
                xhr.send(settings.data ? settings.data : null);
                return xhr;
            };
            function parseArguments(url, data, success, dataType) {
                if ($.isFunction(data)) dataType = success, success = data, data = undefined;
                if (!$.isFunction(success)) dataType = success, success = undefined;
                return {
                    url: url,
                    data: data,
                    success: success,
                    dataType: dataType
                };
            }
            $.get = function() {
                return $.ajax(parseArguments.apply(null, arguments));
            };
            $.post = function() {
                var options = parseArguments.apply(null, arguments);
                options.type = "POST";
                return $.ajax(options);
            };
            $.getJSON = function() {
                var options = parseArguments.apply(null, arguments);
                options.dataType = "json";
                return $.ajax(options);
            };
            $.fn.load = function(url, data, success) {
                if (!this.length) return this;
                var self = this, parts = url.split(/\s/), selector, options = parseArguments(url, data, success), callback = options.success;
                if (parts.length > 1) options.url = parts[0], selector = parts[1];
                options.success = function(response) {
                    self.html(selector ? $("<div>").html(response.replace(rscript, "")).find(selector) : response);
                    callback && callback.apply(self, arguments);
                };
                $.ajax(options);
                return this;
            };
            var escape = encodeURIComponent;
            function serialize(params, obj, traditional, scope) {
                var type, array = $.isArray(obj), hash = $.isPlainObject(obj);
                $.each(obj, function(key, value) {
                    type = $.type(value);
                    if (scope) key = traditional ? scope : scope + "[" + (hash || type == "object" || type == "array" ? key : "") + "]";
                    if (!scope && array) params.add(value.name, value.value); else if (type == "array" || !traditional && type == "object") serialize(params, value, traditional, key); else params.add(key, value);
                });
            }
            $.param = function(obj, traditional) {
                var params = [];
                params.add = function(k, v) {
                    this.push(escape(k) + "=" + escape(v));
                };
                serialize(params, obj, traditional);
                return params.join("&").replace(/%20/g, "+");
            };
        })(Zepto);
        (function($) {
            $.fn.serializeArray = function() {
                var result = [], el;
                $([].slice.call(this.get(0).elements)).each(function() {
                    el = $(this);
                    var type = el.attr("type");
                    if (this.nodeName.toLowerCase() != "fieldset" && !this.disabled && type != "submit" && type != "reset" && type != "button" && (type != "radio" && type != "checkbox" || this.checked)) result.push({
                        name: el.attr("name"),
                        value: el.val()
                    });
                });
                return result;
            };
            $.fn.serialize = function() {
                var result = [];
                this.serializeArray().forEach(function(elm) {
                    result.push(encodeURIComponent(elm.name) + "=" + encodeURIComponent(elm.value));
                });
                return result.join("&");
            };
            $.fn.submit = function(callback) {
                if (callback) this.bind("submit", callback); else if (this.length) {
                    var event = $.Event("submit");
                    this.eq(0).trigger(event);
                    if (!event.isDefaultPrevented()) this.get(0).submit();
                }
                return this;
            };
        })(Zepto);
        (function($) {
            if (!("__proto__" in {})) {
                $.extend($.zepto, {
                    Z: function(dom, selector) {
                        dom = dom || [];
                        $.extend(dom, $.fn);
                        dom.selector = selector || "";
                        dom.__Z = true;
                        return dom;
                    },
                    isZ: function(object) {
                        return $.type(object) === "array" && "__Z" in object;
                    }
                });
            }
            try {
                getComputedStyle(undefined);
            } catch (e) {
                var nativeGetComputedStyle = getComputedStyle;
                window.getComputedStyle = function(element) {
                    try {
                        return nativeGetComputedStyle(element);
                    } catch (e) {
                        return null;
                    }
                };
            }
        })(Zepto);
        (function($) {
            var touch = {}, touchTimeout, tapTimeout, swipeTimeout, longTapTimeout, longTapDelay = 750, gesture;
            function swipeDirection(x1, x2, y1, y2) {
                return Math.abs(x1 - x2) >= Math.abs(y1 - y2) ? x1 - x2 > 0 ? "Left" : "Right" : y1 - y2 > 0 ? "Up" : "Down";
            }
            function longTap() {
                longTapTimeout = null;
                if (touch.last) {
                    touch.el.trigger("longTap");
                    touch = {};
                }
            }
            function cancelLongTap() {
                if (longTapTimeout) clearTimeout(longTapTimeout);
                longTapTimeout = null;
            }
            function cancelAll() {
                if (touchTimeout) clearTimeout(touchTimeout);
                if (tapTimeout) clearTimeout(tapTimeout);
                if (swipeTimeout) clearTimeout(swipeTimeout);
                if (longTapTimeout) clearTimeout(longTapTimeout);
                touchTimeout = tapTimeout = swipeTimeout = longTapTimeout = null;
                touch = {};
            }
            function isPrimaryTouch(event) {
                return (event.pointerType == "touch" || event.pointerType == event.MSPOINTER_TYPE_TOUCH) && event.isPrimary;
            }
            function isPointerEventType(e, type) {
                return e.type == "pointer" + type || e.type.toLowerCase() == "mspointer" + type;
            }
            $(document).ready(function() {
                var now, delta, deltaX = 0, deltaY = 0, firstTouch, _isPointerType;
                if ("MSGesture" in window) {
                    gesture = new MSGesture;
                    gesture.target = document.body;
                }
                $(document).bind("MSGestureEnd", function(e) {
                    var swipeDirectionFromVelocity = e.velocityX > 1 ? "Right" : e.velocityX < -1 ? "Left" : e.velocityY > 1 ? "Down" : e.velocityY < -1 ? "Up" : null;
                    if (swipeDirectionFromVelocity) {
                        touch.el.trigger("swipe");
                        touch.el.trigger("swipe" + swipeDirectionFromVelocity);
                    }
                }).on("touchstart MSPointerDown pointerdown", function(e) {
                    if ((_isPointerType = isPointerEventType(e, "down")) && !isPrimaryTouch(e)) return;
                    firstTouch = _isPointerType ? e : e.touches[0];
                    if (e.touches && e.touches.length === 1 && touch.x2) {
                        touch.x2 = undefined;
                        touch.y2 = undefined;
                    }
                    now = Date.now();
                    delta = now - (touch.last || now);
                    touch.el = $("tagName" in firstTouch.target ? firstTouch.target : firstTouch.target.parentNode);
                    touchTimeout && clearTimeout(touchTimeout);
                    touch.x1 = firstTouch.pageX;
                    touch.y1 = firstTouch.pageY;
                    if (delta > 0 && delta <= 250) touch.isDoubleTap = true;
                    touch.last = now;
                    longTapTimeout = setTimeout(longTap, longTapDelay);
                    if (gesture && _isPointerType) gesture.addPointer(e.pointerId);
                }).on("touchmove MSPointerMove pointermove", function(e) {
                    if ((_isPointerType = isPointerEventType(e, "move")) && !isPrimaryTouch(e)) return;
                    firstTouch = _isPointerType ? e : e.touches[0];
                    cancelLongTap();
                    touch.x2 = firstTouch.pageX;
                    touch.y2 = firstTouch.pageY;
                    deltaX += Math.abs(touch.x1 - touch.x2);
                    deltaY += Math.abs(touch.y1 - touch.y2);
                }).on("touchend MSPointerUp pointerup", function(e) {
                    if ((_isPointerType = isPointerEventType(e, "up")) && !isPrimaryTouch(e)) return;
                    cancelLongTap();
                    if (touch.x2 && Math.abs(touch.x1 - touch.x2) > 30 || touch.y2 && Math.abs(touch.y1 - touch.y2) > 30) swipeTimeout = setTimeout(function() {
                        touch.el.trigger("swipe");
                        touch.el.trigger("swipe" + swipeDirection(touch.x1, touch.x2, touch.y1, touch.y2));
                        touch = {};
                    }, 0); else if ("last" in touch) if (deltaX < 30 && deltaY < 30) {
                        tapTimeout = setTimeout(function() {
                            var event = $.Event("tap");
                            event.cancelTouch = cancelAll;
                            touch.el.trigger(event);
                            if (touch.isDoubleTap) {
                                if (touch.el) touch.el.trigger("doubleTap");
                                touch = {};
                            } else {
                                touchTimeout = setTimeout(function() {
                                    touchTimeout = null;
                                    if (touch.el) touch.el.trigger("singleTap");
                                    touch = {};
                                }, 250);
                            }
                        }, 0);
                    } else {
                        touch = {};
                    }
                    deltaX = deltaY = 0;
                }).on("touchcancel MSPointerCancel pointercancel", cancelAll);
                $(window).on("scroll", cancelAll);
            });
            [ "swipe", "swipeLeft", "swipeRight", "swipeUp", "swipeDown", "doubleTap", "tap", "singleTap", "longTap" ].forEach(function(eventName) {
                $.fn[eventName] = function(callback) {
                    return this.on(eventName, callback);
                };
            });
        })(Zepto);
        (function($, undefined) {
            var prefix = "", eventPrefix, endEventName, endAnimationName, vendors = {
                Webkit: "webkit",
                Moz: "",
                O: "o"
            }, document = window.document, testEl = document.createElement("div"), supportedTransforms = /^((translate|rotate|scale)(X|Y|Z|3d)?|matrix(3d)?|perspective|skew(X|Y)?)$/i, transform, transitionProperty, transitionDuration, transitionTiming, transitionDelay, animationName, animationDuration, animationTiming, animationDelay, cssReset = {};
            function dasherize(str) {
                return str.replace(/([a-z])([A-Z])/, "$1-$2").toLowerCase();
            }
            function normalizeEvent(name) {
                return eventPrefix ? eventPrefix + name : name.toLowerCase();
            }
            $.each(vendors, function(vendor, event) {
                if (testEl.style[vendor + "TransitionProperty"] !== undefined) {
                    prefix = "-" + vendor.toLowerCase() + "-";
                    eventPrefix = event;
                    return false;
                }
            });
            transform = prefix + "transform";
            cssReset[transitionProperty = prefix + "transition-property"] = cssReset[transitionDuration = prefix + "transition-duration"] = cssReset[transitionDelay = prefix + "transition-delay"] = cssReset[transitionTiming = prefix + "transition-timing-function"] = cssReset[animationName = prefix + "animation-name"] = cssReset[animationDuration = prefix + "animation-duration"] = cssReset[animationDelay = prefix + "animation-delay"] = cssReset[animationTiming = prefix + "animation-timing-function"] = "";
            $.fx = {
                off: eventPrefix === undefined && testEl.style.transitionProperty === undefined,
                speeds: {
                    _default: 400,
                    fast: 200,
                    slow: 600
                },
                cssPrefix: prefix,
                transitionEnd: normalizeEvent("TransitionEnd"),
                animationEnd: normalizeEvent("AnimationEnd")
            };
            $.fn.animate = function(properties, duration, ease, callback, delay) {
                if ($.isFunction(duration)) callback = duration, ease = undefined, duration = undefined;
                if ($.isFunction(ease)) callback = ease, ease = undefined;
                if ($.isPlainObject(duration)) ease = duration.easing, callback = duration.complete, delay = duration.delay, duration = duration.duration;
                if (duration) duration = (typeof duration == "number" ? duration : $.fx.speeds[duration] || $.fx.speeds._default) / 1e3;
                if (delay) delay = parseFloat(delay) / 1e3;
                return this.anim(properties, duration, ease, callback, delay);
            };
            $.fn.anim = function(properties, duration, ease, callback, delay) {
                var key, cssValues = {}, cssProperties, transforms = "", that = this, wrappedCallback, endEvent = $.fx.transitionEnd, fired = false;
                if (duration === undefined) duration = $.fx.speeds._default / 1e3;
                if (delay === undefined) delay = 0;
                if ($.fx.off) duration = 0;
                if (typeof properties == "string") {
                    cssValues[animationName] = properties;
                    cssValues[animationDuration] = duration + "s";
                    cssValues[animationDelay] = delay + "s";
                    cssValues[animationTiming] = ease || "linear";
                    endEvent = $.fx.animationEnd;
                } else {
                    cssProperties = [];
                    for (key in properties) if (supportedTransforms.test(key)) transforms += key + "(" + properties[key] + ") "; else cssValues[key] = properties[key], cssProperties.push(dasherize(key));
                    if (transforms) cssValues[transform] = transforms, cssProperties.push(transform);
                    if (duration > 0 && typeof properties === "object") {
                        cssValues[transitionProperty] = cssProperties.join(", ");
                        cssValues[transitionDuration] = duration + "s";
                        cssValues[transitionDelay] = delay + "s";
                        cssValues[transitionTiming] = ease || "linear";
                    }
                }
                wrappedCallback = function(event) {
                    if (typeof event !== "undefined") {
                        if (event.target !== event.currentTarget) return;
                        $(event.target).unbind(endEvent, wrappedCallback);
                    } else $(this).unbind(endEvent, wrappedCallback);
                    fired = true;
                    $(this).css(cssReset);
                    callback && callback.call(this);
                };
                if (duration > 0) {
                    this.bind(endEvent, wrappedCallback);
                    setTimeout(function() {
                        if (fired) return;
                        wrappedCallback.call(that);
                    }, duration * 1e3 + 25);
                }
                this.size() && this.get(0).clientLeft;
                this.css(cssValues);
                if (duration <= 0) setTimeout(function() {
                    that.each(function() {
                        wrappedCallback.call(this);
                    });
                }, 0);
                return this;
            };
            testEl = null;
        })(Zepto);
        (function($) {
            $.Callbacks = function(options) {
                options = $.extend({}, options);
                var memory, fired, firing, firingStart, firingLength, firingIndex, list = [], stack = !options.once && [], fire = function(data) {
                    memory = options.memory && data;
                    fired = true;
                    firingIndex = firingStart || 0;
                    firingStart = 0;
                    firingLength = list.length;
                    firing = true;
                    for (; list && firingIndex < firingLength; ++firingIndex) {
                        if (list[firingIndex].apply(data[0], data[1]) === false && options.stopOnFalse) {
                            memory = false;
                            break;
                        }
                    }
                    firing = false;
                    if (list) {
                        if (stack) stack.length && fire(stack.shift()); else if (memory) list.length = 0; else Callbacks.disable();
                    }
                }, Callbacks = {
                    add: function() {
                        if (list) {
                            var start = list.length, add = function(args) {
                                $.each(args, function(_, arg) {
                                    if (typeof arg === "function") {
                                        if (!options.unique || !Callbacks.has(arg)) list.push(arg);
                                    } else if (arg && arg.length && typeof arg !== "string") add(arg);
                                });
                            };
                            add(arguments);
                            if (firing) firingLength = list.length; else if (memory) {
                                firingStart = start;
                                fire(memory);
                            }
                        }
                        return this;
                    },
                    remove: function() {
                        if (list) {
                            $.each(arguments, function(_, arg) {
                                var index;
                                while ((index = $.inArray(arg, list, index)) > -1) {
                                    list.splice(index, 1);
                                    if (firing) {
                                        if (index <= firingLength) --firingLength;
                                        if (index <= firingIndex) --firingIndex;
                                    }
                                }
                            });
                        }
                        return this;
                    },
                    has: function(fn) {
                        return !!(list && (fn ? $.inArray(fn, list) > -1 : list.length));
                    },
                    empty: function() {
                        firingLength = list.length = 0;
                        return this;
                    },
                    disable: function() {
                        list = stack = memory = undefined;
                        return this;
                    },
                    disabled: function() {
                        return !list;
                    },
                    lock: function() {
                        stack = undefined;
                        if (!memory) Callbacks.disable();
                        return this;
                    },
                    locked: function() {
                        return !stack;
                    },
                    fireWith: function(context, args) {
                        if (list && (!fired || stack)) {
                            args = args || [];
                            args = [ context, args.slice ? args.slice() : args ];
                            if (firing) stack.push(args); else fire(args);
                        }
                        return this;
                    },
                    fire: function() {
                        return Callbacks.fireWith(this, arguments);
                    },
                    fired: function() {
                        return !!fired;
                    }
                };
                return Callbacks;
            };
        })(Zepto);
        (function($) {
            var slice = Array.prototype.slice;
            function Deferred(func) {
                var tuples = [ [ "resolve", "done", $.Callbacks({
                    once: 1,
                    memory: 1
                }), "resolved" ], [ "reject", "fail", $.Callbacks({
                    once: 1,
                    memory: 1
                }), "rejected" ], [ "notify", "progress", $.Callbacks({
                    memory: 1
                }) ] ], state = "pending", promise = {
                    state: function() {
                        return state;
                    },
                    always: function() {
                        deferred.done(arguments).fail(arguments);
                        return this;
                    },
                    then: function() {
                        var fns = arguments;
                        return Deferred(function(defer) {
                            $.each(tuples, function(i, tuple) {
                                var fn = $.isFunction(fns[i]) && fns[i];
                                deferred[tuple[1]](function() {
                                    var returned = fn && fn.apply(this, arguments);
                                    if (returned && $.isFunction(returned.promise)) {
                                        returned.promise().done(defer.resolve).fail(defer.reject).progress(defer.notify);
                                    } else {
                                        var context = this === promise ? defer.promise() : this, values = fn ? [ returned ] : arguments;
                                        defer[tuple[0] + "With"](context, values);
                                    }
                                });
                            });
                            fns = null;
                        }).promise();
                    },
                    promise: function(obj) {
                        return obj != null ? $.extend(obj, promise) : promise;
                    }
                }, deferred = {};
                $.each(tuples, function(i, tuple) {
                    var list = tuple[2], stateString = tuple[3];
                    promise[tuple[1]] = list.add;
                    if (stateString) {
                        list.add(function() {
                            state = stateString;
                        }, tuples[i ^ 1][2].disable, tuples[2][2].lock);
                    }
                    deferred[tuple[0]] = function() {
                        deferred[tuple[0] + "With"](this === deferred ? promise : this, arguments);
                        return this;
                    };
                    deferred[tuple[0] + "With"] = list.fireWith;
                });
                promise.promise(deferred);
                if (func) func.call(deferred, deferred);
                return deferred;
            }
            $.when = function(sub) {
                var resolveValues = slice.call(arguments), len = resolveValues.length, i = 0, remain = len !== 1 || sub && $.isFunction(sub.promise) ? len : 0, deferred = remain === 1 ? sub : Deferred(), progressValues, progressContexts, resolveContexts, updateFn = function(i, ctx, val) {
                    return function(value) {
                        ctx[i] = this;
                        val[i] = arguments.length > 1 ? slice.call(arguments) : value;
                        if (val === progressValues) {
                            deferred.notifyWith(ctx, val);
                        } else if (!--remain) {
                            deferred.resolveWith(ctx, val);
                        }
                    };
                };
                if (len > 1) {
                    progressValues = new Array(len);
                    progressContexts = new Array(len);
                    resolveContexts = new Array(len);
                    for (; i < len; ++i) {
                        if (resolveValues[i] && $.isFunction(resolveValues[i].promise)) {
                            resolveValues[i].promise().done(updateFn(i, resolveContexts, resolveValues)).fail(deferred.reject).progress(updateFn(i, progressContexts, progressValues));
                        } else {
                            --remain;
                        }
                    }
                }
                if (!remain) deferred.resolveWith(resolveContexts, resolveValues);
                return deferred.promise();
            };
            $.Deferred = Deferred;
        })(Zepto);
        module.exports = Zepto;
    });
    define("D:/workspaces/cyan/changquan/tmp-build/main.js", function(require, exports, module) {
        var $ = require("D:/workspaces/cyan/changquan/tmp-build/lib/zepto.cyan.js");
        var $$template = require("D:/workspaces/cyan/changquan/tmp-build/lib/template.cyan.js");
        var $$utils = require("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_utils.js");
        var $$config = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_config.js");
        var params = window.changquan && window.changquan._tmp && window.changquan._tmp.params || {};
        window.changquan._tmp = undefined;
        $$config.client_id = params.client_id;
        $$config.resourceRoot = params.resourceRoot;
        var $$init_module = require("D:/workspaces/cyan/changquan/tmp-build/widget/global/changquan_init.js");
        var $$face_utils = require("D:/workspaces/cyan/changquan/tmp-build/widget/utils/changquan_face.js");
        var init = function() {
            $$template.helper("getFormatDate", $$utils.getFormatDate);
            $$template.helper("decodeFaceContent", $$face_utils.decodeFaceContent);
            $$template.helper("$escape", $$template.utils.$escape);
            $$template.helper("arrayContains", $$utils.arrayContains);
            $$init_module.init();
        };
        init();
    });
    

    run('D:/workspaces/cyan/changquan/tmp-build/main.js');
}());
