/*jslint browser: true, vars: true, nomen: true, indent: 4, maxlen: 180, plusplus: true, sloppy: true, newcap: true, sub: true, regexp: true, continue: true*/
/*global console: true*/

(function () {

    var createNameSpace = function () {
        if (window.changquan !== undefined) {
            throw '畅圈启动失败，畅圈命名空间已存在！';
        }
        window.changquan = function (params) {
            window.changquan._tmp = {};
            window.changquan._tmp.params = params || {};
        };
    };


    var loadChangquan = function () {
        var loadJs = function (src, fun) {
            var head = document.getElementsByTagName('head')[0] || document.head || document.documentElement;

            var script = document.createElement('script');
            script.setAttribute('type', 'text/javascript');
            script.setAttribute('charset', 'UTF-8');
            script.setAttribute('src', src);

            if (typeof fun === 'function') {
                if (window.attachEvent) {
                    script.onreadystatechange = function () {
                        var r = script.readyState;
                        if (r === 'loaded' || r === 'complete') {
                            script.onreadystatechange = null;
                            fun();
                        }
                    };
                } else {
                    script.onload = fun;
                }
            }

            head.appendChild(script);
        };

        var ver = +new Date() + '-' + window.Math.random();
        var url = 'http://changyan.sohu.com/changquan/version.js?' + ver;
        loadJs(url);
    };


    createNameSpace();
    loadChangquan();

}());
