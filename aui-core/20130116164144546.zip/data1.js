{ 
	"code" : "1", 
	"list" : { 
		"src" : [ 
			"images/1.jpg", 
			"images/2.jpg", 
			"images/3.jpg", 
			"images/4.jpg", 
			"images/5.jpg", 
			"images/6.jpg", 
			"images/7.jpg", 
			"images/8.jpg", 
			"images/9.jpg" 
		], 
		"title":[  
			"这个是标题10", 
			"这个是标题11", 
			"这个是标题12", 
			"这个是标题13", 
			"这个是标题14", 
			"这个是标题15", 
			"这个是标题16", 
			"这个是标题17", 
			"这个是标题18" 
		] 
	}
}