{ 
	"code" : "1", 
	"list" : { 
		"src" : [ 
			"images/1.jpg", 
			"images/2.jpg", 
			"images/3.jpg", 
			"images/4.jpg", 
			"images/5.jpg", 
			"images/6.jpg", 
			"images/7.jpg", 
			"images/8.jpg", 
			"images/9.jpg" 
		], 
		"title":[  
			"这个是标题28", 
			"这个是标题29", 
			"这个是标题30", 
			"这个是标题31", 
			"这个是标题32", 
			"这个是标题33", 
			"这个是标题34", 
			"这个是标题35", 
			"这个是标题36" 
		] 
	}
}