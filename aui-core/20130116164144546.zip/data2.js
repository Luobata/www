{ 
	"code" : "1", 
	"list" : { 
		"src" : [ 
			"images/1.jpg", 
			"images/2.jpg", 
			"images/3.jpg", 
			"images/4.jpg", 
			"images/5.jpg", 
			"images/6.jpg", 
			"images/7.jpg", 
			"images/8.jpg", 
			"images/9.jpg" 
		], 
		"title":[  
			"这个是标题19", 
			"这个是标题20", 
			"这个是标题21", 
			"这个是标题22", 
			"这个是标题23", 
			"这个是标题24", 
			"这个是标题25", 
			"这个是标题26", 
			"这个是标题27" 
		] 
	}
}